#!/bin/sh
# ---------------------------------------------------------------------
# This script will run after the install.sh script.  Typically, this
# script is used for clean or anything that does not belong in the
# install script.
# ---------------------------------------------------------------------
echo "post install running....."

