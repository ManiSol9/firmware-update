#!/bin/sh
# ---------------------------------------------------------------------
# This is an example install script.  Typically package install
# actions go in here apt-get, dnf, yum, pip install
# etc., but anything can be run here.  Return a non zero value and the
# err_install.sh script will be invoked.
# ---------------------------------------------------------------------
echo "install running...."

execute_cmd (  )
{
	echo $(date) "[MPGINSTALL]" $*
	$@
	if [ $? -ne 0 ]
	then
            install_dir='/home/cgoma/azure/logs' 
	    path="$install_dir/mpg_install_err.log"
	    echo $(date) "[MPGINSTALL - ERROR] Command failed -> " $* >> $path
		echo $(date) "[MPGINSTALL]" $*
		flag="Y"
		if [ "$flag" = "Y" ]
		then 
			echo $(date) $* "[MPGINSTALL] CONTINUE with next operation"
		elif [ true ]
		then 
			echo $(date) $* "[MPGINSTALL] Installation ABORTED"
			exit 1
		fi
	fi
}

Start_Server()
{
    execute_cmd sudo python app.py &
}

Start_Server
exit 0
