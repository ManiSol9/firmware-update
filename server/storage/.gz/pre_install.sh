#!/bin/sh
# ------------------------------------------------------------------
# This is an example pre install script.  This script holds logic
# that prepare the system for an OTA operation.  If this script
# returns a non zero value, the err_install.sh script will be invoked.
# ------------------------------------------------------------------
echo "pre install running..."

execute_cmd (  )
{
	echo $(date) "[MPGINSTALL]" $*
	$@
	if [ $? -ne 0 ]
	then
            install_dir='/home/cgoma/azure/logs' 
	    path="$install_dir/mpg_install_err.log"
	    echo $(date) "[MPGINSTALL - ERROR] Command failed -> " $* >> $path
		echo $(date) "[MPGINSTALL]" $*
		flag="Y"
		if [ "$flag" = "Y" ]
		then 
			echo $(date) $* "[MPGINSTALL] CONTINUE with next operation"
		elif [ true ]
		then 
			echo $(date) $* "[MPGINSTALL] Installation ABORTED"
			exit 1
		fi
	fi
}


Install_Dependancy()
{
    echo Installing dependancy packages
    execute_cmd sudo pip install bottle
}
#Disable_MPG_Services
#Stop_MPG_Services
#Remove_config
Install_Dependancy


exit 0
