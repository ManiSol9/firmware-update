import React, { Component } from 'react';
import { AppRegistry, FlatList, StyleSheet, TextInput, Picker, ScrollView, TouchableOpacity, Text, Image, KeyboardAvoidingView, View, TouchableHighlight, ToastAndroid, Alert, ActivityIndicator, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

import PhotoUpload from 'react-native-photo-upload'
import axios from 'axios';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import styles from '../Landing/styles.js';

import moment from "moment";


import { request } from 'graphql-request'

export default class ProfileDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            profile: [],
            height_in_feet: null,
            height_in_centimeter: null,
            height_in_inches: null,
            height_in_feet_test: null,
            height_in_inches_test: null,
            height_in_centimeter_test: null,
            weight: null,
            weight_test: null,
            age: null,
            gender: 'Male',
            userid: null,
            genderIndex: null,
            enable: null,
            Loader: false,
            contentLoader: true,
            editable: null,
            visible: true,
            profile_img_url: null,
            upload_uri: null,
            upload_uri_check: false,
            visible: true,
            imperial: null,
            weight_in_kgs: null,
            weight_in_kgs_test: null,
            password: null
        }
    }
    componentWillMount() {
        getAllAsyncStroage()
            .then(res => console.log(res)
        )
            .catch(err => console.log(err)
        );
        this.getStudentID();
    }


    photouploadserver = (file) => {
        console.log('response', file)

        let formData = new FormData();

        if (file.fileName) {
            name = file.fileName
        } else {
            image_source = file.uri
            image = image_source.split("/");
            image_length = image.length
            name = image[image_length - 1];
        }

        console.log(name)

        formData.append('myfile', {
            type: 'image/png',
            name: name,
            uri: file.uri.toString()
        })

        axios.post(API.Image_url, formData).then(response => {
            updated_img = response.data
            console.log(updated_img)

            this.setState({
                visible: true
            })
            this.setState({
                upload_uri: updated_img.url
            })
            this.setState({
                enable: true
            })


        }).catch(err => {
            console.log('err')
            console.log(err)

        })

    }


    getStudentID =async() => {
        console.log('profile view', await AsyncStorage.getItem("DEVICE_NAME"))
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        console.log(USER_ID)
        this.setState({
            userid: USER_ID,
            enable: false,
            Loader: true
        }, () => {
            this._getStudentDetails(this.state.userid);
        });
    }
    _getStudentDetails=(id) => {

        /*
        getProfileDetails(id).then(response => {
            console.log(response)
            if (response.status) {
                this.setState({
                    profile: response.data
                }, () => {

                    console.log(this.state.profile)
                    this.setState({
                        height_in_centimeter: this.state.profile.height_in_centimeter,
                        height_in_centimeter_test: this.state.profile.height_in_centimeter,
                        parameter_type: this.state.profile.parameter_type,
                        profile_img_url: this.state.profile.profile_img_url,
                        height_in_feet: this.state.profile.height_in_feet,
                        height_in_feet_test: this.state.profile.height_in_feet,
                        height_in_inches: this.state.profile.height_in_inches,
                        height_in_inches_test: this.state.profile.height_in_inches,
                        age: this.state.profile.age,
                        gender: this.state.profile.gender
                    }, () => {

                        if (this.state.gender === "Male") {
                            this.setState({
                                genderIndex: 0
                            });
                        } else if (this.state.gender === "Female") {
                            this.setState({
                                genderIndex: 1
                            });
                        } else {
                            this.setState({
                                genderIndex: 2
                            });
                        }

                        if (this.state.parameter_type == 0) {
                            this.setState({
                                imperial: 0
                            });
                            this.setState({
                                weight: this.state.profile.current_weight,
                                weight_test: this.state.profile.current_weight
                            })
                        } else {
                            this.setState({
                                imperial: 1
                            });
                            this.setState({
                                weight_in_kgs: this.state.profile.current_weight,
                                weight_in_kgs_test: this.state.profile.current_weight
                            })
                        }

                    });
                });
                console.log(this.state)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            } else {
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
            }
        }, err => {
            console.log(err)
        })
        */

        const query = `query profile_details($user_id:Int!){

                profile_details(user_id: $user_id) {
                    email,
                    dob,
                    height_in_feet,
                    height_in_meters,
                    height_in_inches,
                    current_weight_in_lbs,
                    current_weight_in_kgs,
                    parameter_type,
                    gender,
                    first_name,
                    last_name,
                    middle_name,
                    profile_image_url
                }

                }`;

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
            .then(async data => {
                response = data.profile_details[0]
                console.log(data.profile_details[0])

                    console.log(data)
                    this.setState({
                        height_in_centimeter: response.height_in_meters,
                        height_in_centimeter_test: response.height_in_centimeter,
                        parameter_type: response.parameter_type,
                        profile_img_url: response.profile_image_url,
                        height_in_feet: response.height_in_feet,
                        height_in_feet_test: response.height_in_feet,
                        height_in_inches: response.height_in_inches,
                        height_in_inches_test: response.height_in_inches,
                        gender: response.gender,
                        password: response.password
                    }, () => {

                        if (this.state.gender === "Male") {
                            this.setState({
                                genderIndex: 0
                            });
                        } else if (this.state.gender === "Female") {
                            this.setState({
                                genderIndex: 1
                            });
                        } else {
                            this.setState({
                                genderIndex: 2
                            });
                        }

                        if (this.state.parameter_type == 1) {
                            this.setState({
                                imperial: 0
                            });
                            this.setState({
                                weight: response.current_weight_in_lbs,
                                weight_test: response.current_weight_in_lbs
                            })
                        } else {
                            this.setState({
                                imperial: 1
                            });
                            this.setState({
                                weight_in_kgs: response.current_weight_in_kgs,
                                weight_in_kgs_test: response.current_weight_in_kgs
                            })
                        }

                    });


                console.log(this.state)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })

 

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )


    }

    addBLERoute=async () => {
        const {navigate} = this.props.navigation;
        if (await AsyncStorage.getItem("DEVICE_NAME") && await AsyncStorage.getItem("DEVICE_ID")) {
            navigate('UpcomingWorkouts')
        } else {
            Alert.alert('Do you want to save BLE device?', 'You can add later also.',
                [
                    {
                        text: 'Add later',
                        onPress: () => navigate('UpcomingWorkouts')
                    },
                    {
                        text: 'Add',
                        onPress: () => navigate('SearchDevices', {
                            fromRoute: 'ProfileDetails',
                            toRoute: 'SearchDevices',
                            enableBack: false
                        })
                    },
                ],
                {
                    cancelable: false
                }
            )
        }
    }
    _savedata=() => {

        console.log(this.state)
        this.setState({
            contentLoader: true
        })
        console.log('---------------------', this.state.contentLoader)

            if (this.state.gender && this.state.age !== '' && (this.state.weight != "" || this.state.weight_in_kgs != "") && (this.state.height_in_feet != "" || this.state.height_in_centimeter != "" || this.state.height_in_inches != "") && this.state.upload_uri != "") {
                if (this.state.enable) {

                    console.log(this.state.weight_in_kgs)

                        if (this.state.imperial == 0) {

                            if (this.state.height_in_inches != null && this.state.height_in_feet != null && this.state.weight != null) {

                                const query = `mutation 
                                                edit_profile_details1(
                                                    $gender:String!, 
                                                    $profile_image_url:String!, 
                                                    $height_in_feet: Int!, 
                                                    $height_in_inches: Int!,
                                                    $current_weight_in_lbs: Int!,
                                                    $parameter_type: Int!,
                                                    $id: Int!
                                                    ){
                                                    edit_profile_details1(
                                                            id: $id, 
                                                            gender: $gender, 
                                                            height_in_feet: $height_in_feet, 
                                                            height_in_inches: $height_in_inches, 
                                                            current_weight_in_lbs: $current_weight_in_lbs,
                                                            parameter_type: $parameter_type,
                                                            profile_image_url: $profile_image_url,
                                                            ) {
                                                        status
                                                }

                                            }`;                                 

                                    if (this.state.upload_uri == null) {
                                        image_path = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
                                    } else {
                                        image_path = this.state.upload_uri
                                    }    


                                    const variables = {
                                        id: Number(this.state.userid),
                                        gender: this.state.gender,
                                        height_in_inches: Number(this.state.height_in_inches),
                                        height_in_feet: Number(this.state.height_in_feet),
                                        current_weight_in_lbs: Number(this.state.weight),
                                        parameter_type: 1,
                                        profile_image_url: image_path,
                                    }


                                    //console.log(variables)

                                    request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                                        .then(async data => {
                                            console.log(data)

                                            if (data.edit_profile_details1[0].status == 'success') {
                                                alert('Profile details updated')

                                                    this.setState({
                                                        contentLoader: false
                                                    })  

                                                this._getStudentDetails(this.state.userid)

                                                AsyncStorage.setItem("PROFILE_IMAGE", String(image_path));
                                                  
                                            }

                                        }
                                    )
                                        .catch(async err => {
                                            console.log(err)
                                            alert("Something Went Wrong, Please try again later")
                                            this.setState({
                                                contentLoader: false
                                            })
                                        }
                                    )

                            } else {
                                alert("Please fill all the fields")
                                this.setState({
                                    contentLoader: false
                                })
                            }
                        } else {
                            if (this.state.height_in_centimeter != null && this.state.weight_in_kgs != null) {

                                const query = `mutation 
                                                edit_profile_details1(
                                                    $gender:String!, 
                                                    $profile_image_url:String!, 
                                                    $height_in_meters: Int!,
                                                    $current_weight_in_kgs: Int!,
                                                    $parameter_type: Int!,
                                                    $id: Int!
                                                    ){
                                                    edit_profile_details1(
                                                            id: $id, 
                                                            gender: $gender, 
                                                            height_in_meters: $height_in_meters, 
                                                            current_weight_in_kgs: $current_weight_in_kgs,
                                                            parameter_type: $parameter_type,
                                                            profile_image_url: $profile_image_url,
                                                            ) {
                                                        status
                                                }

                                            }`;

                                    if (this.state.upload_uri == null) {
                                        image_path = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
                                    } else {
                                        image_path = this.state.upload_uri
                                    }    


                                    const variables = {
                                        id: Number(this.state.userid),
                                        gender: this.state.gender,
                                        height_in_meters: Number(this.state.height_in_centimeter),
                                        current_weight_in_kgs: Number(this.state.weight_in_kgs),
                                        parameter_type: 2,
                                        profile_image_url: image_path,
                                    }


                                    //console.log(variables)

                                    request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                                        .then(async data => {
                                            console.log(data)

                                            if (data.edit_profile_details1[0].status == 'success') {
                                                alert('Profile details updated')

                                                    this.setState({
                                                        contentLoader: false
                                                    })      

                                                    this._getStudentDetails(this.state.userid)

                                                AsyncStorage.setItem("PROFILE_IMAGE", String(image_path));                                          
                                            }

                                        }
                                    )
                                        .catch(async err => {
                                            console.log(err)
                                            alert("Something Went Wrong, Please try again later")
                                            this.setState({
                                                contentLoader: false
                                            })
                                        }
                                    )
                            } else {
                                alert("Please fill all the fields")
                                this.setState({
                                    contentLoader: false
                                })
                            }
                        }

                        //console.log(this.state.imperial)



                    /*  


                    if(this.state.age<=18||this.state.age>=70){
                      this.refs.toast.show("Age should be greater than 18 and less than 70", DURATION.LENGTH_LONG);
                    }else if(this.state.weight<=30||this.state.weight>=200){
                      this.refs.toast.show("Enter valid weight in lbs", DURATION.LENGTH_LONG);
                    }else if(this.state.height<=1||this.state.height>=8){
                      this.refs.toast.show("Enter valid height in feet", DURATION.LENGTH_LONG);
                    }else{
                      updateProfile({imagePath: this.state.upload_uri, weight:this.state.weight, age:this.state.age, height:this.state.height, gender:this.state.gender, id:this.state.userid})
                      .then(async res=>{
                        console.log(res);
                        if(res.status){
                          this.getStudentID();
                          this.refs.toast.show(res.show, DURATION.LENGTH_LONG);
                          this.setState({enable:false}) 
                        }else{
                          this.refs.toast.show(res.show, DURATION.LENGTH_LONG);
                          this.setState({enable:false})
                        }
                      },err=>{
                        console.log(err);
                        this.refs.toast.show(err.show, DURATION.LENGTH_LONG);
                      })
                    }

                    */


                } else {
                    alert(" Please update any value")
                    this.setState({
                        contentLoader: false
                    })
                }
            } else {
                this.setState({
                    contentLoader: false
                })
                alert(" Please update any value")
            }

    }
    onSelect(index, value) {
        console.log(index)
        if (index == 0) {
            this.setState({
                enable: true,
                gender: "Male"
            })
        } else if (index == 1) {
            this.setState({
                enable: true,
                gender: "Female"
            })
        } else {
            this.setState({
                enable: true,
                gender: "Other"
            })
        }
    }

    openMenu = async() => {

        const {navigate} = this.props.navigation;
        navigate("Menu");

    }

    onUnitSelect(index, value) {
        console.log('index', index, this.state.height_in_centimeter_test, this.state.height_in_centimeter)
        console.log('state in onUnitSelect ',this.state)
        if (!index) {

            this.setState({
                imperial: 0
            })
            if (!(this.state.weight_in_kgs_test === null)) {

                let weight = (this.state.weight_in_kgs_test / 0.45359)
                let round_weight = Math.floor(weight)
                if ((weight - round_weight) > 0.8) {
                    round_weight = round_weight + 1
                }
                console.log('round_weight', round_weight)
                console.log('weight', weight)
                this.setState({
                    weight: round_weight,
                    weight_test: weight
                })
            }
            if (!(this.state.height_in_centimeter_test == null)) {

                let inches_test = this.state.height_in_centimeter_test * 0.39370079
                let feet_test = inches_test * 0.08333333

                let round_feet = Math.floor(feet_test)
                let inches = (feet_test - round_feet) * 12.0

                let round_inches = Math.floor(inches)
                if ((inches - round_inches) > 0.8) {
                    round_inches = round_inches + 1
                }
                console.log('round_inches', round_inches)
                // console.log('imperial:0')
                // console.log('height_in_centimeter_test',this.state.height_in_centimeter_test)
                // console.log('feet_test',feet_test)
                // console.log('round_feet',round_feet)
                // console.log('inches/12',feet_test-round_feet)
                // console.log('inches',inches)
                // console.log('inches',inches)
                // console.log('round_inches',round_inches)
                this.setState({
                    height_in_feet: round_feet,
                    height_in_feet_test: round_feet,
                    height_in_inches: round_inches,
                    height_in_inches_test: inches
                })

            }


        } else {

            this.setState({
                imperial: 1
            })

            console.log(this.state.weight_test)

            if (!(this.state.weight_test === null)) {

                let weight_in_kgs = (this.state.weight_test * 0.45359)
                let round_weight_in_kgs = Math.floor(weight_in_kgs)
                if ((weight_in_kgs - round_weight_in_kgs) > 0.8) {
                    round_weight_in_kgs = round_weight_in_kgs + 1
                }
                console.log('weight_in_kgs', weight_in_kgs)
                console.log('round_weight_in_kgs', round_weight_in_kgs)
                this.setState({
                    weight_in_kgs: round_weight_in_kgs,
                    weight_in_kgs_test: weight_in_kgs
                })
            }
            if ((!(this.state.height_in_feet_test === null)) && (!(this.state.height_in_inches_test === null))) {
                console.log('else')
                let height_in_centimeter = this.state.height_in_feet_test * 30.48 + this.state.height_in_inches_test * 2.54
                console.log('height_in_centimeter', height_in_centimeter)

                let round_height_in_centimeter = Math.floor(height_in_centimeter)
                if ((height_in_centimeter - round_height_in_centimeter) > 0.8) {
                    round_height_in_centimeter = round_height_in_centimeter + 1
                }

                this.setState({
                    height_in_centimeter: round_height_in_centimeter,
                    height_in_centimeter_test: height_in_centimeter
                })
            }
        // this.setState({height_in_centimeter:0})
        // this.setState({current_weight:0})
        }
    }

    render() {
        var that = this;
        var radio_props = [
            {
                label: 'Male',
                value: 0
            },
            {
                label: 'Female',
                value: 1
            },
            {
                label: 'Other',
                value: 2
            }
        ];
        const {height, weight, age, enable, loader, contentLoader, profile_img_url, weight_in_kgs, height_in_inches, height_in_feet, height_in_centimeter} = this.state;

        if (profile_img_url == null) {
            image_path = 'https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg'
        } else {
            image_path = profile_img_url
        }

        console.log(image_path)

        return (
            <View style={styles.mainBody}>
        <StatusBarBackground style={{
                backgroundColor: '#FF7E00'
            }}/>

          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate("Tabs", {showProfile: true,showFeed: null,showNotification: null,showMore: null})
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"/>
            </TouchableOpacity>
          </View>

        <View style={styles.header}>
          <Text style={styles.topSignupTxt}>
            Profile Details
          </Text>
        </View>
        {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <ScrollView style={{
                    marginTop: 20,
                    marginBottom: 0,
                    paddingBottom: 10,
                    height: 500,
                    width: Dimensions.get('window').width
                }} >
            <View style={styles.signup_temp_form}>
              <View style={styles.body1a}>

                    <PhotoUpload
                onPhotoSelect={avatar => {
                    if (avatar) {
                        console.log('Image base64 string: ', avatar)

                    }

                }}

                onStart = {start => {
                    console.log('start', start)
                    //this.setState({contentLoader:true})
                    this.setState({
                        visible: false
                    })
                }}
                onResponse = {response => {

                        console.log('response', response)
                                                
                        if(response.didCancel == true) {
                            this.setState({
                                visible: true
                            })                                                    
                        } else {
                            this.photouploadserver(response)
                        }                    

                }}
                onError = {error => {
                    console.log('error', error)
                }}
                onRender = {render => {
                    console.log('render', render)
                }}
                >
                   {this.state.visible ? <Image
                style={{
                    paddingVertical: 30,
                    width: 150,
                    height: 150,
                    borderRadius: 75
                }}
                resizeMode='cover'
                source={{
                    uri: image_path
                }}
                /> : <View style={{
                    height: 150,
                    width: 150,
                    borderRadius: 75,
                    paddingVertical: 30,
                    backgroundColor: 'white'
                }}><ActivityIndicator
                animating = {true}
                color = '#cccccc'
                size = "large"
                style = {{
                    paddingTop: 26
                }}
                /></View> }
                        
                       
                     </PhotoUpload> 
             

                <Text style={{
                    textAlign: 'left',
                    alignSelf: 'stretch',
                    marginLeft: '15%',
                    color: '#ffffff',
                    marginBottom: 5
                }}>Unit: </Text>
                <RadioGroup
                selectedIndex={this.state.imperial}
                style={{
                    flexDirection: 'row',
                    marginLeft: 10,
                    marginBottom: 10
                }}
                onSelect = {(index, value) => this.onUnitSelect(index, value)}>
                  <RadioButton value={1} >
                    <Text>Imperial</Text>
                  </RadioButton>
                  <RadioButton value={0}>
                    <Text>Metric</Text>
                  </RadioButton>
                </RadioGroup>
                <Text style={{
                    textAlign: 'left',
                    alignSelf: 'stretch',
                    marginLeft: '15%',
                    color: '#ffffff',
                    marginBottom: 5
                }}>Weight: </Text>
                {this.state.imperial ? <TextInput
                placeholder="Weight (kgs)"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                value={weight_in_kgs ? String(weight_in_kgs) : 0}
                placeholderTextColor='#626264'
                style={styles.textInput_signup}
                onChangeText={ (text) => this.setState({
                    weight_in_kgs: text,
                    weight_in_kgs_test: text,
                    enable: true
                })}
                /> : <TextInput
                placeholder="Weight (lbs)"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                value={weight ? String(weight) : 0}
                placeholderTextColor='#626264'
                style={styles.textInput_signup}
                onChangeText={ (text) => this.setState({
                    weight: text,
                    weight_test: text,
                    enable: true
                })}
                />}

                <Text style={{
                    textAlign: 'left',
                    alignSelf: 'stretch',
                    marginLeft: '15%',
                    color: '#ffffff',
                    marginBottom: 5
                }}>Height: </Text>
                {this.state.imperial ? <TextInput
                placeholder="Height (cm)"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                value={height_in_centimeter ? String(height_in_centimeter) : 0}
                placeholderTextColor='#626264'
                style={styles.textInput_signup}
                onChangeText={ (text) => this.setState({
                    height_in_centimeter: text,
                    height_in_centimeter_test: text,
                    enable: true
                })}
                /> : <View style={{
                    marginRight: 40,

                    marginTop: 10,
                    marginBottom: 20,
                    paddingTop: 0,
                    paddingBottom: 0,
                    paddingLeft: 25,
                    borderRadius: 30,
                    position: 'relative',
                    width: 252,
                    height: 30
                }}>
                  <View style = {{
                    flex: 1,
                    flexDirection: 'row'
                }}>
                    <TextInput
                placeholder="Feet"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                value={height_in_feet ? String(height_in_feet) : 0}
                placeholderTextColor='#626264'
                style={{
                    marginTop: 0,
                    paddingTop: 0,
                    backgroundColor: '#202124',
                    borderRadius: 30,
                    color: '#fff',
                    width: 110,
                    height: 40,
                    paddingLeft: 15,
                }}
                onChangeText={ (text) => this.setState({
                    height_in_feet: text,
                    height_in_feet_test: text,
                    enable: true
                })}
                />
                  <Text style = {{
                    marginTop: 0,
                    color: '#ffff',
                    fontSize: 30
                }}>'</Text>
                  <TextInput
                placeholder="Inches"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                value={height_in_inches ? String(height_in_inches) : 0}
                placeholderTextColor='#626264'
                style={{
                    paddingLeft: 15,
                    marginTop: 0,
                    paddingTop: 0,
                    backgroundColor: '#202124',
                    borderRadius: 30,
                    color: '#fff',
                    width: 110,
                    height: 40
                }}
                onChangeText={ (text) => this.setState({
                    height_in_inches: text,
                    height_in_inches_test: text,
                    enable: true
                })}
                />
                <Text style = {{
                    marginTop: 5,
                    color: '#ffff',
                    fontSize: 30
                }}>"</Text>
                </View>
                </View>}
                <Text style={{
                    textAlign: 'left',
                    alignSelf: 'stretch',
                    marginLeft: '15%',
                    color: '#ffffff',
                    marginBottom: 5
                }}>Gender: </Text>

                <RadioGroup
                selectedIndex={this.state.genderIndex}
                style={{
                    flexDirection: 'row',
                    marginLeft: 10
                }}
                onSelect = {(index, value) => this.onSelect(index, value)}>
                  <RadioButton value={'Male'} >
                    <Text style={{
                    color: 'white'
                }}>Male</Text>
                  </RadioButton>
                  <RadioButton value={'Female'}>
                    <Text style={{
                    color: 'white'
                }}>Female</Text>
                  </RadioButton>
                  <RadioButton value={'Other'}>
                    <Text style={{
                    color: 'white'
                }}>Other</Text>
                  </RadioButton>                  
                </RadioGroup>
              {this.props.from == null ? null
                    :
                    this.props.from === 'tabs' ?
                        <TouchableOpacity onPress={() => that._savedata()}>
                <View style={styles.saveBtn2}>
                  {loader ?
                            <ActivityIndicator
                            animating = {this.state.loader}
                            color = '#bc2b78'
                            size = "large"
                            style = {styles.activityIndicator}
                            />
                            :
                            <Text style={styles.saveTxtBtn}>
                      SAVE
                    </Text>
                        }
                  <Image style={{
                            width: 200,
                            height: 50
                        }} source={{
                            uri: 'white_btn_bg_a'
                        }} />
                </View>
              </TouchableOpacity>
                        :
                        null
                }


              </View>
            </View>
          </ScrollView>
            }
      
       

        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress={() => this._savedata()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
            <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
        
      </View>
        );
    }
}

module.exports = ProfileDetails;
