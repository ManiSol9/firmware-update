import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Switch,
  Image,
  PixelRatio,
  KeyboardAvoidingView,
  ScrollView,
  TouchableHighlight,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  ActivityIndicator, contentLoader, AsyncStorage
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

import { onSignIn } from '../../../config/auth';
import API from '../../template/constants.js';
import axios from 'axios'; 
import styles from '../signup/styles.js';
import StatusBarBackground from './statusbar.js'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

import { request } from 'graphql-request'


const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import Toast, {DURATION} from 'react-native-easy-toast'


export default class Signup extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      loader:false,
      comments:[],
      contentLoader: true,
      workout_id: null,
      user_id: null,comment: "", course_id: null, student_id: null

    };
  }
  async componentWillMount(){
    console.log(this.props.navigation);

    const { workout_id, course_id, student_id, start_date } = this.props.navigation.state.params

    let USER_ID = await AsyncStorage.getItem("USER_ID");

    date = start_date.split("T")

    this.setState({workout_id: workout_id, user_id: USER_ID, course_id: course_id, student_id: student_id, start_date: date[0]})

    this.getComments(workout_id, course_id)

  }

  backStep = () => {
    const { navigate } = this.props.navigation
    navigate("Tabs", {showProfile: null,showFeed: true,showNotification: null,showMore: null, reloadfeed: false})
  }

  getComments = (id, course_id) => {


        const query = `query fetch_comment($workout_id:Int!, $course_id: Int!){
                        fetch_comment(workout_id:$workout_id, course_id: $course_id){
                          comment
                          myid
                          start_date
                          fetch_user_details{
                            id
                            profile_image_url
                            first_name
                            middle_name
                            last_name
                          }
                        }
                      }
                      `;

        const variables = {
            workout_id: Number(id),
            course_id: Number(course_id)
        }             

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/comment', query, variables)
            .then(async data => {
                console.log(data)
                this.state.comments = data.fetch_comment
                this.setState({
                    contentLoader: false
                })

            }
        )
            .catch(async err => {
                console.log(err)
                alert('There is no schools or server problom')
                this.setState({
                    contentLoader: false
                })
            }
        )

  }

  addcomment = (id, course_id) => {

                this.setState({
                    contentLoader: true
                })

        const query = `mutation addcomment($workout_id: Int!, $user_id: Int!, $comment: String!, $start_date: String!, $start_date1: String!, $myid: Int!, $course_id: Int!){
                          addcomment(workout_id:$workout_id, user_id:$user_id, comment:$comment, start_date:$start_date, start_date1: $start_date1, myid: $myid, course_id: $course_id){
                            count
                          }
                        }
                      `;

        today = new Date()

        const variables = {
            workout_id: Number(id),
            user_id: Number(this.state.student_id),
            comment: String(this.state.comment),
            start_date: String(this.state.start_date),
            start_date1: String(today),
            myid: Number(this.state.user_id),
            course_id: Number(this.state.course_id)
        }             

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/comment', query, variables)
            .then(async data => {
                if(data.addcomment[0].count){

                    this.getComments(id, course_id)

                    this.setState({comment: ""})

                }
            }
        )
            .catch(async err => {
                console.log(err)
                //alert('There is no schools or server problom')
                this.setState({
                    contentLoader: false
                })
            }
        )

  } 


  render(){

    const { navigate } = this.props.navigation;
    const { comments, contentLoader } = this.state;

    return(
    <KeyboardAwareScrollView
      style={{ backgroundColor: '#000' }}
      resetScrollToCoords={{ x: 0, y: 0 }}
      contentContainerStyle={styles.container}
      scrollEnabled={false}
    >    
      <View style={styles.mainBody}>
      <StatusBarBackground style={{backgroundColor:'#ff7200'}}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => this.backStep()}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Coments
            </Text>
          </View>

        {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View>

                 <View>
                  <ScrollView style={{marginBottom: 200}}>
                    {comments.map(comment => {

                       if(comment.fetch_user_details[0].profile_image_url){
                        var profile_image_url = comment.fetch_user_details[0].profile_image_url
                       } else {
                        profile_image_url = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"                        
                       }


                        var today = new Date();
                        var comment_date = new Date(comment.start_date);
                        var diffMs = (today - comment_date); // milliseconds between now & Christmas
                        var diffDays = Math.floor(diffMs / 86400000); // days
                        var diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
                        var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); // minutes
                        if (diffDays > 0) {
                            comment_time = diffDays + "d";
                        } else if (diffHrs > 0) {
                            comment_time = diffHrs + "h";
                        } else {
                            comment_time = diffMins + "m";
                        }
                          return (
                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 2,  borderColor: 'black'}}>

                                  <View style={{width: '20%', alignItems: 'center', padding: 10}}>

                                    <View style={{padding: 10}}>

                                    <Image style={{
                                        width: 45,
                                        height: 45,
                                        marginTop: 0,
                                        borderRadius: 23
                                    }} source={{
                                        uri: profile_image_url
                                    }} />


                                    </View>

                                  </View>

                                  <View style={{width: '65%', alignItems: 'flex-start'}}>

                                    <View style={{padding: 10, marginTop: 5}}>

                                    <Text style={{fontSize: 16, fontWeight: 'bold', color: 'white'}}>{comment.fetch_user_details[0].first_name} {comment.fetch_user_details[0].last_name}</Text>

                                    <Text style={{fontSize: 13, paddingRight: 15, paddingLeft:0, marginTop: 7, marginLeft: 0, fontWeight: 'bold', color: 'whitesmoke'}}>{comment.comment}</Text>

                                    </View>

                                  </View>

                                  <View style={{width: '15%', alignItems: 'flex-start'}}>

                                    <View style={{padding: 10, marginTop: 5}}>

                                    <Text style={{fontSize: 12, fontWeight: 'bold', color: 'black'}}>{comment_time}</Text>

                                    </View>

                                  </View>                                  
                            </View>
                          )
                      })}
                  </ScrollView>

                 </View>

              </View>

            }



          <View style={{flex:1, flexDirection: 'row', bottom: 0, position: 'absolute', backgroundColor: 'black', height: 100}}>
              <View style={{width: '75%', padding: 10}}>
                  <TextInput
                  placeholder="Add comment.."
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  placeholderTextColor='#626264'
                  keyboardShouldPersistTaps={'handled'}
                  style={{height: 80, color: 'white',backgroundColor:'#2d2e37', padding: 10, borderRadius:5}}
                  multiline = {true}
                  numberOfLines = {4}
                  maxLength = {90}
                  value={String(this.state.comment)}
                  onChangeText={ (text) => this.setState({
                      comment: text,
                  })}                  
                  />            
              </View> 
            <View style={{width: '25%', alignSelf: 'center'}}>
              <TouchableOpacity onPress = {() => this.addcomment(this.state.workout_id, this.state.course_id)}>
                <View style={{width: 75, backgroundColor: '#ff7200', padding: 10, borderRadius: 20}}><Text style={{color: 'white', textAlign: 'center'}}>POST</Text></View>
              </TouchableOpacity>
            </View>
          </View>
      </View>
      </KeyboardAwareScrollView>
    );
  }
}