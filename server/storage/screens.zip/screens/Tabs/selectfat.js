import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator, Picker, DatePickerIOS } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from '../signup/styles.js';
import moment from "moment";

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
import { request } from 'graphql-request'

const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');


export default class EditFat extends Component {

    constructor(props) {
        super(props);
        this.state = {
            body_fat: null
        };
    }

    setHeight = async () => {

        const {navigate} = this.props.navigation;

        let USER_ID = await AsyncStorage.getItem("USER_ID");        

            var query = `mutation 
                            edit_profile_details1(
                                $body_fat: Int!, 
                                $id: Int!                                
                                ){
                                edit_profile_details1(
                                    id: $id, 
                                    body_fat: $body_fat
                                ) {
                                    status
                                }

                            }`;                                 


            var variables = {
                id: Number(USER_ID),
                body_fat: Number(this.state.body_fat),
            }

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {

                        if (data.edit_profile_details1[0].status == 'success') {
                            alert('Profile details updated')
                            navigate("ProfileDetails")
                            }
                        }
                    )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                      }
                    )


    }

    backStep = () => {

        const {navigate} = this.props.navigation;

        var {body_fat} = this.props.navigation.state.params;

        navigate("ProfileDetails")

    }


    componentWillMount() {

        var {body_fat} = this.props.navigation.state.params;

        this.setState({body_fat: body_fat})



    }



    render() {
        const {navigate} = this.props.navigation;

        payments = []

        for (let i = 0; i <= 30; i++) {

            sys = '%'

            payments.push(
                <Picker.Item label={i.toString() + ' ' + sys} value={i.toString()} color="#fff"/>
            )
        }
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => this.backStep()}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Add Fat
            </Text>
          </View>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
            <View style={{
                    width: width
                }}>
              <Picker
                selectedValue={this.state.body_fat}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    body_fat: itemValue
                })}>
                {payments}
              </Picker>
            </View>  
            </View>
            
          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.setHeight()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>            

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
