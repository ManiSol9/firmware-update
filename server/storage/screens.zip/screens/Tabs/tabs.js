import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, AsyncStorage, TouchableOpacity, TextInput } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { TabNavigator } from 'react-navigation';
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';

import styles from './styles.js';
import Profile_Data from './profile_data.js';
import Feed from './feed.js';
import More from './more.js'
import Notification from './notification.js';
import ConnectToBle from '../Landing/connecttoble.js'
import SearchDevices from '../Landing/searchdevices.js';
import FinishExercise from '../finishexercise.js';
import Courses from '../Courses/courses.js';

import { request } from 'graphql-request'


export default class Tabs extends Component<{}> {
    constructor(props) {
        super(props);
        this.state = {
            workouts: [],
            loader: null,
            showProfile: null,
            showFeed: true,
            showNotification: null,
            showMore: null,
            notification_count: 0
        };
    }
    async componentWillMount() {
        console.log('tabs')

        if(this.props.navigation.state.params) {

            const { showProfile, showFeed, showNotification, showMore} = this.props.navigation.state.params

            this.setState({showProfile: showProfile, showFeed: showFeed, showNotification: showNotification, showMore: showMore})

        }

        let PROFILE_IMAGE = await AsyncStorage.getItem("PROFILE_IMAGE");

        let USER_ID = await AsyncStorage.getItem("USER_ID");

        if(PROFILE_IMAGE != '') {
            this.state.upload_uri = PROFILE_IMAGE
        }else{
            this.state.upload_uri = String("https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg")
        }

        this.setInterval(() => {

           // this.checkNotification(USER_ID)

        }, 10000);
    }

    checkNotification = (USER_ID) => {

        const query = `query mobile_notification($user_id: Int!){
                          mobile_notification(user_id:$user_id){
                            message
                            status
                            
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }                

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/mobile_notification', query, varibales)
            .then(async data => {
              console.log(data)
        
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )

    }

    route(routeName) {
        const {navigate} = this.props.navigation;
        this.setState({})
        navigate(routeName)
    }
    render() {
        const {navigation} = this.props;
        const {showFeed, showMore, showNotification, showProfile, notification_count} = this.state;
        return (
            <View style={styles.upcomingWorkouts_main_body} >
        {showProfile ? <Profile_Data from={'tabs'} navigation={navigation}/> : null}
        {showNotification ? <Notification /> : null}
        {showFeed ? <Feed from={'tabs'} navigation={navigation} /> : null}
        {showMore ? <More navigation={navigation}/> : null}
        <View style={styles.btm_tabNavigation}>
          <TouchableOpacity
            style={showFeed ? styles.btm_menu_each_active : styles.btm_menu_each }
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: false,
                    showNotification: false,
                    showFeed: true
                });
            }}>
            <Image style={{
                width: 32,
                height: 28,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'feedicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              FEED
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={showProfile ? styles.btm_menu_each_active : styles.btm_menu_each }
            activeOpacity={1}
            onPress={() => {
                this.setState({
                    showProfile: true,
                    showMore: false,
                    showNotification: false,
                    showFeed: false
                });
            }}>
            <Image style={{
                width: 32,
                height: 32,
                top: 1,
                position: 'absolute'
            }} source={{
                uri: 'profileicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              PROFILE
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.btm_menu_each }
            activeOpacity={1} onPress={() => {
                this.route('UpcomingWorkouts');
            }}>
            <Image style={{
                width: 45,
                height: 45,
                marginTop: 0,
                marginBottom: 4
            }} source={{
                uri: 'bottom_tab_middlelogo_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 0
            }}> </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={showNotification ? styles.btm_menu_each_active : styles.btm_menu_each }
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: false,
                    showNotification: true,
                    showFeed: false
                });
            }}>{notification_count == 1 ? <View style={{backgroundColor: '#ff7200', borderRadius: 12, width: 24, height: 24, marginLeft: 20, marginTop: -20}}>
                    <Text style={{fontSize: 16, marginTop: 3, color: 'white', textAlign: 'center', backgroundColor: 'transparent'}}>{this.state.notification_count}</Text>
                </View> : <View style={{width: 24, height: 24, marginLeft: 20, marginTop: -20}}></View> }
            <Image style={{
                width: 28,
                height: 31,
                top: 2,
                position: 'absolute'
            }} source={{
                uri: 'notificationicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 20
            }}>
              NOTIFICATION
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={showMore ? styles.btm_menu_each_active : styles.btm_menu_each }
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: true,
                    showNotification: false,
                    showFeed: false
                });
            }}>
            <Image  style={{
                width: 32,
                height: 32,
                top: 1,
                position: 'absolute'
            }}  source={{
                uri: 'btnmenuicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              MORE
            </Text>
          </TouchableOpacity>
        </View>
      </View>
        );
    }
}


reactMixin(Tabs.prototype, TimerMixin);
