import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator, Picker, DatePickerIOS } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import styles from '../signup/styles.js';
import moment from "moment";

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

const {height, width} = Dimensions.get('window');

import { request } from 'graphql-request'


const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');


export default class EditWeight extends Component {

    constructor(props) {
        super(props);
        this.state = {
            weight: null,
            system: 0,
            weight_in_kgs: null
        };
    }

    componentWillMount() {

        var {feet, inches, weight, system, weight_in_kgs, height_in_metric} = this.props.navigation.state.params;

        console.log(this.props.navigation.state.params)

        if (feet != null) {
            this.setState({
                feet: feet
            })
        }

        if (inches != null) {
            this.setState({
                inches: inches
            })
        }

        if (!!weight) {
            console.log('gnvn')
            this.setState({
                weight: weight
            },()=>console.log(this.state.weight,"kkvbkv"))
        }

        if (system != null) {
            this.setState({
                system: system
            })
        }

        if (height_in_metric != null) {
            this.setState({
                height_in_metric: height_in_metric
            })
        }

        if (weight_in_kgs != null) {
            this.setState({
                weight_in_kgs: weight_in_kgs
            })
        }

        console.log(this.state.weight)

    }

    nextStep = async () => {

        var {weight_in_kgs, weight} = this.state

        if (weight_in_kgs > 0 || weight > 0) {

            const {navigate} = this.props.navigation;

        let USER_ID = await AsyncStorage.getItem("USER_ID");        

        if(this.state.system == 1) {

            var query = `mutation 
                            edit_profile_details1(
                                $present_weight_in_lbs: Int!,
                                $id: Int!                                
                                ){
                                edit_profile_details1(
                                    id: $id, 
                                    present_weight_in_lbs: $present_weight_in_lbs, 
                                ) {
                                    status
                                }

                            }`;                                 


            var variables = {
                id: Number(USER_ID),
                present_weight_in_lbs: Number(weight),
            }

        } else {

            var query = `mutation 
                            edit_profile_details1(
                                $present_weight_in_kgs: Int!,
                                $id: Int!                                
                                ){
                                edit_profile_details1(
                                    id: $id, 
                                    present_weight_in_kgs: $present_weight_in_kgs, 
                                ) {
                                    status
                                }

                            }`;                                 


            var variables = {
                id: Number(USER_ID),
                present_weight_in_kgs: Number(weight_in_kgs),
            }

        }

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {

                        if (data.edit_profile_details1[0].status == 'success') {
                            alert('Profile details updated')

                            const {navigate} = this.props.navigation;
                            
                            navigate("ProfileDetails")

                            }
                        }
                    )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                      }
                    )

        } else {
            alert('Please select valid weight')
        }
    }

    backStep = () => {

        const {navigate} = this.props.navigation;

        navigate("ProfileDetails")

    }

    render() {

        var payments = [];

        var {system} = this.props.navigation.state.params;

        for (let i = 0; i < 300; i++) {

            if (system == 2) {
                var sys = 'Kg'
            } else {
                sys = 'lb'
            }

            payments.push(
                <Picker.Item label={i.toString() + ' ' + sys} value={i.toString()} color="#fff"/>
            )
        }

        const {navigate} = this.props.navigation;
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => this.backStep()}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Select Weight
            </Text>
          </View>

          {this.state.system == 1 ?
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
            <View style={{
                    width: width - 100
                }}>
              <Picker
                selectedValue={this.state.weight}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    weight: itemValue
                })}>
                {payments}
              </Picker>
            </View>  
            <View style={{
                    width: 100
                }}>
              <Picker
                selectedValue={this.state.system}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    system: itemValue
                })}>
                <Picker.Item label="Imperial" value="1" color="#fff"/>
              </Picker>
            </View>                   
          </View>
                :
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
            <View style={{
                    width: width - 100
                }}>
              <Picker
                selectedValue={this.state.weight_in_kgs}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    weight_in_kgs: itemValue
                })}>
                {payments}
              </Picker>
            </View>  
            <View style={{
                    width: 100
                }}>
              <Picker
                selectedValue={this.state.system}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    system: itemValue
                })}>
                <Picker.Item label="Metric" value="1" color="#fff"/>
              </Picker>
            </View>                   
          </View>
            } 

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.nextStep()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>            

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
