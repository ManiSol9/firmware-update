import React, { Component } from 'react';
import { 
  AppRegistry, 
  FlatList, 
  StyleSheet,
  TextInput, 
  Picker, 
  ScrollView, 
  TouchableOpacity, 
  Text, 
  Image,
  KeyboardAvoidingView, 
  View, 
  TouchableHighlight, 
  ToastAndroid, 
  Alert,
  ActivityIndicator,
  TouchableWithoutFeedback,
  Keyboard 
} from 'react-native';
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';

import { AsyncStorage } from "react-native";
import {RadioGroup, RadioButton} from 'react-native-flexi-radio-button';

import Toast, {DURATION} from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

import PhotoUpload from 'react-native-photo-upload'
import axios from 'axios';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import styles from '../Landing/styles.js';
export default class UploadSuucess extends Component {

    constructor(props) {
      super(props);
  }
  componentWillMount(){


    var { userid, image_url } = this.props.navigation.state.params;    

    json = {"id": 767, "profile_img_url": image_url}

    console.log(json)

    axios.put(API.UpdateProfile, json)
      .then(function(response){
        console.log(response);
        if(response.status==200){
          console.log('ssadasdasdasdasdadasda')
        }else{
          console.log('vsvvcvcxvxvcvxcvxvxcvcx')
        }
    }).catch((error)=>{
      console.log('err in catch',error)
    })

  }



  render() {

    return (
      <View style={styles.mainBody}>
        <StatusBarBackground style={{backgroundColor:'#FF7E00'}}/>
        <Text>Upload Completed</Text>
      </View>
    );
  }
}

module.exports = UploadSuucess;
