import React, { Component } from 'react';
import { Platform, StyleSheet, ActivityIndicator, Text, View, Switch, Image, Alert, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, ToastAndroid, Keyboard, Dimensions } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js';
import axios from 'axios';
import styles from './styles.js'
var {width, height} = Dimensions.get('window');
import StatusBarBackground from '../../screens/Tabs/statusbar.js'
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';
import { addToSQLiteTable } from '../../template/SQLiteOperationsOffline.js';
import { addAsyncStorage } from '../../../config/auth.js'
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon from 'react-native-vector-icons/Ionicons';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';
import moment from "moment";

import { request } from 'graphql-request'


export default class CalendarView extends Component {

    constructor(props) {
        super(props);
        this.state = {
            token: '',
            initNotif: '', average: 0,
            obj: {}, past: {}, future: {}, completed: {}, contentLoader: true
        };
    }


    async componentWillMount() {
        console.log("--Landed--")

        let USER_ID = await AsyncStorage.getItem("USER_ID");

        this.futurecalendar(USER_ID)
        this.uncompletedcalender(USER_ID)
        this.completedcalender(USER_ID)
        this.average(USER_ID)

        this.setTimeout(() => {

            console.log('asdasdasd')

            this.checkstate(this.state.connected)

        }, 2000);

    }

    checkstate = () => {

      this.setState({contentLoader: false})

    }

    average = (USER_ID) => {

        const query = `query workout_status($user_id: Int!){
                          workout_status(user_id:$user_id){
                            status
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/workout_calender', query, varibales)
            .then(async data => {
              console.log(data)
              this.setState({average: data.workout_status[0].status})                            
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )

    }

    uncompletedcalender = (USER_ID) => {

        const query = `query uncompleted_workout($user_id: Int!){
                          uncompleted_workout(user_id: $user_id){
                            date
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }                

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/workout_calender', query, varibales)
            .then(async data => {
              console.log(data)
              uncompleted_workouts = data.uncompleted_workout
              var past = {};
              var date = {};
              console.log(uncompleted_workouts)
              for(i=0;i<uncompleted_workouts.length;i++){
                var key = uncompleted_workouts[i].date,
                date = {
                        [key]: {startingDay: true, color: '#ff7200', endingDay: true}
                };

                past = Object.assign(past, date);
              }

              var date1 = {};

              var todayDate = moment().format("YYYY-MM-DD");

              date1 = {
                [todayDate] : {startingDay: true, color: '#CC3299', endingDay: true}
              } 

              past = Object.assign(past, date1);

              this.setState({past: past})
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )


    }

    futurecalendar = (USER_ID) => {

        const query = `query future_workout($user_id: Int!){
                          future_workout(user_id: $user_id){
                            date
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/workout_calender', query, varibales)
            .then(async data => {
              console.log(data)
              future_workouts = data.future_workout
              var future = {};
              data = {}
              console.log(future_workouts)
              for(i=0;i<future_workouts.length;i++){
                var key = future_workouts[i].date,
                date = {
                        [key]: {startingDay: true, color: '#4D4DFF', endingDay: true}
                };

                future = Object.assign(future, date);
              }

              this.setState({future: future})                            
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )


    }

    completedcalender = (USER_ID) => {

        const query = `query completed_workout($user_id: Int!){
                          completed_workout(user_id: $user_id){
                            date
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/workout_calender', query, varibales)
            .then(async data => {
              console.log(data)
              completed_workouts = data.completed_workout
              var completed = {};
              var date = {};
              console.log(completed_workouts)
              for(i=0;i<completed_workouts.length;i++){
                var key = completed_workouts[i].date,
                date = {
                        [key]: {startingDay: true, color: '#05971D', endingDay: true}
                };

                completed = Object.assign(completed, date);
              }
              this.setState({completed: completed})              
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )

    }


    render() {
        const {navigate} = this.props.navigation;
        const {container} = style;

        const { contentLoader } = this.state

        var data = {}

        data = Object.assign(this.state.past, this.state.completed, this.state.future);

        console.log(data)

        return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

                  <View style={style.body}>
                    <View style={{height: 200, backgroundColor: '#000',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: 50,padding: 10}}>
                              <TouchableOpacity onPress={() => {
                                  const {navigate} = this.props.navigation;
                                  navigate("Tabs", {showProfile: null,showFeed: null,showNotification: null,showMore: true})
                              }}>
                                    <FontAwesome name="chevron-left" size={23} color="#FF7E00"   />
                                </TouchableOpacity>                            
                            </View>
                            <View style={{width: width-50,padding: 10, marginLeft: '-7%'}}>
                                <Text style={{ color: '#fff', position: 'relative',fontWeight: 'bold', fontSize: 18, textAlign: 'center'}}>Menu</Text>
                            </View>
                        </View>

                        </View>

                        <View style={{padding: 20,bottom: 0, top: '15%'}}>

                       <Text style={{fontSize: 30, color: '#fff', fontWeight: 'bold'}}>Workout calendar</Text>
                       <Text style={{fontSize: 10, color: '#ff7200', paddingTop: 10, fontWeight: 'bold'}}>CONSESTENCY IS REFUSING TO GIVE UP!</Text>
                        </View>

                        <View style={{padding: 20}}>

                       <Text style={{fontSize: 35, color: '#fff', fontWeight: 'bold'}}>{this.state.average}</Text>
                       <View style={{borderBottomWidth: 2, borderColor: '#ff7200', width: 50}}></View>
                       <Text style={{fontSize: 10, color: '#fff', paddingTop: 5, fontWeight: 'bold'}}>AVERAGE</Text>

                        </View>


                    </View>
  

                    <View style={{marginTop: 10, flex: 1}}>

                    {contentLoader ?
                      <ActivityIndicator
                      animating = {this.state.contentLoader}
                      color = '#bc2b78'
                      size = "large"
                      style = {styles.activityIndicator}
                      />
                      :
                      <CalendarList
                          // Callback which gets executed when visible months change in scroll view. Default = undefined
                          onVisibleMonthsChange={(months) => {console.log('now these months are visible', months);}}
                          // Max amount of months allowed to scroll to the past. Default = 50
                          pastScrollRange={1}
                          // Max amount of months allowed to scroll to the future. Default = 50
                          futureScrollRange={1}
                          // Enable or disable scrolling of calendar list
                          scrollEnabled={true}
                          // Enable or disable vertical scroll indicator. Default = false
                          showScrollIndicator={true}

                          markedDates={data}
                          // Date marking style [simple/period/multi-dot]. Default = 'simple'
                          markingType={'period'}

                        />

                    }
                    </View>

                    </View>

            </View>
        );
    }
}

reactMixin(CalendarView.prototype, TimerMixin);


const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#2d2e37',
        flex:1,
        marginTop: 0
    }
});