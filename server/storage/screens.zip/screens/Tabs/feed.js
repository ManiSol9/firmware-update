import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView,  ScrollView, TouchableHighlight, TouchableOpacity, AsyncStorage, ActivityIndicator } from 'react-native';

import Carousel, { Pagination, ParallaxImage } from 'react-native-snap-carousel';
import { ApolloProvider, graphql, createNetworkInterface, ApolloClient } from 'react-apollo'
import gql from 'graphql-tag'

import { NavigationActions } from 'react-navigation';

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'

import { LineChart, YAxis } from 'react-native-svg-charts'
import { LinearGradient, Stop } from 'react-native-svg'

import * as shape from 'd3-shape'
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import moment from "moment";

import StatusBarBackground from './statusbar.js'


import { sliderWidth, itemWidth } from '../slider/SliderEntry.style';
import SliderEntry from '../slider/SliderEntry';
import styles1, { colors } from '../slider/index.style';
import { ENTRIES1, ENTRIES2 } from '../slider/entries';
import { scrollInterpolators, animatedStyles } from '../slider/animations';

const IS_ANDROID = Platform.OS === 'android';
const SLIDER_1_FIRST_ITEM = 1;

import Icon from 'react-native-vector-icons/Foundation';
import Comment from 'react-native-vector-icons/MaterialCommunityIcons';

import styles from './styles.js'
const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

function wp(percentage) {
    const value = (percentage * viewportWidth) / 100;
    return Math.round(value);
}

import { request } from 'graphql-request'



export default class FeedApp extends Component<{}> {
    constructor(props) {
        super(props);
        this.state = {
            width: 0,
            height: 0,
            user: {
                id: '',
                name: ''
            },
            slider1Ref: null,
            slider1ActiveSlide: 1,
            feeds: [],
            loader: true,
            data: null,
            navigation: null,
            liked: 0,
            likeworkoutid: 0
        };
    }

    async componentWillMount() {
        console.log('hihi')
        var state = this.state;
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        let USER_NAME = await AsyncStorage.getItem("USER_NAME");

        this.setState({navigation: this.props.navigation})

        state.user.id = USER_ID;
        state.user.name = USER_NAME;
        this.setState(state, () => {
            console.log(this.state.user)
        });

        console.log(this.props.navigation.state.params)

        this._getFeed(this.state.user.id)

    }

    async componentWillReceiveProps(nextProps) {
        //console.log('props', nextProps)
        //console.log('nextProps', nextProps.data.loading)

   
    }


    _getFeed=(id) => {


                this.setState({
                    Loader: true,
                    contentLoader: true
                })        

       const query = `query course_to_user($student_id: Int!){
                          course_to_user(student_id: $student_id){
                            student_id
                            course_id
                            user_detail{
                              id
                              first_name
                              middle_name
                              last_name
                              username
                              profile_image_url
                              activity_log{
                                id
                                title
                                date_completed
                                date_created
                                workout_type
                                heart_rates
                                activity_image_url
                                fetch_count_like_day{
                                  day
                                  
                                  
                                }
                                fetch_count_like1{
                                  workout_owner_id
                                  
                                  
                                }
                                fetch_count_like_for_activity{
                                  count
                                }
                                fetch_count_comment_for_activity{
                                  count
                                }
                                fetch_count_comment1{
                                  user_id
                              
                                }
                                fetch_count_comment_day{
                                  day
                              
                                }
                              }
                            }
                            workout_to_user{
                              workout_id
                              user_id
                              course_id
                              day
                              completion_date
                              workout{
                                id
                                title
                                thumbnail_url
                                intensity
                              }
                              sensor_data{
                                avg_heart_rate
                                exercise_id
                              }
                              fetch_count_like_day1{
                                  day
                                  
                                  
                                }
                              fetch_count_like{
                                workout_owner_id
                              }
                              fetch_count_comment{
                                user_id
                              }
                              fetch_count_like_for_workout{
                                count
                              }
                              fetch_count_comment_for_workout{
                                count
                              }
                              fetch_count_comment_day1{
                                  day
                              
                                }
                            }
                          }
                        }`;

        const variables = {
            student_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/feed_api', query, variables)
            .then(async data => {
 
                this.setState({data: data})

                this.setState({
                    Loader: true,
                    contentLoader: true
                })

                console.log(data)

                this._totalFeed(data)

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )


    }


    _totalFeed = (response) => {


        feed = response.course_to_user

        var workout_date = ''

        var activity_date = ''

        //console.log(feed)

        array = []

        for (i = 0; i < feed.length; i++) {

            if(feed.length) {

            feed_user = feed[i].user_detail[0]

            //console.log(feed_user)

            activity_data = feed_user.activity_log
            workout_data = feed[i].workout_to_user


            if (activity_data.length) {
                latest_actvivty_date = activity_data[0].date_completed

                activity_date = new Date(latest_actvivty_date);
            }
            if (workout_data.length) {
                workout_activity_date = workout_data[0].completion_date

                workout_date = new Date(workout_activity_date);

            }

            if (workout_date != '' && activity_date != '') {
                if (workout_date > activity_date) {

                    user_date = workout_date

                } else {

                    user_date = activity_date

                }
            } else if (workout_date == '') {
                user_date = activity_date
            } else {
                user_date = workout_date
            }

            array.push([user_date, feed[i], feed[i].student_id, feed[i].course_id])

            }

        }

        array.sort(function(a, b) {
            var dateA = new Date(b[0]),
                dateB = new Date(a[0]);
            return dateA - dateB;
        });


        

        var arr = []
        var totaldata = []
        var feeddata = []

        //console.log(array)

        for (i = 0; i < array.length; i++) {
            user_detail = array[i][1].user_detail

            userwrokout_data = array[i][1].workout_to_user
            useractivity_data = user_detail[0].activity_log

            

            for (j = 0; j < userwrokout_data.length; j++) {
                userexcierce_data = userwrokout_data[j].workout;


                //arr.push([users[i].user_id, users[i].name,userwrokout_data[j].title,userwrokout_data[j].completion_date,userwrokout_data[j].thumbnail_url,userwrokout_data[j].intensity,userexcierce_data[0].avg_heart_rate])
                arr["user_id"] = array[i][2];
                arr["course_id"] = array[i][3];
                arr["name"] = user_detail[0].first_name
                arr["title"] = userexcierce_data[0].title
                arr["completion_date"] = userwrokout_data[j].completion_date
                arr["thumbnail_url"] = userexcierce_data[0].thumbnail_url
                arr["intensity"] = userexcierce_data[0].intensity
                arr["id"] = userwrokout_data[j].workout_id
                arr["likes"] = userwrokout_data[j].fetch_count_like_for_workout[0].count
                arr["comments"] = userwrokout_data[j].fetch_count_comment_for_workout[0].count
                //arr["userliked"] = userwrokout_data[j].fetch_count_like[0].user_id

                users = userwrokout_data[j].fetch_count_like[0].workout_owner_id

                if(users.length > 0) {
                    var value = users.indexOf(Number(this.state.user.id));
                    if(value < 0) {
                        arr["userliked"] = 0
                    } else {
                        arr["userliked"] = 1
                    }
                }

                //arr["usercommented"] = userwrokout_data[j].fetch_count_comment[0].count
                
                comments = userwrokout_data[j].fetch_count_comment[0].user_id

                if(comments.length > 0) {
                    var value = comments.indexOf(Number(this.state.user.id));
                    if(value < 0) {
                        arr["usercommented"] = 0
                    } else {
                        arr["usercommented"] = 1
                    }
                }

                if(userwrokout_data[j].fetch_count_like_day1.length) {
                arr["day"] = userwrokout_data[j].fetch_count_like_day1[0].day
                } else {
                arr["day"] = 0
                }


                if(userwrokout_data[j].sensor_data.length){
                arr["heartrate"] = userwrokout_data[j].sensor_data[0].avg_heart_rate

                } else {
                 arr["heartrate"] = []
                }

                arr["completed_date"] = userwrokout_data[j].completion_date

                if (user_detail[0].profile_img_url == null) {
                    arr["profile_img_url"] = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
                } else {
                    arr["profile_img_url"] = user_detail[0].profile_image_url
                }



                var today = new Date();
                var Christmas = new Date(userwrokout_data[j].completion_date);
                var diffMs = (today - Christmas); // milliseconds between now & Christmas
                var diffDays = Math.floor(diffMs / 86400000); // days
                var diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
                var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); // minutes
                if (diffDays > 0) {
                    arr["completion_date"] = diffDays + " days ago";
                } else if (diffHrs > 0) {
                    arr["completion_date"] = diffHrs + " hours ago";
                } else {
                    arr["completion_date"] = diffMins + " minutes ago";
                }
                var obj = {
                    "user_id": arr["user_id"],
                    "name": arr["name"],
                    "title": arr["title"],
                    "completion_date": arr["completion_date"],
                    "thumbnail_url": arr["thumbnail_url"],
                    "intensity": arr["intensity"],
                    "heartrate": arr["heartrate"],
                    "completed_date": arr["completed_date"],
                    "profile_img_url": arr["profile_img_url"],
                    "workout_id": arr["id"],
                    "likes": arr["likes"],
                    "comments": arr["comments"],
                    "liked": arr["userliked"],
                    "commented": arr["usercommented"],
                    "day": arr["day"],
                    "course_id": arr["course_id"]                    
                };
                feeddata.push(obj)
                arr = []

            }
            for (j = 0; j < useractivity_data.length; j++) {
                //arr.push([users[i].user_id, users[i].name,useractivity_data[j].title,useractivity_data[j].completed_on,'','',''])
                arr["user_id"] = array[i][2];
                arr["course_id"] = 0;
                arr["name"] = user_detail[0].first_name
                arr["title"] = useractivity_data[j].title
                arr["completion_date"] = useractivity_data[j].date_completed

                if(useractivity_data[j].activity_image_url == null){
                    arr["thumbnail_url"] = 'https://cdn-resoltz-assets.azureedge.net/content/images/corporate/onepage/classes-4.jpg'
                } else {
                    arr["thumbnail_url"] = useractivity_data[j].activity_image_url        
                }
                arr["intensity"] = '0'
                arr["heartrate"] = useractivity_data[j].heart_rates
                arr["completed_date"] = useractivity_data[j].date_completed
                arr["id"] = useractivity_data[j].id
                arr["likes"] = useractivity_data[j].fetch_count_like_for_activity[0].count
                arr["comments"] = useractivity_data[j].fetch_count_comment_for_activity[0].count
                //arr["userliked"] = useractivity_data[j].fetch_count_like1[0].user_id
                
                users = useractivity_data[j].fetch_count_like1[0].workout_owner_id
                if(users.length > 0) {
                    var value = users.indexOf(Number(this.state.user.id));
                    if(value < 0) {
                        arr["userliked"] = 0
                    } else {
                        arr["userliked"] = 1
                    }
                }

                comments = useractivity_data[j].fetch_count_comment1[0].user_id

                if(comments.length > 0) {
                    var value = comments.indexOf(Number(this.state.user.id));
                    if(value < 0) {
                        arr["usercommented"] = 0
                    } else {
                        arr["usercommented"] = 1
                    }
                }


                //arr["usercommented"] = useractivity_data[j].fetch_count_comment1[0].count
                if(useractivity_data[j].fetch_count_like_day.length) {
                arr["day"] = useractivity_data[j].fetch_count_like_day[0].day
                } else {
                arr["day"] = 0
                }

                if (user_detail[0].profile_img_url == null) {
                    arr["profile_img_url"] = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
                } else {
                    arr["profile_img_url"] = user_detail[0].profile_image_url
                }


                var today = new Date();
                var Christmas = new Date(useractivity_data[j].date_completed);
                var diffMs = (today - Christmas); // milliseconds between now & Christmas
                var diffDays = Math.floor(diffMs / 86400000); // days
                var diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
                var diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); // minutes
                if (diffDays > 0) {
                    arr["completion_date"] = diffDays + " days ago";
                } else if (diffHrs > 0) {
                    arr["completion_date"] = diffHrs + " hours ago";
                } else {
                    arr["completion_date"] = diffMins + " minutes ago";
                }

                var obj = {};
                var len = arr.length;

                var obj = {
                    "user_id": arr["user_id"],
                    "name": arr["name"],
                    "title": arr["title"],
                    "completion_date": arr["completion_date"],
                    "thumbnail_url": arr["thumbnail_url"],
                    "intensity": arr["intensity"],
                    "heartrate": arr["heartrate"],
                    "completed_date": arr["completed_date"],
                    "profile_img_url": arr["profile_img_url"],
                    "workout_id": arr["id"],
                    "likes": arr["likes"],
                    "comments": arr["comments"],
                    "liked": arr["userliked"],
                    "commented": arr["usercommented"],
                    "day": arr["day"],
                    "course_id": arr["course_id"]
                };
                feeddata.push(obj)
                arr = []

            }

            

            feeddata.sort(function(a, b) {
                var dateA = new Date(b.completed_date),
                    dateB = new Date(a.completed_date)
                return dateA - dateB;
            });

            totaldata.push(['user' + i + '', feeddata])

            feeddata = []

            //break;

        }

        console.log(totaldata)

        this.setState({
            feeds: totaldata,
            loader: false
        })

                this.setState({
                    Loader: false,
                    contentLoader: false
                })


    }

    
    _refresh() {

        return new Promise((resolve) => {
            setTimeout(() => {
                resolve();
            }, 4000)
        })
    }

    _renderItem ({item, index}) {
        return <SliderEntry data={item} even={(index + 1) % 2 === 0} />;
    }

    comments = (value) => {
            const {navigate} = this.props.navigation;
            navigate("Comments")
    }

    Like = async (id, item, completion_date, workout_user_id, course_id, user_id) => {
        
        console.log(completion_date, 'date')
        
        total_feeds = this.state.feeds

        for(i=0;i<total_feeds.length;i++) {

            wrokouts = total_feeds[i][1]

                for(j=0;j<wrokouts.length;j++) {

                    single_workout = wrokouts[j]

                    console.log(single_workout,"sdasdads")

                    if(id == single_workout.workout_id && completion_date == single_workout.completed_date) {

                        likes = single_workout.likes + 1

                        wrokouts[j].likes = likes

                        wrokouts[j].liked = 1

                   const query = `mutation addlike($workout_id: Int!, $user_id:Int!, $like:Int!, $course_id:Int!, $start_date:String!, $workout_owner_id: Int!){
                                      addlike(workout_id:$workout_id, user_id:$user_id,like:$like,course_id:$course_id,start_date:$start_date, workout_owner_id: $workout_owner_id){
                                        day
                                      }
                                    }`;


                    date = completion_date.split("T")

                    const variables = {
                        workout_id: Number(id),
                        user_id: Number(workout_user_id),
                        like: Number(likes),
                        course_id: Number(course_id),
                        start_date: String(date[0]),
                        workout_owner_id: Number(user_id)
                    }

                    console.log(variables)

                    request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/like', query, variables)
                        .then(async data => {
                            console.log(data)
                            //wrokouts[j].day = data.addlike[0].day

                        }
                    )
                        .catch(async err => {
                            console.log(err)
                            alert("Something Went Wrong, Please try again later")
                            this.setState({
                                Loader: false,
                                contentLoader: false
                            })
                        }
                    )




                    }
            }
        }

    this.setState({feeds: total_feeds})

    }


    unLike = async (id, item, workout_user_id, user_id, day, course_id) => {

        console.log(course_id)

        total_feeds = this.state.feeds

        for(i=0;i<total_feeds.length;i++) {

            wrokouts = total_feeds[i][1]

                for(j=0;j<wrokouts.length;j++) {

                    single_workout = wrokouts[j]

                    if(id == single_workout.workout_id) {

                        likes = single_workout.likes - 1

                        wrokouts[j].likes = likes

                        wrokouts[j].liked = 0

                    }
            }
        }        

        this.setState({feeds: total_feeds})        

       const query = `mutation deletelike($workout_id: Int!, $user_id: Int!, $course_id: Int!, $day: Int!){
                          deletelike(workout_id: $workout_id, user_id: $user_id, course_id: $course_id, day: $day){
                            status
                          }
                        }`;

        const variables = {
            workout_id: Number(id),
            user_id: Number(user_id),
            day: Number(day),
            course_id: Number(course_id)
        }

        console.log(variables)

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/like', query, variables)
            .then(async data => {
                console.log(data)
            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

        

    }

    _renderItemWithParallax ({item, index}, parallaxProps) {

        //console.log(this.props.navigation)

        const { navigate } = this.props.navigation

        //console.log(item)


        heartrate = []
        high_heart_rate = ''
        if (item.heartrate) {
            heartrate = item.heartrate
            high_heart_rate = Math.max.apply(null, heartrate)
        } else {
            high_heart_rate = 0
        }
        const resizeMode = 'center';
        const text = 'This is some text inlaid in an <Image />';

        if (item.intensity < 5) {
            var level = "LOW"
        } else {
            var level = "HIGH"
        }

        return (
                <View>
                    <View style={styles.feed_img_mas}>
                      <Image style={{
                            width: 45,
                            height: 45,
                            marginTop: 15,
                            borderRadius: 23
                        }} source={{
                            uri: item.profile_img_url
                        }} />
                      <Text style={styles.feed_title1}>{item.name}</Text>
                      <View style={styles.feedrgt_mas}>
                        <Text style={styles.feedrgt1}>{item.title}</Text>
                        <Text style={styles.feedrgt2}>{item.completion_date}</Text>
                      </View>
                    </View>
                    <View>
                        <SliderEntry
                          data={item}
                          even={(index + 1) % 2 === 0}
                          parallax={true}
                          firstItem={0}
                          parallaxProps={parallaxProps}
                        />

                    {heartrate.length > 0 ? 
                      <LineChart
                        style={ {
                            height: 80,
                            opacity: 0.85,
                            backgroundColor: '#333333',
                            marginTop: -98,
                            width: '95.2%',
                            marginLeft: 8,
                            marginBottom: 20
                        }}
                        dataPoints={ heartrate }
                        renderGradient={ ({id}) => (
                            <LinearGradient id={ id } x1={ '0%' } y={ '0%' } x2={ '0%' } y2={ '100%' }>
                                <Stop offset={ '0%' } stopColor={ 'rgb(228, 35, 89)' } stopOpacity={ 0.8 }/>
                                <Stop offset={ '100%' } stopColor={ 'rgb(255, 156, 0)' } stopOpacity={ 0.9 }/>
                            </LinearGradient>
                        ) }
                      />

                      : <View></View>
                    }

                    </View>
                    <View style={{flex: 1, flexDirection: 'row', paddingLeft: 5}}>
                      <View style={{width: 180, flex: 1, flexDirection: 'row', height:50}}>
                        {item.liked == 1 ?
                        <TouchableOpacity onPress={() => this.unLike(item.workout_id, item, item.user_id, this.state.user.id, item.day, item.course_id)}>
                          <View style={{borderWidth: 1, width: 65, borderColor: '#FF7E00', padding: 5, borderRadius: 30, alignItems: 'center', backgroundColor: '#FF7E00'}}>
                            <Text style={{backgroundColor: 'transparent', fontSize: 16}}>
                              <Icon name="like" size={22} color="#FFF"   /> <Text style={{color: 'white', fontSize: 20, paddingLeft: 10, fontWeight: 'bold'}}>
                                    {item.likes}
                                </Text>
                            </Text>                      
                          </View>
                        </TouchableOpacity>                          
                        :
                        <TouchableOpacity onPress={() => this.Like(item.workout_id, item, item.completed_date, item.user_id, item.course_id, this.state.user.id)}>                        
                          <View style={{borderWidth: 1, width: 65, borderColor: '#FFF', padding: 5, borderRadius: 30, alignItems: 'center'}}>
                            <Text style={{backgroundColor: 'transparent', fontSize: 18}}>
                              <Icon name="like" size={23} color="#FFF"/>  <Text style={{color: 'white', fontSize: 20, paddingLeft: 10, fontWeight: 'bold'}}>
                                    {item.likes}
                                </Text>
                            </Text>                     
                          </View>
                        </TouchableOpacity>                                                    
                        }                          
                          <TouchableOpacity onPress={() => navigate("Comments", {workout_id: item.workout_id, course_id: item.course_id, student_id: item.user_id, start_date: item.completed_date})}>
                          {item.commented == 1?
                          <View style={{borderWidth: 1, width: 65, borderColor: '#FF7E00', padding: 5, borderRadius: 30, alignItems: 'center', marginLeft: 10, backgroundColor: '#FF7E00'}}>
                            <Text style={{backgroundColor: 'transparent'}}>
                            <Comment name="comment-processing-outline" size={18} color="#FFF"   /> <Text style={{color: 'white', fontSize: 20, fontWeight: 'bold', marginTop: 10}}> {item.comments}</Text>
                            </Text>                      
                          </View>
                          :
                          <View style={{borderWidth: 1, width: 65, borderColor: 'white', padding: 5, borderRadius: 30, alignItems: 'center', marginLeft: 10}}>
                            <Text style={{backgroundColor: 'transparent'}}>
                            <Comment name="comment-processing-outline" size={18} color="#FFF"   /> <Text style={{color: 'white', fontSize: 20, fontWeight: 'bold', marginTop: 10}}> {item.comments}</Text>
                            </Text>                      
                          </View>
                           }
                          </TouchableOpacity>                   
                      </View>
                      <View style={{width: 135, height: 50, alignItems: 'flex-end'}} >
                      </View>
                    </View>
                </View>  
            );
    }

    _renderLightItem ({item, index}) {
        return <SliderEntry data={item} even={false} />;
    }

    _renderDarkItem ({item, index}) {
        return <SliderEntry data={item} even={true} />;
    }

    mainExample (number, title, feed_data) {
        const { slider1ActiveSlide } = this.state;

        return (
            <View style={styles1.exampleContainer}>
                <Carousel
                  ref={c => this._slider1Ref = c}
                  data={feed_data}
                  renderItem={this._renderItemWithParallax.bind(this)}
                  sliderWidth={sliderWidth}
                  itemWidth={itemWidth}
                  hasParallaxImages={false}
                  firstItem={0}
                  inactiveSlideScale={1}
                  inactiveSlideOpacity={0.9}
                  inactiveSlideShift={0}
                  containerCustomStyle={styles1.slider}
                  contentContainerCustomStyle={styles1.sliderContentContainer}
                  loop={false}
                  loopClonesPerSide={1}
                  autoplay={false}
                  autoplayDelay={500}
                  autoplayInterval={3000}
                  onSnapToItem={(index) => this.setState({ slider1ActiveSlide: index }) }
                />

            </View>
        );
    }


    render() {

        const { navigate } = this.props.navigation;
        const {loader} = this.state;
        const resizeMode = 'center';
        const text = 'I am some centered text';

        console.log(loader)


        

        return (

            <View style={styles.mainBody} >

    <StatusBarBackground style={{
                backgroundColor: '#FF7E00'
            }}/>


                  <View style={styles.listofWrkouts1}>


                    <View style={styles.header}>
                          <Text style={styles.topSignupTxt}>
                            Feed
                          </Text>
                    </View>

                    <View>
                      <Text style = {styles.text_workout_heading}>
                        Hey {this.state.user.name}!
                      </Text>
                      <Text style = {styles.text_workout_sub_heading}>
                        REMAINDER TO STAY STRONG AND KEEP YOUR GOALS IN MIND
                      </Text>
                    </View>

                    <View style={styles.slidertop_btns}>
                      <View style={{
                flex: 1,
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center'
            }}>
                        <View style = {{
                flex: 0.28,
                alignItems: 'center',
                justifyContent: 'center',
            }}>
                        <TouchableOpacity>
                          <View style={styles.gradi_btns}>
                            <Text style={styles.gradi_NormalbtnsTxtBtn}>
                                Distance
                            </Text>
                            <View style={styles.gradiPagBtns}></View>
                          </View>
                        </TouchableOpacity>
                        </View>
                        <View style = {{
                flex: 0.28,
                alignItems: 'center',
                justifyContent: 'center',
            }}>
                        <TouchableOpacity>
                        <View style={styles.gradi_btns}>
                          <Text style={styles.gradi_NormalbtnsTxtBtn}>
                              Weights
                          </Text>
                          <View style={styles.gradiPagBtns}></View>
                        </View>
                        </TouchableOpacity>
                        </View>
                        <View style = {{
                flex: 0.28,
                alignItems: 'center',
                justifyContent: 'center',
            }}>
                        <TouchableOpacity>
                        <View style={styles.gradi_btns}>
                          <Text style={styles.gradi_btnsTxtBtn}>
                              Conditioning
                          </Text>
                          <Image style={{
                width: 86,
                height: 32
            }} source={{
                uri: 'gradi_btn'
            }} />
                          </View>
                        </TouchableOpacity>
                        </View>
                        <View style = {{
                                    flex: 0.16,
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}>
                          <TouchableOpacity onPress={() => navigate("Filter")}>
                              <View style = {{
                                            marginTop: 7
                                        }}>
                                <Feather name="sliders" size={25} color='#fff' />
                              </View>
                          </TouchableOpacity>

                        </View>

                      </View>
                    </View>
                  </View>


                  {loader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :

                <ScrollView
                style={{
                    flex: 1,
                    paddingBottom: 10,
                    marginBottom: 20
                }}
                contentContainerStyle={{
                    paddingBottom: 50
                }}
                indicatorStyle={'white'}
                scrollEventThrottle={200}
                directionalLockEnabled={true}
                >
                  {this.state.feeds.map((data1) => {
                    // console.log(data1)
                    //console.log(this.state.feeds)
                    const feed_data = data1[1]

                    const example1 = this.mainExample(1, 'Default layout', feed_data, this.props.navigation);

                    if (feed_data != '') {
                        return (
                            <View style={{
                                borderBottomWidth: 4
                            }}>

                            { example1 }

                          </View>
                        )
                    }
                }
                )}
                  </ScrollView>
            }
        <View style={styles.btm_tabNavigation}>
          <TouchableOpacity
            style = {{
                flex: 0.80,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: 60
            }}
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: false,
                    showNotification: false,
                    showFeed: true
                });
            }}>
            <Image style={{
                width: 32,
                height: 28,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'feedicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              FEED
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style = {{
                flex: 0.80,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: 60
            }}
            activeOpacity={1}
            onPress={() => {
                this.setState({
                    showProfile: true,
                    showMore: false,
                    showNotification: false,
                    showFeed: false
                });
            }}>
            <Image style={{
                width: 32,
                height: 32,
                top: 1,
                position: 'absolute'
            }} source={{
                uri: 'profileicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              PROFILE
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style = {{
                flex: 0.80,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: 60
            }}
            activeOpacity={1} onPress={() => {
                this.route('UpcomingWorkouts');
            }}>
            <Image style={{
                width: 45,
                height: 45,
                marginTop: 0,
                marginBottom: 4
            }} source={{
                uri: 'bottom_tab_middlelogo_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 0
            }}> </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style = {{
                flex: 0.80,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: 60
            }}
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: false,
                    showNotification: true,
                    showFeed: false
                });
            }}>
            <Image style={{
                width: 28,
                height: 31,
                top: 2,
                position: 'absolute'
            }} source={{
                uri: 'notificationicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              NOTIFICATION
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style = {{
                flex: 0.80,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                height: 60
            }}
            activeOpacity={1}onPress={() => {
                this.setState({
                    showProfile: false,
                    showMore: true,
                    showNotification: false,
                    showFeed: false
                });
            }}>
            <Image  style={{
                width: 32,
                height: 32,
                top: 1,
                position: 'absolute'
            }}  source={{
                uri: 'btnmenuicon_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 23
            }}>
              MORE
            </Text>
          </TouchableOpacity>
        </View>
    </View>

        );


    }
}
