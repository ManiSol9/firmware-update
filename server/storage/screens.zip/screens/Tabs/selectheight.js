import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator, Picker, DatePickerIOS } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from '../signup/styles.js';
import moment from "moment";

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
import { request } from 'graphql-request'

const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');


export default class EditHeight extends Component {

    constructor(props) {
        super(props);
        this.state = {
            feet: 1,
            inches: null,
            system: null,
            height_in_metric: null,
            weight: null,
            weight_in_kgs: null
        };
    }

    setHeight = async (feet, inches, system, height_in_metric) => {

        let USER_ID = await AsyncStorage.getItem("USER_ID");        

        if(system == 1) {

            var query = `mutation 
                            edit_profile_details1(
                                $present_height_in_feet: Int!, 
                                $present_height_in_inches: Int!,
                                $id: Int!                                
                                ){
                                edit_profile_details1(
                                    id: $id, 
                                    present_height_in_feet: $present_height_in_feet, 
                                    present_height_in_inches: $present_height_in_inches,
                                ) {
                                    status
                                }

                            }`;                                 


            var variables = {
                id: Number(USER_ID),
                present_height_in_inches: Number(inches),
                present_height_in_feet: Number(feet),
            }

        } else {

            var query = `mutation 
                            edit_profile_details1(
                                $id: Int!,
                                $present_height_in_meters: Int!
                                ){
                                edit_profile_details1(
                                    id: $id,
                                    present_height_in_meters: $present_height_in_meters 
                                ) {
                                    status
                                }

                            }`;                                 


            var variables = {
                id: Number(USER_ID),
                present_height_in_meters: Number(height_in_metric),
            }

        }

        console.log(variables)

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {

                        if (data.edit_profile_details1[0].status == 'success') {
                            alert('Profile details updated')
                    
                            const {navigate} = this.props.navigation;
                            
                            navigate("ProfileDetails")                    
                            
                            }
                        }
                    )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                      }
                    )


    }

    backStep = () => {

        const {navigate} = this.props.navigation;

        navigate("ProfileDetails")

    }


    componentWillMount() {

        var {feet, inches, weight, system, height_in_metric, weight_in_kgs} = this.props.navigation.state.params;

        if (feet != null) {
            this.setState({
                feet: feet
            })
        }

        if (inches != null) {
            this.setState({
                inches: inches
            })
        }

        if (weight != null) {
            this.setState({
                weight: weight
            })
        }

        if (weight_in_kgs != null) {
            this.setState({
                weight_in_kgs: weight_in_kgs
            })
        }

        if (system != null) {
            this.setState({
                system: system
            })
        } else {
            this.setState({
                system: 0
            })
        }

        if (height_in_metric != null) {
            this.setState({
                height_in_metric: height_in_metric
            })
        }

    }

    changeHeight = (itemvalue, itemIndex) => {

        var feet = parseInt(this.state.feet)

        if (itemIndex == 12) {

            if (feet < 12) {
                var feet = feet + 1
            } else {
                var feet = feet
            }
            this.setState({
                feet: feet.toString(),
                inches: 0
            })
        } else {
            this.setState({
                feet: feet.toString(),
                inches: itemvalue
            })
        }

    }


    render() {
        const {navigate} = this.props.navigation;

        var {system} = this.props.navigation.state.params;

        var payments = [];

        for (let i = 0; i < 300; i++) {

            if (system == 2) {
                var sys = 'cm'
            } else {
                var sys = ''
            }

            payments.push(
                <Picker.Item label={i.toString() + ' ' + sys} value={i.toString()} color="#fff"/>
            )
        }
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => this.backStep()}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Select height
            </Text>
          </View>

          {this.state.system == 1 ?
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
              <View style={{
                    width: width / 3
                }}>
                <Picker
                selectedValue={this.state.feet}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    feet: itemValue
                })
                }>
                  <Picker.Item label="1 feet" value="1" color="#fff"/>
                  <Picker.Item label="2 feet" value="2" color="#fff"/>
                  <Picker.Item label="3 feet" value="3" color="#fff"/>
                  <Picker.Item label="4 feet" value="4" color="#fff"/>
                  <Picker.Item label="5 feet" value="5" color="#fff"/>
                  <Picker.Item label="6 feet" value="6" color="#fff"/>
                  <Picker.Item label="7 feet" value="7" color="#fff"/>
                  <Picker.Item label="8 feet" value="8" color="#fff"/>
                  <Picker.Item label="9 feet" value="9" color="#fff"/>
                  <Picker.Item label="10 feet" value="10" color="#fff"/>
                  <Picker.Item label="11 feet" value="11" color="#fff"/>
                  <Picker.Item label="12 feet" value="12" color="#fff"/>
                </Picker>
              </View>
              <View style={{
                    width: width / 3
                }}>
                <Picker
                selectedValue={this.state.inches}
                onValueChange={(itemValue, itemIndex) => this.changeHeight(itemValue, itemIndex)}>
                  <Picker.Item label="0 inches" value="0" color="#fff" />                  
                  <Picker.Item label="1 inches" value="1" color="#fff" />
                  <Picker.Item label="2 inches" value="2" color="#fff"/>
                  <Picker.Item label="3 inches" value="3" color="#fff"/>
                  <Picker.Item label="4 inches" value="4" color="#fff"/>
                  <Picker.Item label="5 inches" value="5" color="#fff"/>
                  <Picker.Item label="6 inches" value="6" color="#fff"/>
                  <Picker.Item label="7 inches" value="7" color="#fff"/>
                  <Picker.Item label="8 inches" value="8" color="#fff"/>
                  <Picker.Item label="9 inches" value="9" color="#fff"/>
                  <Picker.Item label="10 inches" value="10" color="#fff"/>
                  <Picker.Item label="11 inches" value="11" color="#fff"/>
                  <Picker.Item label="" value="12" color="#fff"/>
                </Picker>
              </View>
              <View style={{
                    width: width / 3
                }}>
                <Picker
                selectedValue={this.state.system}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    system: itemValue
                })}>
                  <Picker.Item label="Imperial" value="1" color="#fff"/>
                </Picker>
              </View>
            </View>
                :
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
            <View style={{
                    width: width - 100
                }}>
              <Picker
                selectedValue={this.state.height_in_metric}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    height_in_metric: itemValue
                })}>
                {payments}
              </Picker>
            </View> 
            <View style={{
                    width: 100
                }}>
              <Picker
                selectedValue={this.state.system}
                onValueChange={(itemValue, itemIndex) => this.setState({
                    system: itemValue
                })}>
                <Picker.Item label="Metric" value="1" color="#fff"/>
              </Picker>
            </View> 
            </View>
            }                   
 

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.setHeight(this.state.feet, this.state.inches, this.state.system, this.state.height_in_metric, this.state.weight_in_kgs, this.state.weight)}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>            

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
