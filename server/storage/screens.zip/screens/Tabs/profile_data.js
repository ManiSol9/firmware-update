import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, ActivityIndicator, Image, AsyncStorage, Alert, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, ToastAndroid, Keyboard, Dimensions } from 'react-native';

import { onSignIn, isSignedIn, onSignOut, getAllAsyncStroage, removeBLE } from '../../../config/auth';
import styles from './styles.js'
var {width, height} = Dimensions.get('window');

import StatusBarBackground from '../../screens/Tabs/statusbar.js'
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon1 from 'react-native-vector-icons/SimpleLineIcons';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';

import Icon from 'react-native-vector-icons/FontAwesome';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { sliderWidth, itemWidth } from '../slider/SliderEntry.style';
import SliderEntry from '../slider/SliderEntry';
import GraphSlider from '../slider/graphslider';

import styles1, { colors } from '../slider/index.style';
//import { ENTRIES1, ENTRIES2 } from '../slider/entries';
import { scrollInterpolators, animatedStyles } from '../slider/animations';

const IS_ANDROID = Platform.OS === 'android';
const SLIDER_1_FIRST_ITEM = 1;

import Carousel from 'react-native-snap-carousel';

import { Grid, LineChart, XAxis, YAxis } from 'react-native-svg-charts'


import { request } from 'graphql-request'
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';


export default class Profile_Data extends Component {

  constructor(props) {
      super(props);
      this.state={
        tabs: 0,
        upload_uri:null,
        completedworkouts: [],
        loader_completedworkouts: true,
        listofstudents:[],
        studentslist:[],
        user_id: null,
        calories: 0,
        workout_hours: 0,
        workouts_completed: 0,
        load_date: true,
        grpahData: [],
        username: null,
        body_fat: 0,
        weight_inc: 0,
        activity_response: [],
        video_response:[],
        pageLoader: true,
        profile_image_url: "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
      }
  }
  async componentWillMount(){
    console.log(this.props)

        let USER_ID = await AsyncStorage.getItem("USER_ID");
        let USER_NAME = await AsyncStorage.getItem("USER_NAME");

        this.setState({username: USER_NAME})

        this.setState({user_id: USER_ID})

        this._getLatestworkouts(USER_ID)

        this._getleaderboard(USER_ID)

        this._getData(USER_ID)

        this._getMonth(USER_ID)

        this.setTimeout(() => {

            console.log('asdasdasd')

            this.checkstate(this.state.connected)

        }, 1000);

  }


  _getLatestworkouts = (id) => {

       const query =`query profile_data($user_id: Int!){
                      profile_data(user_id: $user_id)
                      {title
                      thumbnail_url}
                    }`

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_profile_data2', query, variables)
            .then(async data => {
 
                this.setState({completedworkouts: data.profile_data, loader_completedworkouts: false})

                console.log(data.profile_data)

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

  }


  _getleaderboard = (id) => {

       const query =`query course($user_id: Int!){
                      course(user_id: $user_id)
                     {course_id
                    user_detail{
                      student_id
                      profile_data{
                        id
                        username
                        workouts{
                          workouts_completed
                        }
                      }
                    }} 
                    }`

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_profile_data3', query, variables)
            .then(async data => {
              
                list = data.course

                studentslist = []

                studentids = []

                student_length = 0

                for(i=0;i<list.length;i++){

                  listofstudents = list[i].user_detail

                  for(j=0;j<listofstudents.length;j++){

                    studentids.push([listofstudents[j].student_id])
                    
                    studentslist.push([listofstudents[j].student_id, listofstudents[j].profile_data[0].workouts[0].workouts_completed, listofstudents[j].profile_data[0].username])
                    
                    student_length++

                  }

                }

                let output = studentslist.filter((value) => {
                  return !this[value] && (this[value] = true)
                }, Object.create(null))

                output.sort((a, b)=> a[1].toString().localeCompare(b[1].toString()))

                console.log(output)

                this.setState({studentslist: output})

            }
        )
            .catch(async err => {
                console.log(err)
                //alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

  }

  _getData = (id) => {

       const query =`query profile_data($user_id:Int!){profile_data(user_id: $user_id)
                      {calories
                      workouts_completed
                      workout_hours
                      current_weight_in_kgs
                      current_weight_in_lbs
                      present_weight_in_kgs
                      present_weight_in_lbs
                      body_fat
                      parameter_type
                      profile_image_url
                      first_name
                      last_name                      
                    }}`

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_profile_data', query, variables)
            .then(async data => {
              
                console.log(data)

                this.setState({
                    workouts_completed: data.profile_data[0].workouts_completed,
                    body_fat: data.profile_data[0].body_fat
                  })
                if(data.profile_data[0].profile_image_url) {
                  this.state.profile_image_url = data.profile_data[0].profile_image_url
                }
                if(data.profile_data[0].calories < 1000) {
                  this.setState({calories: data.profile_data[0].calories,})
                } else {
                  var calories = (data.profile_data[0].calories)/1000

                  var factor = Math.pow(10, 1);
                  calories = Math.round(calories * factor) / factor;

                  calories = calories +"k"
                  this.setState({calories: calories})
                }

                var num = data.profile_data[0].workout_hours;
                var hours = (num / 60);
                var rhours = Math.floor(hours);
                var minutes = (hours - rhours) * 60;
                var rminutes = Math.round(minutes);
                var result =  rhours + "." + rminutes;                

                this.setState({workout_hours: result})

                if (data.profile_data[0].parameter_type == 1) {

                  if(data.profile_data[0].present_weight_in_lbs == null) {
                    weight =  0
                  } else {
                    weight =  data.profile_data[0].present_weight_in_lbs - data.profile_data[0].current_weight_in_lbs
                  }

                } else {

                  if(data.profile_data[0].present_weight_in_kgs == null) {
                    weight =  0
                  } else {
                    weight =  data.profile_data[0].present_weight_in_kgs - data.profile_data[0].current_weight_in_kgs
                  }

                }

                this.setState({weight_inc: weight})

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

  }  


  _getMonth = (id) => {

        var activity_response = {}

        var video_response = {}

       const query1 =`query profile_graph_activity_workouts($user_id: Int!){
                      profile_graph_activity_workouts(user_id:$user_id){
                        month
                        year
                        monthly_length
                        week
                      }
                    }`

        const variables1 = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_graph', query1, variables1)
            .then(async data => {
              
               this.setState({activity_response:data.profile_graph_activity_workouts})

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false,
                    load_date: false
                })
            }
        )

       const query2 =`query profile_graph_video_workouts($user_id: Int!){
                      profile_graph_video_workouts(user_id: $user_id){
                        month
                        year
                        monthly_length
                        week
                      }
                    }`

        const variables2 = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_graph', query2, variables2)
            .then(async data => {
              
               this.setState({video_response:data.profile_graph_video_workouts})

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false,
                    load_date: false
                })
            }
        )

  }

  _renderItem ({item, index}) {
        return (
            <View style={styles.slide}>
                <Text style={styles.title}>{ item.title }</Text>
            </View>
        );
  }


  alert = () => {
        const {navigate} = this.props.navigation;
        
        navigate("ProfileDetails")
  }


    _renderItemWithParallax123 ({item, index}, parallaxProps) {


        const { navigate } = this.props.navigation

        var months = new Array( "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");

        return (

                              <View style={{width: '100%', borderWidth: 0,  borderColor: 'black'}}>

                                <View style={{padding: 0, marginTop: 0}}>

                                  <View>

                                    <View style={{ alignItems: 'center', padding: 5}}>

                                    <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold', textAlign: 'center'}}> {months[item.month-1]} {item.year} </Text>

                                    </View>

                                    <View style={{ alignItems: 'center', padding: 5}}>

                                    <Text style={{ color: '#fff', fontSize: 14, fontWeight: 'bold', textAlign: 'center'}}> NUMBER OF WORKOUTS </Text>

                                    </View>

                                    <View style={{ alignItems: 'center', padding: 10}}>

                                      <View style={{ alignItems: 'center', width: 60, padding: 5, borderWidth: 1, borderRadius: 20, borderColor: 'black'}}>

                                      <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold', textAlign: 'center'}}> {item.monthly_length} </Text>

                                      </View>

                                    </View>

                                      <View style={{marginTop: 20}}>
                                        
                                        <GraphSlider
                                          data={item}
                                          even={(index + 1) % 2 === 0}
                                          parallax={true}
                                          firstItem={0}
                                          parallaxProps={parallaxProps}
                                        />

                                      </View>                                   

                                  </View>

                                  <View>
                                 

                                  </View>                                  

                                </View>


                              </View>



            );
    }


    _renderItemWithParallax ({item, index}, parallaxProps) {

        //console.log(this.props.navigation)

        if(item.thumbnail_url == "") {

          item.thumbnail_url = "https://cdn-resoltz-assets.azureedge.net/content/images/corporate/onepage/classes-4.jpg"

        } 



        const { navigate } = this.props.navigation

        return (

                              <View style={{width: '100%', borderWidth: 0,  borderColor: 'black'}}>

                                <View style={{padding: 0, marginTop: 0}}>

                                  <View>

                                    <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold'}}> {item.title} </Text>

                                      <View style={{marginTop: 20}}>
                                        
                                        <SliderEntry
                                          data={item}
                                          even={(index + 1) % 2 === 0}
                                          parallax={true}
                                          firstItem={0}
                                          parallaxProps={parallaxProps}
                                        />

                                      </View>                                   

                                  </View>

                                  <View>
                                 

                                  </View>                                  

                                </View>


                              </View>



            );
    }

    _renderLightItem ({item, index}) {
        return <SliderEntry data={item} even={false} />;
    }

    _renderDarkItem ({item, index}) {
        return <SliderEntry data={item} even={true} />;
    }

    completedworkouts (number, title, feed_data) {
        const { slider1ActiveSlide } = this.state;

        return (
            <View style={styles1.exampleContainer}>
                <Carousel
                  ref={c => this._slider1Ref = c}
                  data={feed_data}
                  renderItem={this._renderItemWithParallax.bind(this)}
                  sliderWidth={sliderWidth}
                  itemWidth={itemWidth}
                  hasParallaxImages={false}
                  firstItem={0}
                  inactiveSlideScale={1}
                  inactiveSlideOpacity={0.9}
                  inactiveSlideShift={0}
                  containerCustomStyle={styles1.slider}
                  contentContainerCustomStyle={styles1.sliderContentContainer}
                  loop={false}
                  loopClonesPerSide={1}
                  autoplay={false}
                  autoplayDelay={500}
                  autoplayInterval={3000}
                  onSnapToItem={(index) => this.setState({ slider1ActiveSlide: index }) }
                />

            </View>
        );
    }

    monthscroll (number, title, feed_data) {
        const { slider1ActiveSlide } = this.state;

        return (
            <View style={styles1.exampleContainer}>
                <Carousel
                  ref={c => this._slider1Ref = c}
                  data={feed_data}
                  renderItem={this._renderItemWithParallax123.bind(this)}
                  sliderWidth={sliderWidth}
                  itemWidth={itemWidth}
                  hasParallaxImages={false}
                  firstItem={0}
                  inactiveSlideScale={1}
                  inactiveSlideOpacity={0.9}
                  inactiveSlideShift={0}
                  containerCustomStyle={styles1.slider}
                  contentContainerCustomStyle={styles1.sliderContentContainer}
                  loop={false}
                  loopClonesPerSide={1}
                  autoplay={false}
                  autoplayDelay={500}
                  autoplayInterval={3000}
                  onSnapToItem={(index) => this.setState({ slider1ActiveSlide: index }) }
                />

            </View>
        );
    }

    checkstate = () => {

      this.setState({pageLoader: false})

    }

  render() {
         
    console.log(this.state.completedworkouts)

    const completedworkouts = this.completedworkouts(1, 'Default layout', this.state.completedworkouts, this.props.navigation);

    const { activity_response, video_response } = this.state

    graph_data = {}

    month_data = []

    graph_data.week = []

    if(activity_response.length > 0 && video_response.length > 0) {

        for(i=0;i<5;i++){

          console.log(activity_response[i].month, "month")

          graph_data.month = activity_response[i].month

          graph_data.year = activity_response[i].year

          graph_data.monthly_length = activity_response[i].monthly_length + video_response[i].monthly_length

          graph_data.week[0] = activity_response[i].week[0] + video_response[i].week[0]

          graph_data.week[1] = activity_response[i].week[1] + video_response[i].week[1]

          graph_data.week[2] = activity_response[i].week[2] + video_response[i].week[2]

          graph_data.week[3] = activity_response[i].week[3] + video_response[i].week[3]

          graph_data.week[4] = activity_response[i].week[4] + video_response[i].week[4]

          month_data.push(graph_data)

          graph_data = {}

          graph_data.week = []

        }

    }

    if(month_data.length > 0 ) { this.state.load_date = false }

      console.log(month_data,"datara")

    const monthscroll = this.monthscroll(1, 'Default layout', month_data, this.props.navigation);

    return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

                  {this.state.pageLoader?
                        <ActivityIndicator
                        animating = {this.state.pageLoader}
                        color = '#bc2b78'
                        size = "large"
                        style = {styles.activityIndicator}
                        />
                        :
                  <View style={style.body}>
                    <View style={{height: 180, backgroundColor: '#000',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: width,padding: 10, }}>
                                <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>Profile</Text>
                            </View>

                        </View>

                        <TouchableOpacity onPress={()=> this.alert('CONTACT')}>
                        <View style={{flex: 1, flexDirection: 'row', bottom: '35%'}}>

                          <View style={{alignItems: 'flex-start', paddingLeft: 20}}>

                              <Image
                              style={{
                                  paddingVertical: 0,
                                  width: 100,
                                  height: 100,
                                  borderRadius: 50
                              }}
                              resizeMode='cover'
                              source={{
                                uri: this.state.profile_image_url
                              }}
                              />
                          </View>
                          <View style={{ padding: 20, bottom: 0}}>

                                  <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 28, textAlign: 'left'}}>{this.state.username}</Text>
                                  <Text style={{ color: '#ff7200', fontSize: 13, textAlign: 'left'}}>ARCHITECHUR MAYER</Text>

                          </View>
                        </View>
                        </TouchableOpacity>

                    </View>
  

                    <View style={{flex: 1, flexDirection: 'column', marginTop: 0, height: 600}}>

                        <ScrollView style={{flex: 1}}>

                          <View style={{flex: 1, marginTop: 0}}>
                          
                          {this.state.load_date?
                        <ActivityIndicator
                        animating = {this.state.load_date}
                        color = '#bc2b78'
                        size = "large"
                        style = {styles.activityIndicator}
                        />
                        :
                            <View style={{flex: 1, flexDirection: 'row'}}>

                              { monthscroll }

                            </View>
                        }

                          </View>

                          <View style={{flex: 1}}>

                            <View style={{flex: 1, flexDirection: 'row', bottom: 30}}>

                              <View style={{ height: 150, width: '50%', borderWidth: 1, borderColor: 'black'}}>
                                <Text style={style.iconstyle}><Icon2 name="dumbbell" size={20} color="#FF7E00"   /></Text>
                                <Text style={style.headerLine}>{this.state.workouts_completed}</Text>
                                <View style={style.middleLine}></View>
                                <Text style={style.innerBlock}>WORKOUTS</Text>                              
                              </View>

                              <View style={{ height: 150, width: '50%', borderWidth: 1, borderLeftWidth: 0, borderColor: 'black'}}>
                                <Text style={style.iconstyle}><Icon name="clock-o" size={20} color="#FF7E00"   /></Text>
                                <Text style={style.headerLine}>{this.state.workout_hours}</Text>
                                <View style={style.middleLine}></View>
                                <Text style={style.innerBlock}>TOTAL HOURS</Text> 
                              </View>

                            </View>

                          </View>
                          <View style={{flex: 1}}>

                            <View style={{flex: 1, flexDirection: 'row', bottom: 30}}>

                              <View style={{ height: 150, width: '50%', borderWidth: 1, borderColor: 'black'}}>
                                <Text style={style.iconstyle}><Icon name="calendar" size={20} color="#FF7E00"   /></Text>
                                <Text style={style.headerLine}>5.5</Text>
                                <View style={style.middleLine}></View>
                                <Text style={style.innerBlock}>CONSISTENCY AVERAGE</Text> 

                              </View>

                              <View style={{ height: 150, width: '50%', borderWidth: 1, borderLeftWidth: 0, borderColor: 'black'}}>
                                <Text style={style.iconstyle}><Icon1 name="fire" size={20} color="#FF7E00"   /></Text>
                                <Text style={style.headerLine}>{this.state.calories}</Text>
                                <View style={style.middleLine}></View>
                                <Text style={style.innerBlock}>CALORIES BURNED</Text> 
                              </View>

                            </View>

                          </View>
                          <View style={{flex: 1}}>

                            <View style={{flex: 1, flexDirection: 'row', bottom: 30}}>

                              <View style={{ height: 150, width: '50%', borderWidth: 1,  borderColor: 'black'}}>
                              <Text style={style.iconstyle}><Icon2 name="weight" size={20} color="#FF7E00"   /></Text>
                              <Text style={style.headerLine}>{this.state.weight_inc}<Text style={{fontSize: 16}}>lbs</Text></Text>
                              <View style={style.middleLine}></View>
                              <Text style={style.innerBlock}>WEIGHT +/-</Text>                                 
                              </View>

                              <View style={{ height: 150, width: '50%', borderWidth: 1, borderLeftWidth: 0, borderColor: 'black'}}>
                              <Text style={style.iconstyle}><Icon name="hand-peace-o" size={20} color="#FF7E00"   /></Text>
                              <Text style={style.headerLine}>{this.state.body_fat}%</Text>
                              <View style={style.middleLine}></View>
                              <Text style={style.innerBlock}>BODY FAT</Text>                                 
                              </View>

                            </View>

                          </View>

                          <View style={{flex: 1}}>

                            <View style={{flex: 1, flexDirection: 'row', bottom: 30}}>

                              <View style={this.state.tabs == 0 ? style.tab1 : style.tab2}>
                                <TouchableOpacity onPress={()=> this.setState({tabs: 0})}>
                                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: 'bold'}}> LATEST WORKOUTS </Text>
                                </TouchableOpacity>  
                              </View>

                              <View style={this.state.tabs == 1 ? style.tab1 : style.tab2}>
                                <TouchableOpacity onPress={()=> this.setState({tabs: 1})}>
                                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: 'bold'}}> LEADERBOARD </Text>
                                </TouchableOpacity> 
                              </View>

                            </View>

                          </View>                          

                          {this.state.tabs == 0 ?

                          <View style={{flex: 1, backgroundColor: '#000', top: -30, paddingBottom: 50 }}>

                            {this.state.loader_completedworkouts ?
                              <ActivityIndicator
                              animating = {this.state.contentLoader}
                              color = '#bc2b78'
                              size = "large"
                              style = {styles.activityIndicator}
                              />
                            :

                            <View style={{flex: 1, flexDirection: 'row'}}>

                              { completedworkouts }

                            </View>

                            }

                          </View> 

                          :  

                          <View style={{flex: 1, backgroundColor: '#000', top: -30, paddingBottom: 50 }}>

                            <View style={{flex: 1, flexDirection: 'row'}}>

                              <View style={{ width: '100%', borderWidth: 0,  borderColor: 'black'}}>

                            {this.state.studentslist.map(data => {
                                  return (
                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 2,  borderColor: '#2d2e37'}}>

                                  <View style={{width: '20%', alignItems: 'center', padding: 10}}>

                                    <View style={{padding: 10}}>

                                    <Image style={{
                                        width: 45,
                                        height: 45,
                                        marginTop: 0,
                                        borderRadius: 23
                                    }} source={{
                                        uri: "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"
                                    }} />


                                    </View>

                                  </View>

                                  <View style={{width: '60%', alignItems: 'flex-start'}}>

                                    <View style={{padding: 10, marginTop: 10}}>

                                    <Text style={{fontSize: 18, fontWeight: 'bold', color: 'white'}}>{data[2]}</Text>

                                    <Text style={{fontSize: 10, marginTop: 10, marginLeft: -3, fontWeight: 'bold', color: 'whitesmoke'}}> Campus Name   |  Archirecture Mayor</Text>

                                    </View>

                                  </View>

                                  {this.state.user_id == data[0] ?

                                  <View style={{width: '20%', borderLeftWidth: 2,  borderColor: '#2d2e37', backgroundColor: '#ff7200'}}>


                                    <View style={{padding: 10, alignItems: 'center', marginTop: 15}}>

                                    <Text style={{fontSize: 28, fontWeight: 'bold', color: 'white'}}>{data[1]}</Text>

                                    </View>

                                  </View>

                                    :

                                  <View style={{width: '20%', borderLeftWidth: 2,  borderColor: '#2d2e37'}}>


                                    <View style={{padding: 10, alignItems: 'center', marginTop: 15}}>

                                    <Text style={{fontSize: 28, fontWeight: 'bold', color: 'white'}}>{data[1]}</Text>

                                    </View>

                                  </View>                                  


                                    }


                                </View>
                                  )
                              })}

                              </View>

                            </View>

                          </View> 

                        }


                        </ScrollView>

                    </View>                    

                    </View>

                  }

            </View>
    );
  }
}

reactMixin(Profile_Data.prototype, TimerMixin);


const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#2d2e37',
        flex:1,
        marginTop: 0
    },
    tab1: {
      height: 60, 
      width: '50%', 
      backgroundColor: '#000', 
      borderBottomWidth: 2,  
      borderBottomColor: '#ff7200', 
      borderRightWidth: 1,  
      borderRightColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    tab2: {
      height: 60, 
      width: '50%', 
      borderWidth: 0, 
      borderLeftWidth: 0, 
      borderColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    innerBlock: {fontSize: 10, color: '#fff', paddingTop: 5, fontWeight: 'bold', paddingLeft: 20, paddingTop: 10},
    middleLine: {borderBottomWidth: 2, borderColor: '#ff7200', width: 50, marginLeft: 20},
    headerLine: { color: '#fff', fontWeight: 'bold', fontSize: 55, textAlign: 'left', paddingLeft: 20},
    iconstyle: {textAlign: 'right', padding: 5}



});
