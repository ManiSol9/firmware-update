import React, { Component } from 'react';
import { Platform, AppRegistry, FlatList, StyleSheet, TextInput, Picker, ScrollView, TouchableOpacity, Text, Image, KeyboardAvoidingView, View, TouchableHighlight, ToastAndroid, Alert, ActivityIndicator, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';

import { onSignIn, getAllAsyncStroage } from '../../../config/auth';


import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon1 from 'react-native-vector-icons/SimpleLineIcons';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';

import Icon from 'react-native-vector-icons/FontAwesome';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';

import { sliderWidth, itemWidth } from '../slider/SliderEntry.style';
import FilterSlider from '../slider/SliderEntry';
import GraphSlider from '../slider/graphslider';

import styles1, { colors } from '../slider/index.style';
import { ENTRIES1, ENTRIES2 } from '../slider/entries';
import { scrollInterpolators, animatedStyles } from '../slider/animations';

const IS_ANDROID = Platform.OS === 'android';
const SLIDER_1_FIRST_ITEM = 1;

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

import PhotoUpload from 'react-native-photo-upload'
import axios from 'axios';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import styles from '../Landing/styles.js';
import Carousel from 'react-native-snap-carousel';

import moment from "moment";


import { request } from 'graphql-request'

export default class Filter extends Component {

    constructor(props) {
        super(props);
        this.state = {
          classyear: null,
          sportsteam: null,
          campusgroup: null,
          major: null
        }
    }
    componentWillMount() {

    }

    _renderItemWithParallax123 ({item, index}, parallaxProps) {

        return (
                        <FilterSlider
                          data={item}
                          firstItem={0}
                        />
            );
    }

    completedworkouts () {
        const { slider1ActiveSlide } = this.state;

        return (
            <View style={styles1.exampleContainer}>
                <Carousel
                  ref={c => this._slider1Ref = c}
                  data={ENTRIES1}
                  renderItem={this._renderItemWithParallax123.bind(this)}
                  sliderWidth={sliderWidth}
                  itemWidth={itemWidth}
                  hasParallaxImages={false}
                  firstItem={0}
                  inactiveSlideScale={1}
                  inactiveSlideOpacity={0.9}
                  inactiveSlideShift={0}
                  containerCustomStyle={styles1.slider}
                  contentContainerCustomStyle={styles1.sliderContentContainer}
                  loop={false}
                  loopClonesPerSide={1}
                  autoplay={false}
                  autoplayDelay={500}
                  autoplayInterval={3000}
                  onSnapToItem={(index) => this.setState({ slider1ActiveSlide: index }) }
                />

            </View>
        );
    }

    classyear = (val) =>{

      this.setState({classyear: val})

    }

    sportsteam = (val) => {
      this.setState({sportsteam: val})
    }

    campusgroup = (val) => {
      this.setState({campusgroup: val})
    }

    major = (val) => {
      this.setState({major: val})
    }

    sendData = () => {

      const {navigate} = this.props.navigation

      navigate("Tabs")

    }

    render() {

            const completedworkouts = this.completedworkouts();

        let major = [
        {
          value: ['Anim. Sci', 'Justice', 'Agri. Tech']
        }, {
          value: ['Art', 'Architecture', 'Anthropology']
        }, {
          value: ['Auto Tech', 'Astronomy', 'Nursing']
        },{
          value: ['Biology', 'Auto Electric', 'Auto Repair']
        }, {
          value: ['Caterpillar', 'Chemistry', 'Business']
        },
        {
          value: ['Comp. Net', 'Comm. Studies', 'Chemistry']
        }, {
          value: ['Corr. Sci', 'CS', 'Cisco']
        }, {
          value: ['Diesel Tech', 'Dance', 'Culinary']
        },{
          value: ['Economics', 'Childhood', 'Drama']
        }, {
          value: ['Electron Mic.', 'Electrical Tech', 'Education']
        },{
          value: ['English', 'Engineering', 'Electronics']
        },{
          value: ['FP Tech', 'Fashion', 'ESL']
        },
        {
          value: ['Graphics Arts', 'Geography','FL']
        },{
          value: ['H & AC', 'Health Ed.', 'Counseling']
        }, {
          value: ['Industrial Tech', 'Humanities', 'History']
        }, {
          value: ['Kinesiology', 'Journalism', 'Interior Design']
        }, {
          value: ['Library', 'Resources', 'M. Languages']
        }, {
          value: ['Music', 'Mathematics', 'Mech. Tech']
        },
        {
          value: ['OH', 'NAT', 'N. Resources']
        }, {
          value: ['Physics', 'Photography', 'PE/Rec']
        }, {
          value: ['POST Academy', 'Political Sci.', 'Plant Sci.'],
        },{
          value: ['Radio/TV', 'Psychology', 'Psych. Tech'],
        },{
          value: ['Sociology', 'Reading', 'Radiologic'],
        },{
          value: ['Welding', 'SLPA', 'Speech'],
        }        
        ];

        var classyear = [{
                    value: ['2018', '2019', '2020']          
        }, {
                    value: ['2021', '2022', '2023']
        }]             

        var sportsteam = [{
          value: ['Baseball', 'Basketball (w)', 'Basketball (m)']
        },{
          value: ['Cross Country', 'Cheer Team', 'Beach VB (w)']
        }, {
          value: ['Soccer (m)', 'Golf (w)', 'Football']
        }, {
          value: ['Softball (w)', 'Soccer (w)', 'Basketball (w)']
        }, {
          value: ['Volleyball (w)', 'Track & Field', 'Swimming']
        },{
          value: ['Wrestling', 'Water Polo (w)', 'Water Polo (m)']
        }]; 

        var campusgroup = [{
                    value: ['Music', 'Dance', 'Cooking']          
        }, {
                    value: ['Signing']
        }]

        console.log(campusgroup)

        return (
                <View style={styles.mainBody}>
                
                 <StatusBarBackground style={{
                        backgroundColor: '#FF7E00'
                    }}/>

                    <View style={{backgroundColor: '#000', height: 60}}>
                      <View style={styles.chevron_left_icon}>
                        <TouchableOpacity onPress={() => {
                            const {navigate} = this.props.navigation;
                            navigate("Tabs", {showProfile: null,showFeed: true,showNotification: null,showMore: null})
                        }}>
                          <Icon name="chevron-left" size={25} color="#FF7E00"/>
                        </TouchableOpacity>
                      </View>
                      <View style={styles.header}>
                        <Text style={styles.topSignupTxt}>
                        Profile Details
                        </Text>
                      </View>
                    </View>

                    <View style={{alignItems:'flex-end', padding: 20}}>
                      <View style={{width: 100, borderColor: '#000', borderWidth: 1, padding: 10, borderRadius: 20}}>
                          <Text style={{color: '#fff', textAlign: 'center'}}>
                            Reset all
                          </Text>
                      </View>
                    </View>  

                    <ScrollView>

                    <View style={{height: 195, borderColor: '#000', borderBottomWidth: 1}}>

                      <View style={{padding: 10}}>
                        <Text style={{color: '#fff', fontSize: 20, marginLeft: 20, textAlign: 'left'}}>
                          Major
                        </Text>
                      </View>            

                      <ScrollView>

                      <View>

                      {major.map(data => {

                      return (                      

                        <View style={{flex: 1, flexDirection: 'row', padding: 10 }}>

                            {data.value[0] != '' ?
                              <TouchableOpacity onPress={() => this.major(data.value[0])}>
                                <View style={this.state.major == data.value[0]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[0]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}

                            {data.value[1] != null ?
                              <TouchableOpacity onPress={() => this.major(data.value[1])}>
                                <View style={this.state.major == data.value[1]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[1]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}

                            {data.value[2] != null ?
                              <TouchableOpacity onPress={() => this.major(data.value[2])}>
                                <View style={this.state.major == data.value[2]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[2]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}                                                                
                                                                            
                        </View>

                          )
                      })}

                      </View>
                      
                      </ScrollView>

                    </View>

                    <View style={{height: 195, borderColor: '#000', borderBottomWidth: 1}}>

                      <View style={{padding: 10}}>
                        <Text style={{color: '#fff', fontSize: 20, marginLeft: 20, textAlign: 'left'}}>
                          Campus Group
                        </Text>
                      </View>            

                      <ScrollView>

                      <View>

                      {campusgroup.map(data => {

                      return (                      

                        <View style={{flex: 1, flexDirection: 'row', padding: 10 }}>

                            {data.value[0] != '' ?
                              <TouchableOpacity onPress={() => this.campusgroup(data.value[0])}>
                                <View style={this.state.campusgroup == data.value[0]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[0]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}

                            {data.value[1] != null ?
                              <TouchableOpacity onPress={() => this.campusgroup(data.value[1])}>
                                <View style={this.state.campusgroup == data.value[1]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[1]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}

                            {data.value[2] != null ?
                              <TouchableOpacity onPress={() => this.campusgroup(data.value[2])}>
                                <View style={this.state.campusgroup == data.value[2]?styles.selected_value:styles.not_selected_value}>
                                  <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                      {data.value[2]}
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              :<View></View>}                                                              
                                                                            
                        </View>

                          )
                      })}

                      </View>
                      
                      </ScrollView>

                    </View>

                    <View style={{height: 195, borderColor: '#000', borderBottomWidth: 1}}>

                      <View style={{padding: 10}}>
                        <Text style={{color: '#fff', fontSize: 20, marginLeft: 20, textAlign: 'left'}}>
                          Sports Team
                        </Text>
                      </View>            

                      <ScrollView>

                      <View>

                      {sportsteam.map(data => {

                      return (                      

                        <View style={{flex: 1, flexDirection: 'row', padding: 10 }}>

                            <TouchableOpacity onPress={() => this.sportsteam(data.value[0])}>
                              <View style={this.state.sportsteam == data.value[0]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[0]}
                                </Text>
                              </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.sportsteam(data.value[1])}>
                              <View style={this.state.sportsteam == data.value[1]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[1]}
                                </Text>
                              </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.sportsteam(data.value[2])}>
                              <View style={this.state.sportsteam == data.value[2]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[2]}
                                </Text>
                              </View>                                                              
                            </TouchableOpacity>                                                             
                                                                            
                        </View>

                          )
                      })}

                      </View>
                      
                      </ScrollView>

                    </View>                                        

                    <View style={{height: 195, borderColor: '#000', borderBottomWidth: 1, marginTop: 20}}>

                      <View style={{padding: 10}}>
                        <Text style={{color: '#fff', fontSize: 20, marginLeft: 20, textAlign: 'left'}}>
                          Class Year
                        </Text>
                      </View>            

                      <ScrollView>

                      <View>

                      {classyear.map(data => {

                      return (                      

                        <View style={{flex: 1, flexDirection: 'row', padding: 10 }}>
                            
                            <TouchableOpacity onPress={() => this.classyear(data.value[0])}>
                              <View style={this.state.classyear == data.value[0]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[0]}
                                </Text>
                              </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.classyear(data.value[1])}>
                              <View style={this.state.classyear == data.value[1]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[1]}
                                </Text>
                              </View>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.classyear(data.value[2])}>
                              <View style={this.state.classyear == data.value[2]?styles.selected_value:styles.not_selected_value}>
                                <Text style={{color: '#fff', textAlign: 'center', fontSize: 12}}>
                                    {data.value[2]}
                                </Text>
                              </View>                                                              
                            </TouchableOpacity>                                              
                        </View>

                          )
                      })}

                      </View>
                      
                      </ScrollView>

                    </View> 

                    </ScrollView>

                    <View style={{bottom: 0, marginTop: 50, position: 'absolute', alignItems: 'center',justifyContent: 'center'}}>
                        <TouchableOpacity onPress={() => this.sendData()}>
                            <View style={{
                            zIndex: 999,
                            alignItems: 'center',
                            justifyContent: 'center',
                            height: 50,
                            width: width
                        }}>
                        <Text style={{
                            backgroundColor: 'transparent',
                            alignSelf: 'center',
                            fontFamily: 'CircularStd-Black',
                            color: '#fff',
                            fontSize: 19
                        }}>Save</Text>
                      
                            </View>
                            <Image style={{
                            width: width,
                            height: 50,
                            position: 'absolute',
                            bottom: 0
                        }} source={{
                            uri: 'btn_gradi_bg'
                        }}/>
                        </TouchableOpacity>
                    </View> 
                
                </View>
                );
        }
}

module.exports = Filter;
