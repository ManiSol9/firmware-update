/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Switch,
  Image,
  PixelRatio,
  KeyboardAvoidingView,
  ScrollView,
  TouchableHighlight,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  AsyncStorage
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import  Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'
import Toast, {DURATION} from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'


import { TabNavigator } from 'react-navigation';


import styles from './styles.js'

import { request } from 'graphql-request'

export default class Notification extends Component<{}> {
  constructor(props) {
    super(props);
    this.state = {
      width:0,
      height : 0,
      buttonText:true,
      notifications: []
    };
  }
  async componentDidMount () {

    let USER_ID = await AsyncStorage.getItem("USER_ID");

    this.checkNotification(USER_ID)

  }


    checkNotification = (USER_ID) => {

        const query = `query mobile_notification($user_id: Int!){
                          mobile_notification(user_id:$user_id){
                            message
                            status
                            first_name
                            middle_name
                            last_name
                            profile_image_url
                          }
                        }`;

        const varibales = {
          user_id: USER_ID
        }                

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/mobile_notification', query, varibales)
            .then(async data => {
              console.log(data)
              this.setState({notifications: data.mobile_notification})
            }
        )
            .catch(async err => {
                console.log(err)
            }
        )

    }

  render() {
    const {navigation} = this.props
    const { buttonText } = this.state;

    const { contentLoader, notifications } = this.state;

    return (
      <View style={styles.mainBody}>
      <StatusBarBackground style={{backgroundColor:'#ff7200'}}/>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Notification's
            </Text>
          </View>

        {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View style={{marginTop: 20}}>

                 <View>
                  <ScrollView style={{marginBottom: 200}}>

                    {notifications.map(comment => {

                       if(comment.profile_image_url){
                        var profile_image_url = comment.profile_image_url
                       } else {
                        profile_image_url = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg"                        
                       }

                          return (
                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 2,  borderColor: 'black'}}>

                                  <View style={{width: '20%', alignItems: 'center', padding: 10}}>

                                    <View style={{padding: 10}}>

                                    <Image style={{
                                        width: 45,
                                        height: 45,
                                        marginTop: 0,
                                        borderRadius: 23
                                    }} source={{
                                        uri: profile_image_url
                                    }} />

                                    </View>

                                  </View>

                                  <View style={{width: '65%', alignItems: 'flex-start'}}>

                                    <View style={{padding: 10, marginTop: 5}}>

                                    <Text style={{fontSize: 16, fontWeight: 'bold', color: 'white'}}> {comment.first_name} {comment.last_name} </Text>

                                    <Text style={{fontSize: 13, paddingRight: 15, paddingLeft:0, marginTop: 7, marginLeft: 0, fontWeight: 'bold', color: 'whitesmoke'}}> {comment.message} </Text>

                                    </View>

                                  </View>
                                  
                            </View>
                          )
                      })}

                  </ScrollView>

                 </View>

              </View>

            }

      </View>

    );
  }
}
