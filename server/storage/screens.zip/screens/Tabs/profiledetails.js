import React, { Component } from 'react';
import { AppRegistry, FlatList, StyleSheet, TextInput, Picker, ScrollView, TouchableOpacity, Text, Image, KeyboardAvoidingView, View, TouchableHighlight, ToastAndroid, Alert, ActivityIndicator, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import { NavigationActions } from 'react-navigation';

import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

import PhotoUpload from 'react-native-photo-upload'
import axios from 'axios';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import styles from '../Landing/styles.js';

import { request } from 'graphql-request'
import { Dropdown } from 'react-native-material-dropdown';
import ImageResizer from 'react-native-image-resizer';


import moment from "moment";


export default class ProfileDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            profile: [],
            height_in_feet: null,
            height_in_meters: null,
            height_in_inches: null,
            weight: null,
            age: null,
            gender: 'Male',
            userid: null,
            genderIndex: null,
            enable: null,
            Loader: false,
            contentLoader: true,
            editable: null,
            visible: true,
            profile_img_url: null,
            upload_uri: "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg",
            upload_uri_check: false,
            visible: true,
            imperial: 0,
            weight_in_kgs: null,
            profile_img_url: null,
            password: null,
            body_fat: null,
            username: null,
            major: "",
            rescollege: "",
            sport: "",
            classyear: "",
            campus: ""
        }
    }
    async componentWillMount() {
        getAllAsyncStroage()
            .then(res => console.log(res)
        )
            .catch(err => console.log(err)
        );

        let USER_NAME = await AsyncStorage.getItem("USER_NAME");

        this.setState({username: USER_NAME})

        this.getStudentID();
        //this.getSchool();
    }


    photouploadserver = async (file) => {
        console.log('response', file)

        let formData = new FormData();

        if (file.fileName) {
            name = file.fileName
        } else {
            image_source = file.uri
            image = image_source.split("/");
            image_length = image.length
            name = image[image_length - 1];
        }

        let USER_ID = await AsyncStorage.getItem("USER_ID");


        ImageResizer.createResizedImage(file.uri, 100, 100, 'PNG', 1).then((response) => {
            console.log(response, "response")

            formData.append('myfile', {
                type: 'image/png',
                name: name,
                uri: response.uri
            })

        axios.post(API.Image_url, formData).then(response => {
            updated_img = response.data
            console.log(updated_img)

            this.setState({
                visible: true
            })
            this.setState({
                upload_uri: updated_img.url
            })
            this.setState({
                enable: true
            })

                    var query = `mutation 
                            edit_profile_details1(
                                $profile_image_url: String!,
                                $id: Int!                                
                                ){
                                edit_profile_details1(
                                    id: $id, 
                                    profile_image_url: $profile_image_url, 
                                ) {
                                    status
                                }

                            }`;                                 


                    var variables = {
                        id: Number(USER_ID),
                        profile_image_url: String(updated_img.url),
                    }



                    request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {

                        if (data.edit_profile_details1[0].status == 'success') {
                            alert('Profile image updated')
                            }
                        }
                    )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                      }
                    )


        }).catch(err => {
            console.log('err')
            console.log(err)

        })


        }).catch(err => {
            console.log('err')
            console.log(err)

        })


    }


    getStudentID =async() => {
        console.log('profile view', await AsyncStorage.getItem("DEVICE_NAME"))
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        console.log(USER_ID)
        this.setState({
            userid: USER_ID,
            enable: false,
            Loader: true
        }, () => {
            this._getStudentDetails(this.state.userid);
        });
    }
    _getStudentDetails=(id) => {

        const query = `query profile_details($user_id:Int!){

                profile_details(user_id: $user_id) {
                    email,
                    dob,
                    height_in_feet,
                    height_in_meters,
                    height_in_inches,
                    current_weight_in_lbs,
                    current_weight_in_kgs,
                    present_weight_in_lbs,
                    present_weight_in_kgs,
                    present_height_in_feet,
                    present_height_in_inches,
                    present_height_in_meters,
                    parameter_type,
                    gender,
                    first_name,
                    last_name,
                    middle_name,
                    profile_image_url,
                    body_fat
                    user_school_details {
                      class_major
                      sports_team
                      campus_group
                      residential_college
                      graduation_year
                    }
                }

                }`;

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
            .then(async data => {
                
                response = data.profile_details[0]
                
                console.log(data.profile_details[0], "qwerty")

                    if(response.profile_image_url) {
                      this.state.upload_uri = response.profile_image_url
                    } else {
                       this.state.upload_uri = "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg" 
                    }

                    this.setState({
                        parameter_type: response.parameter_type,
                        gender: response.gender,
                        password: response.password,
                        major: response.user_school_details[0].class_major,
                        sport: response.user_school_details[0].sports_team,
                        classyear: response.user_school_details[0].graduation_year,
                        campus: response.user_school_details[0].campus_group
                    }, () => {

                        if(response.body_fat == null){

                            this.setState({body_fat: 0})

                        } else {

                            this.setState({body_fat: response.body_fat})
                        }

                        if (this.state.gender === "Male") {
                            this.setState({
                                genderIndex: 0
                            });
                        } else if (this.state.gender === "Female") {
                            this.setState({
                                genderIndex: 1
                            });
                        } else {
                            this.setState({
                                genderIndex: 2
                            });
                        }

                        if (this.state.parameter_type == 1) {
                            this.setState({
                                imperial: 0
                            });

                            if(response.present_weight_in_lbs == null){
                                
                                this.setState({
                                    weight: response.current_weight_in_lbs,
                                    weight_test: response.current_weight_in_lbs
                                })

                            } else {

                                this.setState({
                                    weight: response.present_weight_in_lbs,
                                    weight_test: response.present_weight_in_lbs
                                })

                            }
                            
                            if(response.present_height_in_inches == null){
                         
                                this.setState({
                                    height_in_inches: response.height_in_inches,
                                    height_in_inches_test: response.height_in_inches
                                })
                                       
                            } else {

                                this.setState({
                                    height_in_inches: response.present_height_in_inches,
                                    height_in_inches_test: response.present_height_in_inches
                                })

                            }


                            if(response.present_height_in_feet == null){

                                this.setState({
                                    height_in_feet: response.height_in_feet,
                                    height_in_feet_test: response.height_in_feet
                                })

                            } else {

                                this.setState({
                                    height_in_feet: response.present_height_in_feet,
                                    height_in_feet_test: response.present_height_in_feet
                                })

                            }


                        } else {
                            this.setState({
                                imperial: 1
                            });

                            if(response.present_height_in_meters == null){

                                this.setState({
                                    height_in_centimeter: response.height_in_meters,
                                    height_in_centimeter_test: response.height_in_meters
                                })

                            } else {

                                this.setState({
                                    height_in_centimeter: response.present_height_in_meters,
                                    height_in_centimeter_test: response.present_height_in_meters,
                                })

                            }                            

                            if(response.present_weight_in_kgs == null){
                                
                                this.setState({
                                    weight: response.current_weight_in_kgs,
                                    weight_test: response.current_weight_in_kgs
                                })

                            } else {

                                this.setState({
                                    weight: response.present_weight_in_kgs,
                                    weight_test: response.present_weight_in_kgs
                                })

                            }

                        }

                    });


                console.log(this.state)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })


            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )        
    }


    nextScreen = (value) => {
        
        const {navigate} = this.props.navigation

        if(value == 'Weight') {
                    navigate('EditWeight', {
                        feet: String(this.state.height_in_feet),
                        inches: String(this.state.height_in_inches),
                        system: String(this.state.parameter_type),
                        weight: String(this.state.weight),
                        height_in_metric: String(this.state.height_in_centimeter),
                        weight_in_kgs: String(this.state.weight)
                    })

        } else if(value == 'Height') {
                    navigate('EditHeight', {
                        feet: String(this.state.height_in_feet),
                        inches: String(this.state.height_in_inches),
                        system: this.state.parameter_type,
                        weight: String(this.state.weight),
                        height_in_metric: String(this.state.height_in_centimeter),
                        weight_in_kgs: String(this.state.weight)
                    })            
        } else if(value == 'bodyfat') {

                    navigate('EditFat', {
                        body_fat: String(this.state.body_fat),
                    })        
        }

    }

    SaveData = async () => {

       let USER_ID = await AsyncStorage.getItem("USER_ID");

       const query =`mutation edit_school_details($residential_college: String!, $campus_group: String!, $sports_team: String!, $graduation_year: String!, $class_major: String!, $user_id: Int!){
                      edit_school_details(residential_college: $residential_college, campus_group: $campus_group, sports_team: $sports_team, graduation_year: $graduation_year, class_major: $class_major, user_id: $user_id){
                        status
                      }
                    }`

        const variables = {
            user_id: Number(USER_ID),
            residential_college: String(this.state.rescollege),
            campus_group: String(this.state.campus),
            sports_team: String(this.state.sport),
            graduation_year: String(this.state.classyear),
            class_major: String(this.state.major)
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
            .then(async data => {
              
                console.log(data)

                alert('Profile details updated')

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

    }


    onChangeSport = (val) => {

        this.setState({
            sport: val
        })

    }

    onChangeyear = (val) => {

        this.setState({
            classyear: val
        })

    } 

    onChangeCampus = (val) => {

        this.setState({
            campus: val
        })

    }       

    onChangemajor = (val) => {

        this.setState({
            major: val
        })

    }  



    render() {
        var that = this;
        var radio_props = [
            {
                label: 'Male',
                value: 0
            },
            {
                label: 'Female',
                value: 1
            }
        ];
        var {height, weight, age, enable, loader, contentLoader, profile_img_url, weight_in_kgs, height_in_inches, height_in_feet, height_in_meters, upload_uri} = this.state;

        console.log(this.state)

        var res_col = [{value: '--na--'}]

        let sports = [{
          value: 'Baseball',
        }, {
          value: 'Basketball (m)',
        }, {
          value: 'Basketball (w)',
        },{
          value: 'Beach VB (w)',
        },{
          value: 'Cheer Team',
        }, {
          value: 'Cross Country',
        }, {
          value: 'Football',
        },{
          value: 'Golf (m)',
        },{
          value: 'Golf (w)',
        }, {
          value: 'Soccer (m)',
        }, {
          value: 'Basketball (w)',
        },{
          value: 'Soccer (w)',
        },{
          value: 'Softball (w)',
        },{
          value: 'Swimming',
        }, {
          value: 'Track & Field',
        }, {
          value: 'Volleyball (w)',
        },{
          value: 'Water Polo (m)',
        },
        {
          value: 'Water Polo (w)',
        },{
          value: 'Wrestling',
        }];        

        let data = [{
          value: 'Baseball',
        }, {
          value: 'Basketball (m)',
        }, {
          value: 'Basketball (w)',
        },{
          value: 'Beach VB (w)',
        },{
          value: 'Cheer Team',
        }, {
          value: 'Cross Country',
        }, {
          value: 'Football',
        },{
          value: 'Golf (m)',
        },{
          value: 'Golf (w)',
        }, {
          value: 'Soccer (m)',
        }, {
          value: 'Basketball (w)',
        },{
          value: 'Soccer (w)',
        },{
          value: 'Softball (w)',
        },{
          value: 'Swimming',
        }, {
          value: 'Track & Field',
        }, {
          value: 'Volleyball (w)',
        },{
          value: 'Water Polo (m)',
        },
        {
          value: 'Water Polo (w)',
        },{
          value: 'Wrestling',
        }];       

        let major = [
        {
          value: 'Justice',
        }, {
          value: 'Agri. Tech',
        }, {
          value: 'Anim. Sci',
        },{
          value: 'Anthropology',
        },{
          value: 'Architecture',
        }, {
          value: 'Art',
        }, {
          value: 'Nursing',
        },{
          value: 'Astronomy',
        },{
          value: 'Auto Tech',
        }, {
          value: 'Auto Repair',
        }, {
          value: 'Auto Electric',
        },{
          value: 'Biology',
        },{
          value: 'Business',
        },{
          value: 'Chemistry',
        }, {
          value: 'Caterpillar',
        }, {
          value: 'Chemistry',
        },{
          value: 'Comm. Studies',
        },
        {
          value: 'Comp. Net',
        },
        {
          value: 'Cisco',
        },
        {
          value: 'CS',
        }, {
          value: 'Corr. Sci',
        }, {
          value: 'Culinary',
        },{
          value: 'Dance',
        },{
          value: 'Diesel Tech',
        }, {
          value: 'Drama',
        }, {
          value: 'Childhood',
        },{
          value: 'Economics',
        },{
          value: 'Education',
        }, {
          value: 'Electrical Tech',
        }, {
          value: 'Electron Mic.',
        },{
          value: 'Electronics',
        },{
          value: 'Engineering',
        },{
          value: 'English',
        }, {
          value: 'ESL',
        }, {
          value: 'Fashion',
        },{
          value: 'FP Tech',
        },
        {
          value: 'FL',
        },{
          value: 'Geography',
        },
        {
          value: 'Graphics Arts',
        }, {
          value: 'Counseling',
        }, {
          value: 'Health Ed.',
        },{
          value: 'H & AC',
        },{
          value: 'History',
        }, {
          value: 'Humanities',
        }, {
          value: 'Industrial Tech',
        },{
          value: 'Interior Design',
        },{
          value: 'Journalism',
        }, {
          value: 'Kinesiology',
        }, {
          value: 'M. Languages',
        },{
          value: 'Resources',
        },{
          value: 'Library',
        },{
          value: 'Mech. Tech',
        }, {
          value: 'Mathematics',
        }, {
          value: 'Music',
        },{
          value: 'N. Resources',
        },
        {
          value: 'NAT',
        },
        {
          value: 'OH',
        },
        {
          value: 'PE/Rec',
        }, {
          value: 'Photography',
        }, {
          value: 'Physics',
        },{
          value: 'Plant Sci.',
        },{
          value: 'Political Sci.',
        }, {
          value: 'POST Academy',
        }, {
          value: 'Psych. Tech',
        },{
          value: 'Psychology',
        },{
          value: 'Radio/TV',
        }, {
          value: 'Radiologic',
        }, {
          value: 'Reading',
        },{
          value: 'Sociology',
        },{
          value: 'Speech',
        },{
          value: 'SLPA',
        }, {
          value: 'Welding',
        }        
        ];   

        if(this.state.imperial == 0)
        {
            if(height_in_feet == null) {
                height_in_feet = 0
            }
            if(height_in_inches == null) {
                height_in_inches = 0
            }

            edit_height = height_in_feet +"'"+height_in_inches
            edit_weight = weight
            weight_type = "lb"

        } else {
            edit_height = this.state.height_in_centimeter
            edit_weight = this.state.weight
            weight_type = "kgs"
        }

        console.log(this.state)

        year = new Date().getFullYear()

        let years = [{
          value: year,
        }, {
          value: year+1,
        }, {
          value: year+2,
        },{
          value: year+3,
        },{
          value: year+4,
        }];

        let campus_group = [{ value: 'Music'}, { value: 'Dance'}, { value: 'Cooking'}, { value: 'Signing'}]

        return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

                {this.state.contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :

                  <View style={style.body}>
                    <View style={{height: 250, backgroundColor: '#000',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: width,padding: 10, flex: 1, flexDirection: 'row' }}>
                                
                                <View style={{width: '10%'}}>
                                    <TouchableOpacity onPress={() => {
                                        const {navigate} = this.props.navigation;
                                        navigate('Tabs', {showProfile: true,showFeed: false,showNotification: null,showMore: null, reloadfeed: false})
                                    }}>
                                        <Icon name="chevron-left" size={25} color="#FF7E00"   />
                                    </TouchableOpacity>
                                </View>
                                <View style={{width: '80%', alignItems: 'center'}}>
                                    <Text style={{ color: '#2d2e37', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>Profile</Text>
                                </View>    
                                <View style={{width: '10%', alignItems: 'flex-end'}}>
                                    <Icon name="pencil" size={25} color="#FFF"   />
                                </View>                                
                            </View>

                        </View>

                        <View style={{flex: 1, flexDirection: 'row', bottom: '4%', height: 150}}>

                          <View style={{alignItems: 'flex-start', paddingLeft: 20}}>

                                <PhotoUpload
                                            onPhotoSelect={avatar => {
                                                if (avatar) {
                                                    console.log('Image base64 string: ', avatar)

                                                }

                                            }}

                                            onStart = {start => {
                                                console.log('start', start)
                                                //this.setState({contentLoader:true})
                                                this.setState({
                                                    visible: false
                                                })
                                            }}
                                            onResponse = {response => {
                                                //this.setState({contentLoader:false})
                                                console.log('response', response)
                                                
                                                if(response.didCancel == true) {
                                                    this.setState({
                                                        visible: true
                                                    })                                                    
                                                } else {
                                                    this.photouploadserver(response)
                                                }

                                            }}
                                            onError = {error => {
                                                console.log('error', error)
                                            }}
                                            onRender = {render => {
                                                console.log('render', render)
                                            }}
                                            >
                                               {this.state.visible ? <Image
                                            style={{
                                                paddingVertical: 30,
                                                width: 100,
                                                height: 100,
                                                borderRadius: 50
                                            }}
                                            resizeMode='cover'
                                            source={{
                                                uri: this.state.upload_uri
                                            }}
                                            /> : <View style={{
                                                height: 100,
                                                width: 100,
                                                borderRadius: 50,
                                                paddingVertical: 10,
                                                backgroundColor: 'white'
                                            }}>
                                                    <ActivityIndicator
                                                    animating = {true}
                                                    color = '#cccccc'
                                                    size = "large"
                                                    style = {{
                                                        paddingTop: 26
                                                    }}
                                                    />

                                                </View> }
                                                    
                                                   
                                </PhotoUpload> 
                          </View>
                          <View style={{ padding: 20, bottom: 0}}>

                                  <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 28, textAlign: 'left'}}>{this.state.username}</Text>
                                  <Text style={{ color: '#ff7200', fontSize: 13, textAlign: 'left'}}>ARCHITECHUR MAYER</Text>

                          </View>
                        </View>


                        <View style={{flex: 1, flexDirection: 'row', bottom: '-6%'}}>

                            

                            <View style={{width: '33%', alignItems: 'center'}}>

                            <TouchableOpacity onPress={()=> this.nextScreen('Weight')}>

                                <Text style={{fontSize: 24, fontWeight: 'bold', color: '#FFF', textAlign: 'center'}}>{edit_weight ? edit_weight : '0'} {weight_type}</Text>
                                <Text style={{fontSize: 10, fontWeight: 'bold', color: '#FFF'}}>CURRENT WEIGHT</Text>

                            </TouchableOpacity>

                            </View>

                            


                            <View style={{width: '33%', alignItems: 'center'}}>

                            <TouchableOpacity onPress={()=> this.nextScreen('Height')}>


                                <Text style={{fontSize: 24, fontWeight: 'bold', color: '#FFF' ,textAlign: 'center'}}>{edit_height ? edit_height : '0'}</Text>
                                <Text style={{fontSize: 10, fontWeight: 'bold', color: '#FFF'}}>HEIGHT</Text>

                            </TouchableOpacity>


                            </View>

                            <View style={{width: '33%', alignItems: 'center'}}>

                            <TouchableOpacity onPress={()=> this.nextScreen('bodyfat')}>


                                <Text style={{fontSize: 24, fontWeight: 'bold', color: '#FFF' ,textAlign: 'center'}}>{this.state.body_fat}%</Text>
                                <Text style={{fontSize: 10, fontWeight: 'bold', color: '#FFF'}}>BODY FAT</Text>

                            </TouchableOpacity>


                            </View>                            


                        </View>

                    </View>
  

                    <View style={{flex: 1, flexDirection: 'column', marginTop: 20, height: 600}}>

                        <ScrollView style={{flex: 1}}>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>RES COLLEGE</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={res_col}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                        value={this.state.rescollege}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>MAJOR</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={major}
                                        onChangeText={this.onChangemajor}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                        value={this.state.major}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>CAMPUS GROUP</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={campus_group}
                                        onChangeText={this.onChangeCampus}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                        value={this.state.campus}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>SPORTS TEAM</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={sports}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                        onChangeText={this.onChangeSport}
                                        value={this.state.sport}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 16, fontWeight: 'bold'}}>COLLEGE YEAR</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={years}
                                        style={{width: '100%'}}
                                        onChangeText={this.onChangeyear}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                        value={this.state.classyear}
                                      />
                                    </View>                                
                                </View>

                            </View>



                            <View style={{height: 60}}>


                            </View>

                        </ScrollView>

                    </View>                    

                    </View>

                }

        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress={() => this.SaveData()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
            <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save profile</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 



            </View>
        );
    }
}

const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#2d2e37',
        flex:1,
        marginTop: 0
    },
    tab1: {
      height: 60, 
      width: '50%', 
      backgroundColor: '#000', 
      borderBottomWidth: 2,  
      borderBottomColor: '#ff7200', 
      borderRightWidth: 1,  
      borderRightColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    tab2: {
      height: 60, 
      width: '50%', 
      borderWidth: 0, 
      borderLeftWidth: 0, 
      borderColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    innerBlock: {fontSize: 10, color: '#fff', paddingTop: 5, fontWeight: 'bold', paddingLeft: 20, paddingTop: 10},
    middleLine: {borderBottomWidth: 2, borderColor: '#ff7200', width: 50, marginLeft: 20},
    headerLine: { color: '#fff', fontWeight: 'bold', fontSize: 55, textAlign: 'left', paddingLeft: 20},
    iconstyle: {textAlign: 'right', padding: 5}



});


module.exports = ProfileDetails;

