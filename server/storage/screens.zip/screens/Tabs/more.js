import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, Alert, AsyncStorage, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, ToastAndroid, Keyboard, Dimensions, ActivityIndicator } from 'react-native';

import { onSignIn, isSignedIn, onSignOut, getAllAsyncStroage, removeBLE } from '../../../config/auth';
import styles from './styles.js'
var {width, height} = Dimensions.get('window');

import StatusBarBackground from '../../screens/Tabs/statusbar.js'
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon from 'react-native-vector-icons/Ionicons';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';

import { request } from 'graphql-request'


export default class More extends Component {

  constructor(props) {
      super(props);
      this.state={
        upload_uri: "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg",
        contentLoader: true
      }
  }
  async componentWillMount(){
 
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        console.log(USER_ID)
        this._getStudentDetails(USER_ID);    

  }

  _getStudentDetails = async (id) => {

        const query = `query profile_details($user_id:Int!){

                profile_details(user_id: $user_id) {
                    profile_image_url                   
                }

                }`;

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
            .then(async data => {
                console.log(data.profile_details[0], "kkkk")

                response = data.profile_details[0]

                if(response.profile_image_url != null) {
                
                  this.state.upload_uri = response.profile_image_url

                }

                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )

  }



  alert = (value) => {
        const {navigate} = this.props.navigation;
        if(value == 'Calendar') {
          navigate("CalendarView")
        } else if(value == 'LOGOUT') {
          onSignOut();
          navigate("SignedOut")
        } else if(value == 'DEVICE') {
           navigate('SearchDevices', {fromRoute:'More', toRoute:'SearchDevices', enableBack:false})
        } else if(value == 'REMOVE') {
          removeBLE();
          navigate('Tabs', {fromRoute:'More', toRoute:'Tabs', enableBack:false})

        } else if(value == 'PROFILE') {
          navigate("Tabs", {showProfile: true,showFeed: null,showNotification: null,showMore: null})
        } else if(value == 'FEED') {
          navigate("Tabs", {showProfile: false,showFeed: true,showNotification: null,showMore: null})
        } else if(value == 'NOTIFICATION') {
          navigate("Tabs", {showProfile: false,showFeed: null,showNotification: true,showMore: null})
        }else {
          alert("Page in Dovelopment")
        }
        
  }


  render() {

    console.log(this.state.upload_uri)

    return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

                {this.state.contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                  <View style={style.body}>
                    <View style={{height: 230, backgroundColor: '#2d2e37',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: width,padding: 10, }}>
                                <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 18, textAlign: 'center'}}>Menu</Text>
                            </View>

                        </View>


                        <View style={{alignItems: 'center', padding: 10, bottom: 20}}>

                            <Image
                            style={{
                                paddingVertical: 30,
                                width: 150,
                                height: 150,
                                borderRadius: 75
                            }}
                            resizeMode='cover'
                            source={{
                                uri: this.state.upload_uri
                            }}
                            />
                        </View>


                    </View>
  

                    <View style={{flex: 1, flexDirection: 'column', marginTop: 20, height: 600}}>

                        <ScrollView style={{flex: 1, }}>

                           <TouchableOpacity onPress={() => this.alert('Calendar')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>CALENDAR</Text></View>
                           </TouchableOpacity>
                           <TouchableOpacity onPress={() => this.alert('DEVICE')}>
                            <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>CONNECT DEVICE</Text></View>
                           </TouchableOpacity>                           
                           <TouchableOpacity onPress={() => this.alert('REMOVE')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>REMOVE DEVICE</Text></View>
                           </TouchableOpacity>
                           <TouchableOpacity onPress={() => this.alert('FEED')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>FEED</Text></View>
                           </TouchableOpacity>
                            <TouchableOpacity onPress={() => this.alert('PROFILE')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>PROFILE</Text></View>
                           </TouchableOpacity>                           
                           <TouchableOpacity onPress={() => this.alert('NOTIFICATION')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>NOTIFICATION</Text></View>
                           </TouchableOpacity>                           
                           <TouchableOpacity onPress={() => this.alert('LOGOUT')}>
                           <View style={{padding: 12}}><Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>LOGOUT</Text></View>
                           </TouchableOpacity>
                        </ScrollView>

                    </View>                    

                    </View>

                  }

            </View>
    );
  }
}


const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#2d2e37',
        flex:1,
        marginTop: 0
    }
});
