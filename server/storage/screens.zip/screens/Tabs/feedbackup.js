<ScrollView
            style={{flex:1}}
            contentContainerStyle={{paddingBottom: 50}}
            indicatorStyle={'white'}
            scrollEventThrottle={200}
            directionalLockEnabled={true}
          >
            <View style={styles.listofWrkouts1}>


              <View style={styles.header}>
                    <Text style={styles.topSignupTxt}>
                      Feed
                    </Text>
              </View>

              <View>
                <Text style = {styles.text_workout_heading}>
                  Hey {this.state.user.name}!
                </Text>
                <Text style = {styles.text_workout_sub_heading}>
                  REMAINDER TO STAY STRONG AND KEEP YOUR GOALS IN MIND
                </Text>
              </View>

              <View style={styles.slidertop_btns}>
                <View style={{flex:1,flexDirection:'row',justifyContent:'center',alignItems:'center'}}>
                  <View style = {{flex:0.28,alignItems:'center',justifyContent:'center',}}>
                  <TouchableOpacity>
                    <View style={styles.gradi_btns}>
                      <Text style={styles.gradi_NormalbtnsTxtBtn}>
                          Distance
                      </Text>
                      <View style={styles.gradiPagBtns}></View>
                    </View>
                  </TouchableOpacity>
                  </View>
                  <View style = {{flex:0.28,alignItems:'center',justifyContent:'center',}}>
                  <TouchableOpacity>
                  <View style={styles.gradi_btns}>
                    <Text style={styles.gradi_NormalbtnsTxtBtn}>
                        Weights
                    </Text>
                    <View style={styles.gradiPagBtns}></View>
                  </View>
                  </TouchableOpacity>
                  </View>
                  <View style = {{flex:0.28,alignItems:'center',justifyContent:'center',}}>
                  <TouchableOpacity>
                  <View style={styles.gradi_btns}>
                    <Text style={styles.gradi_btnsTxtBtn}>
                        Conditioning
                    </Text>
                    <Image style={{ width: 86, height: 32 }} source={{uri:'gradi_btn'}} />
                    </View>
                  </TouchableOpacity>
                  </View>
                  <View style = {{flex:0.16,alignItems:'center',justifyContent:'center',}}>
                    <TouchableOpacity >
                        <View>
                          <Feather name="sliders" size={25} color='#fff' />
                        </View>
                    </TouchableOpacity>

                  </View>

                </View>
              </View>
            </View>


            {loader?
              <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
              />
            :

            <ScrollView
              style={{flex:1, paddingBottom: 10, marginBottom: 20}}
              contentContainerStyle={{paddingBottom: 50}}
              indicatorStyle={'white'}
              scrollEventThrottle={200}
              directionalLockEnabled={true}
            >
            {this.state.feeds.map((data1)=>{
              console.log(data1)
              console.log(this.state.feeds)
              const feed_data = data1[1]
              console.log(data1[1])
              return(
                <View style={{borderBottomWidth:4}}>
                    <Carousel
                      ref={(c) => { if (!this.state.slider1Ref) { this.setState({ slider1Ref: c }); } }}
                      data={feed_data}
                      renderItem={this._renderWorkout}
                      sliderWidth={sliderWidth}
                      itemWidth={230}
                      itemHeight={300}
                      hasParallaxImages={false}
                      firstItem={0}
                      containerCustomStyle={{marginTop: 15}}
                      itemWidth={itemWidth}
                      enableSnap = {true}
                      lockScrollWhileSnapping = {false}
                      onSnapToItem={(index) => this.setState({ slider1ActiveSlide: index }) }
                    />
                  </View>
              )
            }
            )}
            </ScrollView>
            }

          </ScrollView>




          <View style={styles.btm_tabNavigation}>
              <View style = {{flex:1,flexDirection:'column',alignItems:'center',justifyContent:'center'}}><Image style={{ width: 32, height: 28, top:3, position:'absolute' }} source={{uri:'feedicon_a'}} /><Text style={{fontSize:10,color:'#fff', marginTop:12}}>FEED</Text></View>
              <View style = {{flex:1,flexDirection:'column',alignItems:'center',justifyContent:'center'}}><Image style={{ width: 28, height: 28, top:3, position:'absolute'  }} source={{uri:'profileicon_a'}} /><Text style={{fontSize:10,color:'#fff', marginTop:12}}>PROFILE</Text></View>
              <View style = {{flex:1,flexDirection:'column',alignItems:'center',justifyContent:'center'}}><Image style={{ width: 45, height: 45, marginTop:3 }} source={{uri:'bottom_tab_middlelogo_a'}} /><Text style={{fontSize:10,color:'#fff', marginTop:12}}> </Text></View>
              <View style = {{flex:1,flexDirection:'column',alignItems:'center',justifyContent:'center'}}><Image style={{ width: 28, height: 31, top:3, position:'absolute'  }} source={{uri:'notificationicon_a'}} /><Text style={{fontSize:10,color:'#fff', marginTop:12}}>NOTIFICATION</Text></View>
              <View style = {{flex:1,flexDirection:'column',alignItems:'center',justifyContent:'center'}}><Image style={{ width: 28, height: 28, top:3, position:'absolute'  }} source={{uri:'btnmenuicon_a'}} /><Text style={{fontSize:10,color:'#fff', marginTop:12}}>MORE</Text></View>
          </View>