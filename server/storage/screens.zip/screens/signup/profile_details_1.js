import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';
import axios from 'axios';
import { Slider } from 'react-native-elements'
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

import { request } from 'graphql-request'


export default class ProfileDetails1 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            date: null,
            gender: 0,
            genderatbirth: 0,
            userid: null,
            contentLoader: true,
            password: ""
        };



    }

    componentWillMount() {


        getAllAsyncStroage()
            .then(res => console.log(res)
        )
            .catch(err => console.log(err)
        );
        this.getStudentID();


        var {date, gender, genderatbirth} = this.props.navigation.state.params;

        console.log(this.state)

        if (date != null) {
            this.state.date = date
        }
        if (gender != null) {
            this.state.gender = gender
        }
        if (genderatbirth != null) {
            this.state.genderatbirth = genderatbirth
        }


    }

    getStudentID =async() => {

        let USER_ID = await AsyncStorage.getItem("USER_ID");
        //let USER_ID = 220
        this.setState({
            userid: USER_ID,
            enable: false,
            Loader: true
        }, () => {
            this._getStudentDetails(this.state.userid);
        });
    }
    _getStudentDetails= async(id) => {
        /*
        getProfileDetails(id).then(response => {
            if (response.status) {
                this.setState({
                    profile: response.data
                }, () => {
                    var gender = this.state.profile.gender
                    this.setState({
                        date: this.state.profile.dob
                    })

                    if (this.state.profile.gender == 'Male') {
                        this.setState({
                            gender: 0,
                            genderatbirth: 0
                        })
                    } else if (this.state.profile.gender == 'Female') {
                        this.setState({
                            gender: 2,
                            genderatbirth: 2
                        })
                    } else {
                        this.setState({
                            gender: 1,
                            genderatbirth: 1
                        })
                    }

                });
                console.log(this.state)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            } else {
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
            }
        }, err => {
            console.log(err)
        })

        */


        if(this.props.navigation.state.params) {

            const { secondstep} = this.props.navigation.state.params

            if(secondstep == 1) {

                const query = `query profile_details($user_id:Int!){

                        profile_details(user_id: $user_id) {
                        dob,
                        gender,
                        gender_identity,
                        password
                        }

                        }`;

                const variables = {
                    user_id: id,
                }

                request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {
                        response = data.profile_details[0]
                        console.log(data.profile_details[0])

                        this.setState({
                            date: response.dob
                        })

                        this.setState({
                            password: response.password
                        })

                        if (response.gender == 'Male') {
                            this.setState({
                                gender: 0,
                            })
                        } else if (response.gender == 'Female') {
                            this.setState({
                                gender: 2,
                            })
                        } else {
                            this.setState({
                                gender: 1,
                            })
                        }

                        if (response.gender_identity == 'Male') {
                            this.setState({
                                genderatbirth: 0,
                            })
                        } else if (response.gender_identity == 'Female') {
                            this.setState({
                                genderatbirth: 1,
                            })
                        }

                        console.log(this.state)
                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })                    

                    }
                )
                    .catch(async err => {
                        //console.log(err.response.errors)
                        //console.log(err.response.data)
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })
                    }
                )


            }
            else {


                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })    
                
            }

        }        




    }

    /*

      nextStep(date, gender, genderatbirth) {

        if(date!=null&&gender!=null&&genderatbirth!=null){
        const { navigate } = this.props.navigation;
        navigate('ProfileDetails2', {})
        } else {
          alert('Please Fill All Fields')
        }

      }

    */


    nextStep = async() => {


        const {date, gender, genderatbirth, userid} = this.state


        this.setState({
            contentLoader: true
        })

        if (date != null && gender != null && genderatbirth != null) {

            if (gender == 0) {
                var gender_text = 'Male'
            } else if (gender == 2) {
                var gender_text = "Female"
            } else {
                var gender_text = "Other"
            }

            if (genderatbirth == 0) {
                var gender_text_birth = 'Male'
            } else {
                var gender_text_birth = "Female"
            }


            var datenow = new Date();
            var presentyear = datenow.getFullYear();
            var dateofbirth = date.split("/");
            var dateofbirthyear = dateofbirth[2]
            let USER_ID = await AsyncStorage.getItem("USER_ID");

            var age = presentyear - dateofbirthyear

            data = {
                "dob": date,
                "gender": gender_text,
                "id": USER_ID,
                "age": age,
            }

            console.log(data)

            //this.setState({contentLoader: false})

            /*

            axios.put(API.UpdateProfile, data).then(async response => {
                if (response.status == 200) {
                    console.log(response)
                    //this.setState({contentLoader: false})
                    const {navigate} = this.props.navigation;
                    navigate("ProfileDetails2", {
                        feet: null,
                        inches: null,
                        weight: null,
                        system: 0,
                        height_in_metric: null
                    })

                }
            }).catch(err => {
                console.log(err)
            })

            */

            let password = await AsyncStorage.getItem("PASSWORD");


            const query = `mutation edit_profile_details($password: String!, $dob:String!, $id:Int!, $gender: String!, $gender_identity: String!){

                edit_profile_details(id: $id, dob: $dob, gender_identity: $gender_identity, gender: $gender, password: $password) {

                    status

                }

                }`;

            //schollname = this.state.schoolname

            const variables = {
                id: Number(userid),
                dob: date,
                campus_group: "",
                gender: gender_text,
                gender_identity: gender_text_birth,
                password: password
            }

            console.log(variables)

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                .then(async data => {
                    console.log(data)

                    if (data.edit_profile_details[0].status == 'success') {
                        //console.log(response)
                        //AsyncStorage.setItem("USER_NAME", String(this.state.username));
                        alert('Updated')
                        const {navigate} = this.props.navigation;
                        navigate("ProfileDetails2", {
                            feet: null,
                            inches: null,
                            weight: null,
                            system: 0,
                            height_in_metric: null,
                            password: password
                        })
                    }

                }
            )
                .catch(async err => {
                    console.log(err.response.errors)
                    console.log(err.response.data)
                    console.log(err)
                    alert("Something Went Wrong, Please try again later")
                    this.setState({
                        contentLoader: false
                    })
                }
            )



        } else {
            alert('Please Fill the fields')
            this.setState({
                contentLoader: false
            })
        }


    //navigate("UserInfo2")    
    }



    render() {
        const {navigate} = this.props.navigation;
        const {loader, username, password, showErrorUsername, showErrorPassword, errorUsernameMessage, errorPasswordMessage, contentLoader} = this.state;

        var {date} = this.props.navigation.state.params;
        if (date != null) {
            this.state.date = date
        }

        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;

                const {secondstep} = this.props.navigation.state.params

                navigate('ProfileFill', {
                    userinfo: 0,
                    profiledetails: 1,
                    pickclass: 0,
                    secondstep: secondstep
                })
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Profile details (1/2)
            </Text>
          </View>

          {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :

                <View style={{
                    flex: 1,
                    flexDirection: 'column'
                }}>
              <View style={{
                    height: (height - 140) / 3,
                    borderBottomWidth: 1
                }}>
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;
                    navigate('SelectDataofBirth', {
                        date: this.state.date,
                        gender: this.state.gender,
                        genderatbirth: this.state.genderatbirth
                    })
                }}>              
                <View style={{
                    width: width,
                    height: 80
                }}>
                  <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>                 
                    <View style={{
                    width: width - 50,
                    height: 50
                }}>
                    {this.state.date == null ?
                    <Text style={{
                        textAlign: "center",
                        marginTop: 66,
                        fontSize: 20,
                        width: '100%',
                        marginLeft: 6,
                        color: "#fff"
                    }}> Date of birth </Text>
                    :
                    <Text style={{
                        textAlign: "center",
                        marginTop: 66,
                        fontSize: 20,
                        width: '100%',
                        marginLeft: 6,
                        color: "#fff"
                    }}> {this.state.date} </Text>
                }
                    </View>
                    <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 70
                }} ><Icon name="chevron-right" size={25} color="#FF7E00"/></View>
                  </View>              
                </View>
                </TouchableOpacity>                              
              </View>                            
              <View style={{
                    height: (height - 140) / 3,
                    borderBottomWidth: 1
                }}>
                  <View style={{
                    flex: 1,
                    alignItems: 'stretch',
                    justifyContent: 'center',
                    width: 200,
                    alignSelf: 'center',
                    marginTop: 40
                }}>
                  <Text style={{
                    textAlign: "center",
                    paddingBottom: 10,
                    fontSize: 16,
                    width: '100%',
                    marginLeft: 6,
                    color: "#fff"
                }}> Gender Identity</Text>                                  
                    <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'stretch',
                    justifyContent: 'center',
                    width: 200,
                    alignSelf: 'center'
                }}>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Male</Text>
                      </View>
                      <View style={{
                    width: width / 2
                }}>

                        <Slider
                value={this.state.gender}
                step={1}
                minimumValue={0}
                maximumValue={2}
                onValueChange={(value) => this.setState({
                    gender: value
                })} />

                      </View>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Female</Text>
                      </View>                      

                    </View>
                  </View>                                         
               </View> 
              <View style={{
                    height: (height - 140) / 3
                }}>
                  <View style={{
                    flex: 1,
                    alignItems: 'stretch',
                    justifyContent: 'center',
                    width: 200,
                    alignSelf: 'center',
                    marginTop: 40
                }}>
                  <Text style={{
                    textAlign: "center",
                    paddingBottom: 10,
                    fontSize: 16,
                    width: '100%',
                    marginLeft: 6,
                    color: "#fff"
                }}> Gender at birth (BMR calc) </Text>                                  
                    <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    alignItems: 'stretch',
                    justifyContent: 'center',
                    width: 200,
                    alignSelf: 'center'
                }}>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Male</Text>
                      </View>
                      <View style={{
                    width: width / 2
                }}>

                        <Slider
                value={this.state.genderatbirth}
                step={1}
                minimumValue={0}
                maximumValue={1}
                onValueChange={(value) => this.setState({
                    genderatbirth: value
                })} />

                      </View>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Female</Text>
                      </View>                      

                    </View>
                  </View>                                         
               </View>              
            </View>

            }

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.nextStep()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save and continue</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>            

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}

