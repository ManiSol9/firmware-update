/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput } from 'react-native';


import Orientation from 'react-native-orientation';


import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { LineChart, YAxis } from 'react-native-svg-charts'
import { LinearGradient, Stop } from 'react-native-svg'

import * as shape from 'd3-shape'
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { AsyncStorage } from "react-native";


import styles from '../styles.js'

export default class PickCourse3 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            workoutdata: null,
            user_id: ''
        }
    }


    async componentWillMount() {}


    getWorkoutDetails(workoutID) {}


    render() {
        const {navigation} = this.props
        const resizeMode = 'center';
        const text = 'I am some centered text';
        return (

            <View style={styles.mainBody} >


            <ScrollView
            style={{
                flex: 1
            }}
            contentContainerStyle={{
                paddingBottom: 50
            }}
            indicatorStyle={'white'}
            scrollEventThrottle={200}
            directionalLockEnabled={true}
            >
              <View style={styles.listofWrkouts21}>

                <View style={styles.header_wrkout_details}>
                       <Image style={{
                width: Dimensions.get('window').width,
                height: 260
            }} source={{
                uri: this.state.ImageUrl
            }} />
                <View style={styles.chevron_left_icon}>
                  <TouchableOpacity onPress={() => this.onPressChevronLeft()}>
                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                  </TouchableOpacity>
                </View>
                </View>
                <View>
                    <Text style={styles.wrkdetails_name1}>
                      {this.state.Title}
                    </Text>
                    <View style={styles.wrkdetails_name1abc_mas}>
                      <Text style={styles.wrkdetails_name1a}> {this.state.Duration} MIN!</Text>
                      {this.state.intensity < 5 ? <Text style={styles.wrkdetails_name1b}> LOW LEVEL</Text>
                : <Text style={styles.wrkdetails_name1b}> HARD LEVEL</Text>}
                      <Text style={styles.wrkdetails_name1c}>{this.state.tags}</Text>
                    </View>
                </View>

              </View>





            </ScrollView>


        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress = {() => this.nextpage()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                    

                    <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Start Workout</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 




            </View>

        );
    }
}
