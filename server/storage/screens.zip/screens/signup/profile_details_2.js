import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator, contentLoader } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';
import { Slider } from 'react-native-elements'
import API from '../../template/constants.js';
import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

import { request } from 'graphql-request'

export default class ProfileDetails2 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            weight: null,
            weight_test: null,
            feet: null,
            feet_test: null,
            inches: null,
            inches_test: null,
            weight_in_kgs: null,
            weight_in_kgs_test: null,
            height_in_metric: null,
            height_in_metric_test: null,
            height: null,
            system: 0,
            showBMR: false,
            contentLoader: false,
            password: ""
        };
    }

    componentWillMount() {


        getAllAsyncStroage()
            .then(res => console.log(res)
        )
            .catch(err => console.log(err)
        );

        var {feet, inches, weight, system, height_in_metric, weight_in_kgs, password} = this.props.navigation.state.params;

        console.log(this.props)

        if (feet != null) {
            this.setState({
                feet: feet
            })
            this.setState({
                feet_test: feet
            })
        }

        if (inches != null) {
            this.setState({
                inches: inches
            })
            this.setState({
                inches_test: inches
            })
        }

        if (weight != null) {
            this.setState({
                weight: weight
            })
            this.setState({
                weight_test: weight
            })
        }

        if (system != null) {
            this.setState({
                system: system
            })
        }

        if (height_in_metric != null) {
            this.setState({
                height_in_metric: height_in_metric
            })
            this.setState({
                height_in_metric_test: height_in_metric
            })
        }

        if (weight_in_kgs != null) {
            this.setState({
                weight_in_kgs: weight_in_kgs
            })
            this.setState({
                weight_in_kgs_test: weight_in_kgs
            })
        }

        if (password != null) {
            this.setState({
                password: password
            })
        }

    }

    nextStep =async() => {

        this.setState({
            contentLoader: true
        })

        const {feet, inches, weight_in_kgs, weight, height, height_in_metric, system} = this.state

        console.log(this.props.navigation.state.params)

        let USER_ID = await AsyncStorage.getItem("USER_ID");
        let password = await AsyncStorage.getItem("PASSWORD");

        //let USER_ID = 220

        if (((feet != null || inches != null) || height_in_metric != null) && (weight != null || weight_in_kgs != null)) {

            if (system == 0) {
                variables = {
                    height_in_feet: Number(feet),
                    height_in_inches: Number(inches),
                    current_weight_in_lbs: Number(weight),
                    id: Number(USER_ID),
                    parameter_type: 1,
                    password: password
                }
            } else {
                variables = {
                    height_in_meters: Number(height_in_metric),
                    current_weight_in_kgs: Number(weight_in_kgs),
                    id: Number(USER_ID),
                    parameter_type: 2,
                    password: password
                }
            }

            console.log(variables)

            /*

            axios.put(API.UpdateProfile, data).then(async response => {
                if (response.status == 200) {
                    console.log(response)

                    alert('Details Updated')

                    const {navigate} = this.props.navigation;

                    navigate("ProfileFill", {
                        userinfo: 0,
                        profiledetails: 0,
                        pickclass: 1
                    })

                }
            }).catch(err => {
                console.log(err)
            })

            */

            console.log(system)


            if (system == 0) {

                var query = `mutation edit_profile_details($password: String!, $height_in_feet:Int!, $id:Int!, $height_in_inches: Int!, $current_weight_in_lbs: Int!, $parameter_type: Int!){

                edit_profile_details(password: $password, id: $id, height_in_feet: $height_in_feet, height_in_inches: $height_in_inches, current_weight_in_lbs: $current_weight_in_lbs, parameter_type: $parameter_type) {

                    status

                }

                }`;

            } else {


                var query = `mutation edit_profile_details($password: String!, $height_in_meters:Int!, $id:Int!, $current_weight_in_kgs: Int!, $parameter_type: Int!){

                edit_profile_details(password: $password, id: $id, height_in_meters: $height_in_meters, current_weight_in_kgs: $current_weight_in_kgs, parameter_type: $parameter_type) {

                    status

                }

                }`;

            }

            //schollname = this.state.schoolname

            /*

            const variables = {
                id: 220,
                dob: date,
                campus_group: "",
                gender: gender_text,
                gender_identity: gender_text_birth

            }

            */

            console.log(variables)

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                .then(async data => {
                    console.log(data)

                    if (data.edit_profile_details[0].status == 'success') {
                        //console.log(response)
                        //AsyncStorage.setItem("USER_NAME", String(this.state.username));

                        alert('Details Updated')

                        const {navigate} = this.props.navigation;

                        navigate("ProfileFill", {
                            userinfo: 0,
                            profiledetails: 0,
                            pickclass: 1
                        })

                    }

                }
            )
                .catch(async err => {
                    //console.log(err.response.errors)
                    //console.log(err.response.data)
                    console.log(err)
                    alert("Something Went Wrong, Please try again later")
                    this.setState({
                        contentLoader: false
                    })
                }
            )

        } else {
            alert('Please Fill the fields')
            this.setState({
                contentLoader: false
            })
        }


    }

    systemChange = (value) => {

        console.log('value', value)
        this.setState({
            system: value
        })
        console.log('system', this.state.system)
        // this.setState({feet: null})
        // this.setState({inches: null})
        // this.setState({weight: null})
        // this.setState({weight_in_kgs: null})
        // this.setState({height_in_metric: null})
        if (!value) {
            console.log('if')
            console.log('weight_in_kgs_test,weight_in_kgs', this.state.weight_in_kgs_test, this.state.weight_in_kgs)
            if (!(this.state.weight_in_kgs_test === null)) {
                let weight = (this.state.weight_in_kgs_test / 0.45359)
                let round_weight = Math.floor(weight)
                if ((weight - round_weight) > 0.8) {
                    round_weight = round_weight + 1
                }

                this.setState({
                    weight: round_weight,
                    weight_test: weight
                })
            }
            if (!(this.state.height_in_metric_test === null)) {
                let inches_test = this.state.height_in_metric_test * 0.39370079
                let feet_test = inches_test * 0.08333333

                let round_feet = Math.floor(feet_test)
                let inches = (feet_test - round_feet) * 12.0

                let round_inches = Math.floor(inches)
                if ((inches - round_inches) > 0.8) {
                    round_inches = round_inches + 1
                }
                this.setState({
                    feet: round_feet,
                    feet_test: round_feet,
                    inches: round_inches,
                    inches_test: inches
                })
            }
        } else {
            console.log('else')
            console.log('weight_test,weight', this.state.weight_test, this.state.weight)
            if (!(this.state.weight_test === null)) {
                let weight_in_kgs = (this.state.weight_test * 0.45359)
                let round_weight_in_kgs = Math.floor(weight_in_kgs)
                if ((weight_in_kgs - round_weight_in_kgs) > 0.8) {
                    round_weight_in_kgs = round_weight_in_kgs + 1
                }
                this.setState({
                    weight_in_kgs: round_weight_in_kgs,
                    weight_in_kgs_test: weight_in_kgs
                })
            }
            if ((!(this.state.feet_test === null)) && (!(this.state.inches_test === null))) {
                let height_in_centimeter = this.state.feet_test * 30.48 + this.state.inches_test * 2.54
                let round_height_in_centimeter = Math.floor(height_in_centimeter)
                if ((height_in_centimeter - round_height_in_centimeter) > 0.8) {
                    round_height_in_centimeter = round_height_in_centimeter + 1
                }
                this.setState({
                    height_in_metric: round_height_in_centimeter,
                    height_in_metric_test: height_in_centimeter
                })

            }
        }

    }

    BmrCaliculate = () => {

        if (this.state.system == 1 && this.state.weight_in_kgs != null && this.state.height_in_metric != null) {
            var BMR = 10 * this.state.weight_in_kgs + 6.25 * this.state.height_in_metric - 5 * 27 + 5 // BMR formula

            this.setState({
                showBMR: true
            })

        } else if (this.state.feet != null && this.state.inches != null && this.state.weight != null) {

            var height_in_cms = (this.state.feet * 30.48) + (this.state.inches * 2.54)

            var weight_in_lbs = this.state.weight * 0.45359

            var BMR = 10 * weight_in_lbs + 6.25 * height_in_cms - 5 * 27 + 5 // BMR formula

            this.setState({
                showBMR: true
            })
        }
    }


    render() {

        var {contentLoader} = this.state


        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('ProfileDetails1', {
                    date: null,
                    feet: null,
                    inches: null,
                    height_in_metric: null,
                    weight: null,
                    weight_in_kgs: null,
                    secondstep: 1
                })
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Profile details (2/2)
            </Text>
          </View>

          {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :

                <View style={{
                    flex: 1,
                    flexDirection: 'column'
                }}>
              <View style={{
                    height: (height - 140) / 4,
                    borderBottomWidth: 1
                }}>
                    <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    marginTop: 40,
                    alignItems: 'stretch',
                    justifyContent: 'center',
                    width: 200,
                    alignSelf: 'center'
                }}>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Imperial</Text>
                      </View>
                      <View style={{
                    width: width / 2
                }}>

                        <Slider
                value={this.state.system}
                step={1}
                minimumValue={0}
                maximumValue={1}
                onValueChange={(value) => this.systemChange(value)} />

                      </View>
                      <View style={{
                    width: width / 4
                }}>
                        <Text style={{
                    textAlign: "center",
                    marginTop: 10,
                    fontSize: 15,
                    marginLeft: 0,
                    color: "#fff"
                }}>Metric</Text>
                      </View>                      

                    </View>                                             
              </View>                            
             <View style={{
                    height: (height - 140) / 4,
                    borderBottomWidth: 1
                }}>                   
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;
                    navigate('SelectHeight', {
                        feet: this.state.feet,
                        inches: this.state.inches,
                        system: this.state.system,
                        weight: this.state.weight,
                        height_in_metric: this.state.height_in_metric,
                        weight_in_kgs: this.state.weight_in_kgs,
                        password: this.state.password
                    })
                }}>              
                <View style={{
                    width: width,
                    height: 80
                }}>
                  <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>                 
                    <View style={{
                    width: width - 50,
                    height: 50
                }}>
                    { (this.state.feet != null && this.state.system == 0) ?
                    <Text style={{
                        textAlign: "center",
                        marginTop: 55,
                        fontSize: 20,
                        width: '100%',
                        marginLeft: 6,
                        color: "#fff"
                    }}> {this.state.feet}'{this.state.inches}" </Text>
                    :
                    (this.state.height_in_metric != null && this.state.system == 1) ?
                        <Text style={{
                            textAlign: "center",
                            marginTop: 55,
                            fontSize: 20,
                            width: '100%',
                            marginLeft: 6,
                            color: "#fff"
                        }}> { this.state.height_in_metric } cm</Text>
                        :
                        <Text style={{
                            textAlign: "center",
                            marginTop: 55,
                            fontSize: 20,
                            width: '100%',
                            marginLeft: 6,
                            color: "#fff"
                        }}> Height </Text>
                }                   
                    </View>
                    <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 60
                }}><Icon name="chevron-right" size={25} color="#FF7E00"   /></View>
                  </View>              
                </View>
                </TouchableOpacity>           
              </View>
              <View style={{
                    height: (height - 140) / 4,
                    borderBottomWidth: 1
                }}>
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;
                    navigate('SelectWeight', {
                        feet: this.state.feet,
                        inches: this.state.inches,
                        system: this.state.system,
                        weight: this.state.weight,
                        height_in_metric: this.state.height_in_metric,
                        weight_in_kgs: this.state.weight_in_kgs,
                        password: this.state.password
                    })
                }}>              
                <View style={{
                    width: width,
                    height: 80
                }}>
                  <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>                 
                    <View style={{
                    width: width - 50,
                    height: 50
                }}>
                    {(this.state.weight != null && this.state.system == 0) ?
                    <Text style={{
                        textAlign: "center",
                        marginTop: 55,
                        fontSize: 20,
                        width: '100%',
                        marginLeft: 6,
                        color: "#fff"
                    }}> {this.state.weight} lbs </Text>
                    :
                    (this.state.weight_in_kgs != null && this.state.system == 1) ?
                        <Text style={{
                            textAlign: "center",
                            marginTop: 55,
                            fontSize: 20,
                            width: '100%',
                            marginLeft: 6,
                            color: "#fff"
                        }}> {this.state.weight_in_kgs} Kg </Text>
                        :
                        <Text style={{
                            textAlign: "center",
                            marginTop: 55,
                            fontSize: 20,
                            width: '100%',
                            marginLeft: 6,
                            color: "#fff"
                        }}> Weight </Text>
                }
                    </View>
                    <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 60
                }}><Icon name="chevron-right" size={25} color="#FF7E00" /></View>
                  </View>              
                </View>
                </TouchableOpacity>                                          
               </View>   
                         
            </View>

            }

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.nextStep()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>            

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
