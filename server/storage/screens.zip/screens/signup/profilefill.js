import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
const {height, width} = Dimensions.get('window');

import { TabNavigator } from 'react-navigation';

import { request } from 'graphql-request'

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

export default class ProfileFill extends Component {

    constructor(props) {
        super(props);
        this.state = {
            username: "",
            password: "",
            showErrorUsername: false,
            showErrorPassword: false,
            errorUsernameMessage: "",
            errorPasswordMessage: "",
            loader: false,
            userinfo: 0,
            profiledetails: 0,
            pickclass: 0,
        };
    }

    async componentWillMount() {

        const {userinfo, profiledetails, pickclass, firststep} = this.props.navigation.state.params

        console.log(this.props.navigation.state.params)

        if (userinfo != null) {
            this.setState({
                userinfo: userinfo
            })
        }
        if (profiledetails != null) {
            this.setState({
                profiledetails: profiledetails
            })
        }
        if (pickclass != null) {
            this.setState({
                pickclass: pickclass
            })
        }

        if (firststep != null) {
            this.setState({
                firststep: firststep
            })
        }

        let USER_ID = await AsyncStorage.getItem("USER_ID");
        console.log(USER_ID)

    }



    nextStep = () => {

        const {navigate} = this.props.navigation;

        const {firststep} = this.props.navigation.state.params

        const {userinfo, profiledetails, pickclass} = this.state

        if (userinfo == 1) {
            navigate("UserInfo1", {firststep : firststep})
        } else if (profiledetails == 1) {
            navigate('ProfileDetails1', {
                date: null,
                feet: null,
                inches: null,
                height_in_metric: null
            })
        } else if (pickclass == 1) {
            navigate("PickCourse")
        } else {
            navigate("UpcomingWorkouts")
        }

    }


    /*authenticating starts*/

    /*authenticating starts*/

    render() {
        const {navigate} = this.props.navigation;
        const {loader, username, password, showErrorUsername, showErrorPassword, errorUsernameMessage, errorPasswordMessage, userinfo, pickclass, profiledetails} = this.state;

        //this.state.userinfo = 1

        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>

          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              School sign up
            </Text>
          </View>
            <View style={{
                marginTop: 0,
                padding: 10
            }}>
              <View style={styles.body1}>
                <View style={{
                padding: 10
            }}>
                  <Text style={styles.forTxtHeader}>Welcome to the Resoltz app!</Text>
                  <Text style={styles.forTxt1}>Hi! We’re so exited to have you join the Resoltz community. </Text>
                  <Text style={styles.forTxt2}>You now have the power to achieve your wellness goals, on your own terms. Let’s get started!</Text>
                </View>
              </View>
            </View>

            <View style={{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'flex-start',
                marginTop: 20
            }}>

            {!!this.state.userinfo == 1 ?
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;

                    const {userinfo, profiledetails, pickclass, firststep} = this.props.navigation.state.params

                    navigate('UserInfo1', { firststep: firststep})
                }}>              
              <View style={{
                    width: width,
                    height: 80,
                }}>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#fff",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#fff"
                }}>1</Text>
                  </View>
                  <View style={{
                    width: 150,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    fontWeight: 'bold',
                    marginTop: 10,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#fff"
                }}>User Info</Text>
                  </View>
                  <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 13
                }} > 
                    <Icon name="chevron-right" size={25} color="#FF7E00"/> 
                  </View>
                </View>              
              </View>
              </TouchableOpacity>
                :
                <View style={{
                    width: width,
                    height: 80,
                }}>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#6B6464",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#6B6464"
                }}>1</Text>
                  </View>
                  <View style={{
                    width: 250,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    fontWeight: 'bold',
                    marginTop: 10,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#6B6464"
                }}>User Info</Text>
                  </View>
                </View>              
              </View>
            }
            {!!this.state.profiledetails == 1 ?
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;

                    const {secondstep} = this.props.navigation.state.params

                    navigate('ProfileDetails1', {
                        date: null,
                        feet: null,
                        inches: null,
                        height_in_metric: null,
                        secondstep: secondstep
                    })
                }}>              
              <View style={{
                    width: width,
                    height: 80
                }}>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#fff",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#fff"
                }}>2</Text>
                  </View>                  
                  <View style={{
                    width: 150,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    marginTop: 6,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#fff"
                }}>Profile Details</Text>
                  </View>
                  <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 13
                }}><Icon name="chevron-right" size={25} color="#FF7E00"/></View>
                </View>              
              </View>
              </TouchableOpacity>
                :
                <View style={{
                    width: width,
                    height: 80
                }}>
                <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#6B6464",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#6B6464"
                }}>2</Text>
                  </View>                  
                  <View style={{
                    width: 250,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    marginTop: 6,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#6B6464"
                }}>Profile Details</Text>
                  </View>
                </View>              
              </View>
            }
            {!!this.state.pickclass == 1 ?
                <TouchableOpacity onPress={() => {
                    const {navigate} = this.props.navigation;
                    navigate('PickCourse')
                }}>  
              <View style={{
                    width: width,
                    height: 80
                }}>
                  <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#fff",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#fff"
                }}>3</Text>
                  </View>                    
                  <View style={{
                    width: 150,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    marginTop: 10,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#fff"
                }}>Pick Course</Text>
                  </View>                    
                  <View style={{
                    width: 50,
                    height: 50,
                    marginTop: 13
                }}><Icon name="chevron-right" size={25} color="#FF7E00"   /></View>
                  </View>
              </View>
              </TouchableOpacity>
                :
                <View style={{
                    width: width,
                    height: 80
                }}>
                  <View style={{
                    flex: 1,
                    flexDirection: 'row',
                    justifyContent: 'space-between'
                }}>
                  <View style={{
                    borderWidth: 3,
                    borderRadius: 25,
                    borderColor: "#6B6464",
                    width: 50,
                    height: 50,
                    marginLeft: 20
                }}>
                    <Text style={{
                    textAlign: "center",
                    marginTop: 6,
                    fontSize: 25,
                    width: 20,
                    marginLeft: 12,
                    color: "#6B6464"
                }}>3</Text>
                  </View>                    
                  <View style={{
                    width: 250,
                    height: 50
                }}>
                    <Text style={{
                    textAlign: "left",
                    marginTop: 10,
                    fontSize: 25,
                    width: '100%',
                    marginLeft: -36,
                    color: "#6B6464"
                }}>Pick Class</Text>
                  </View>                    
                  </View>
              </View>
            }
            </View>

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.nextStep()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>


               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
