import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator, TouchableWithoutFeedback, contentLoader } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';
import { addAsyncStorage } from '../../../config/auth.js'

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
const {height, width} = Dimensions.get('window');

var Spinner = require('react-native-spinkit');

import { request } from 'graphql-request'

import dismissKeyboard from 'react-native/Libraries/Utilities/dismissKeyboard';


const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');


export default class Singup_New extends Component {

    constructor(props) {
        super(props);
        this.state = {
            email: null,
            isVisible: false,
            text: 'Useless Placeholder'
        };


    }

    componentWillMount() {}


    /*authenticating starts*/


    checkEmailSignup = async (mail) => {

        this.setState({
            isVisible: false
        })


        if (mail != null) {

            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

            if (!filter.test(mail)) {
                alert("Enter valid email address")
            } else {

                this.setState({
                    isVisible: true
                })

                const query = `mutation
                          adduser(
                          $email: String!, $role_id: Int!
                          ){
        adduser(
            email: $email, role_id: $role_id
            ){
        id
        status
                          }
                        }`


                const variables = {
                    email: this.state.email,
                    role_id: 1
                }

                request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/signin_mobile', query, variables)
                    .then(async data => {

                        console.log(data.adduser[0].status)

                        if (data.adduser[0].status == 'registered') {


                            alert("Registered successfully")
                            var userid = data.adduser[0].id
                            AsyncStorage.setItem("USER_ID", String(userid));
                            console.log(await AsyncStorage.getItem("USER_ID"))

                            const {navigate} = this.props.navigation;

                            navigate("ProfileFill", {
                                userinfo: 1,
                                profiledetails: 0,
                                pickclass: 0,
                                firststep: 0
                            })

                            this.setState({
                                isVisible: false
                            })


                        } else {


                            alert("Already Registered, go to login page")
                            this.setState({
                                isVisible: false
                            })


                        }

                    }
                )
                    .catch(async err => {
                        console.log(err.response.errors)
                        console.log(err.response.data)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            isVisible: false
                        })
                    }
                )

            }

        } else {

            alert("Enter valid email address")

        }


    }

    /*authenticating starts*/

    render() {
        const {navigate} = this.props.navigation;
        const {loader, username, password, showErrorUsername, showErrorPassword, errorUsernameMessage, errorPasswordMessage, isVisible} = this.state;
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('Login')
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              Sign up
            </Text>
          </View>
          {isVisible ?
                <View style={styles.activityIndicator}>
            <Spinner  isVisible={true} size={100} type="Bounce" color="#ff7200"/>
            </View>
                :
                <TouchableWithoutFeedback onPress={dismissKeyboard}>
            <View style= { {
                    flex: 0
                }}>
                <View
                style={{
                    marginTop: 50
                }}>
                <View style={styles.body1}>
                    <View style={{}}>
                    <Text style={styles.forTxt}>For students, sign up using your school email</Text>
 
                        <TextInput
                placeholder="email@school.com"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                placeholderTextColor='#626264'
                keyboardShouldPersistTaps={'handled'}
                style={styles.textInput_login}
                onChangeText={ (text) => this.setState({
                    email: text
                })}
                />
            
                        {showErrorUsername ? <Text style={{
                    color: '#fb620c'
                }}>{errorUsernameMessage}</Text> : null}

                    </View>             

                      <View style={{
                    marginTop: 30,
                    borderTopWidth: 2
                }}>
                        <Text style={styles.nonStudent}>Non students create an account using options below</Text>
                        <TouchableOpacity  style={styles.submitFB}>
                          <Icon name="facebook-f" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
                          <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
                          <Text style={styles.buttonText}>
                            Sign up with Facebook
                          </Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity  style={styles.submitTW}>
                          <Icon name="twitter" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
                          <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
                          <Text style={styles.buttonText}>
                            Sign up with Twitter
                          </Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity  style={styles.submitGM}>
                          <Icon name="google-plus" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
                          <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
                          <Text style={styles.buttonText}>
                            Sign up with Gmail
                          </Text>
                          </View>
                        </TouchableOpacity>
                      </View>
                    </View>
                </View>
            </View>
            </TouchableWithoutFeedback>
            }

            {isVisible ?

                <View></View>

                :

                <View style={{
                    bottom: 0,
                    position: 'absolute',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
              <TouchableOpacity onPress={() => this.checkEmailSignup(this.state.email)}>
                  <View style={{
                    zIndex: 999,
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: 50,
                    width: width
                }}>
                      

                      <Text style={{
                    backgroundColor: 'transparent',
                    alignSelf: 'center',
                    fontFamily: 'CircularStd-Black',
                    color: '#fff',
                    fontSize: 19
                }}>Save</Text>
            
                  </View>
                  <Image style={{
                    width: width,
                    height: 50,
                    position: 'absolute',
                    bottom: 0
                }} source={{
                    uri: 'btn_gradi_bg'
                }}/>
              </TouchableOpacity>
          </View>

            }

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />


      </View>
        );
    }
}
