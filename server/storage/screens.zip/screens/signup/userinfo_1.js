import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, TouchableWithoutFeedback, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'
const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

import dismissKeyboard from 'react-native/Libraries/Utilities/dismissKeyboard';

import { request } from 'graphql-request'


export default class UserInfo1 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            firstname: null,
            lastname: null,
            username: null,
            password: "",
            loader: false,
            userid: "",
            contentLoader: true
        };
    }

    componentWillMount() {

        getAllAsyncStroage()
            .then(res => console.log(res)
        )
            .catch(err => console.log(err)
        );
        this.getStudentID();
    }

    getStudentID =async() => {

        let USER_ID = await AsyncStorage.getItem("USER_ID");
        //let USER_ID = 220
        this.setState({
            userid: USER_ID,
            enable: false,
            Loader: true
        }, () => {
            this._getStudentDetails(this.state.userid);
        });
    }
    _getStudentDetails=(id) => {

        /*
        getProfileDetails(id).then(response => {
            if (response.status) {
                this.setState({
                    profile: response.data
                }, () => {
                    this.setState({
                        firstname: this.state.profile.first_name,
                        lastname: this.state.profile.last_name,
                        username: this.state.profile.user_name
                    })
                });
                console.log(this.state)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            } else {
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
            }
        }, err => {
            console.log(err)
        })

        */

        if(this.props.navigation.state.params) {

            const { firststep } = this.props.navigation.state.params

            if(firststep == 1) {

                const query = `query profile_details($user_id:Int!){

                        profile_details(user_id: $user_id) {

                        first_name,

                        last_name,

                        username

                        }

                        }`;

                const variables = {
                    user_id: Number(id),
                }

                request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                    .then(async data => {
                        response = data.profile_details[0]
                        console.log(data.profile_details[0])

                        this.setState({
                            firstname: response.first_name,
                            lastname: response.last_name,
                            username: response.username
                        })

                        console.log(this.state)
                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })

                    }
                )
                    .catch(async err => {
                        console.log(err.response.errors)
                        console.log(err.response.data)
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })
                    }
                )

            } else {

                        this.setState({
                            Loader: false,
                            contentLoader: false
                        })
                
            }

        }




    }


    nextstep = () => {
        //const { navigate } = this.props.navigation;

        console.log('saasddsada')

        const {firstname, lastname, username, userid} = this.state

        this.setState({
            contentLoader: true
        })


        if (firstname != null && lastname != null && username != null) {

            data = {
                "first_name": firstname,
                "last_name": lastname,
                "user_name": username,
                "id": Number(userid)
            }

            /*
            axios.put(API.UpdateProfile, data).then(async response => {
                if (response.status == 200) {
                    console.log(response)
                    AsyncStorage.setItem("USER_NAME", String(username));
                    const {navigate} = this.props.navigation;
                    this.setState({
                        contentLoader: false
                    })
                    alert('Updated')
                    navigate("UserInfo2", {
                        password: null,
                        confirmpassword: null,
                        schoolid: null,
                        schollname: null
                    })
                }
            }).catch(err => {
                console.log(err)
            })

            */


            const query = `mutation edit_profile_details($first_name:String!, $last_name:String!, $username:String!, $id:Int!){

                edit_profile_details(id: $id, first_name: $first_name, last_name: $last_name, username: $username, password: "") {

                    status

                }

                }`;

            console.log(query)

            const variables = {
                id: Number(userid),
                last_name: lastname,
                first_name: firstname,
                username: username,
                password: ""
            }

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
                .then(async data => {
                    console.log(data)

                    if (data.edit_profile_details[0].status == 'success') {
                        //console.log(response)
                        AsyncStorage.setItem("USER_NAME", String(username));
                        AsyncStorage.setItem("PROFILE_IMAGE", "");
                        const {navigate} = this.props.navigation;
                        this.setState({
                            contentLoader: false
                        })
                        alert('Updated')
                        navigate("UserInfo2", {
                            password: null,
                            confirmpassword: null,
                            schoolid: null,
                            schollname: null
                        })
                    }

                }
            )
                .catch(async err => {
                    console.log(err)
                    alert("Something Went Wrong, Please try again later")
                    this.setState({
                        contentLoader: false
                    })
                }
            )

        } else {
            alert('Please Fill the fields')
            this.setState({
                contentLoader: false
            })
        }

    }

    render() {
        const {navigate} = this.props.navigation;
        const {loader, username, password, showErrorUsername, showErrorPassword, errorUsernameMessage, errorPasswordMessage, contentLoader} = this.state;
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;

                const { firststep } = this.props.navigation.state.params

                if( firststep == 1) {
                    navigate('ProfileFill', {
                        userinfo: 1,
                        profiledetails: 0,
                        pickclass: 0,
                        firststep: 1
                    })
                } else {
                   navigate('ProfileFill', {
                        userinfo: 1,
                        profiledetails: 0,
                        pickclass: 0,
                        firststep: 0
                    })
                }

 
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              User Info (1/2)
            </Text>
          </View>

          {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View>
                <TouchableWithoutFeedback onPress={dismissKeyboard}>
            <View style={{
                    marginTop: 50
                }}>
              <View style={styles.body1}>
                <View style={{
                    marginTop: 25,
                    marginBottom: 25
                }}>
                  <TextInput
                placeholder="First name"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                placeholderTextColor='#626264'
                style={styles.textInput_login}
                value={this.state.firstname}
                onChangeText={ (text) => this.setState({
                    firstname: text
                })}
                onFocus={ () => this.setState({
                    showErrorUsername: false,
                    showErrorPassword: false
                })}
                />
                </View>

                <View style={{
                    marginTop: 25,
                    marginBottom: 25
                }}>
                  <TextInput
                placeholder="Last name"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                placeholderTextColor='#626264'
                style={styles.textInput_login}
                value={this.state.lastname}
                onChangeText={ (text) => this.setState({
                    lastname: text
                })}
                />
                </View>

                <View style={{
                    marginTop: 25,
                    marginBottom: 25
                }}>
                  <TextInput
                placeholder="Username"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                placeholderTextColor='#626264'
                style={styles.textInput_login}
                value={this.state.username}
                onChangeText={ (text) => this.setState({
                    username: text
                })}
                onFocus={ () => this.setState({
                    showErrorUsername: false,
                    showErrorPassword: false
                })}
                />
                </View>                            
              </View>
            </View>

            </TouchableWithoutFeedback>

            </View>



            } 

            <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
                <TouchableOpacity onPress={() => this.nextstep()}>
                    <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                        

                        <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save and continue</Text>
              
                    </View>
                    <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
                </TouchableOpacity>
            </View>

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
