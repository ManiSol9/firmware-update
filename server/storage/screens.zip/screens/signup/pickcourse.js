import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

import SearchInput, { createFilter } from 'react-native-search-filter';
const KEYS_TO_FILTERS = ['title'];

import { request } from 'graphql-request'


export default class PickCourse extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: null,
            schoolname: null,
            searchTerm: '',
            courses: [],
            contentLoader: true,
        };
    }
    searchUpdated(term) {
        this.setState({
            searchTerm: term
        })
    }
    componentWillMount() {

        console.log(this.props)

        this.getSchool()

    }



    getSchool = () => {

        const query = `{
            fetch_course{
                id
                title
                type
          }
        }`;

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_course', query)
            .then(async data => {
                console.log(data)
                this.state.courses = data.fetch_course
                this.setState({
                    contentLoader: false
                })

            }
        )
            .catch(async err => {
                console.log(err)
                alert('There is no schools or server problom')
                this.setState({
                    contentLoader: false
                })
            }
        )

    }


    selectcourse = (course) => {
        const {navigate} = this.props.navigation
        navigate("PickCourse2", {
            courseid: course.id, course: course
        })
    }

    nextstep = () => {



        if (this.state.selected != '') {

            const {navigate} = this.props.navigation

            const {password, confirmpassword} = this.props.navigation.state.params;

            //alert(password)

            navigate("UserInfo2", {
                password: password,
                confirmpassword: confirmpassword,
                schoolid: this.state.selected,
                schoolname: this.state.schoolname
            })

        } else {
            alert("Please select your school")
        }

    }

    render() {
        const {navigate} = this.props.navigation;
        const {courses, contentLoader} = this.state;

        console.log(courses)

        const filteredCourses = courses.filter(createFilter(this.state.searchTerm, KEYS_TO_FILTERS))

        let mani = 0


        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('ProfileFill', {
                    userinfo: 0,
                    profiledetails: 0,
                    pickclass: 1
                })
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"/>
            </TouchableOpacity>
          </View>
          <View style={styles.header1}>
            <Text style={styles.topSignupTxt}>
              Pick Course (1/2)
            </Text>
          </View>

        {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View>
          <View style={{
                    alignItems: 'center',
                    borderBottomWidth: 1
                }}>
            <SearchInput
                onChangeText={(term) => {
                    this.searchUpdated(term)
                }}
                style={styles.textInput_search}
                placeholder="Type a message to search"
                placeholderTextColor='#626264'
                />
           </View> 

           <View style={{paddingBottom: 40, maxHeight: height - 100}}>
            <ScrollView>
              {filteredCourses.map(course => {
                    if(course.type == "existing-plan") {
                        return (
                            <TouchableOpacity onPress={() => this.selectcourse(course)} style={styles.emailItem}>
                                <View style={styles.searchresults}>
                                  <Text style={styles.selected}>{course.title}</Text>
                                  <Text><Icon name="chevron-right" size={20} color="#FF7E00"   /></Text>
                                </View>
                            </TouchableOpacity>
                        )
                    }
                })}
            </ScrollView>

           </View>

           </View>

            }



               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
