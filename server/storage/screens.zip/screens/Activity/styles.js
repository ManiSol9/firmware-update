import { StyleSheet, } from 'react-native';
const Dimensions = require('Dimensions');
const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

function wp(percentage) {
    const value = (percentage * viewportWidth) / 100;
    return Math.round(value);
}

const slideHeight = viewportHeight * 0.4;
const slideWidth = wp(90);
const itemHorizontalMargin = wp(2);
const sliderWidth = viewportWidth;
const itemWidth = slideWidth + itemHorizontalMargin * 2;

const styles = StyleSheet.create({

    btm_tabNavigation: {
        position: 'absolute',
        bottom: 0,
        backgroundColor: 'red',
        flex: 1,
        flexDirection: 'row',
        paddingTop: 12,
        paddingBottom: 2
    },
    save_btnTxt: {
        fontSize: 20,
        paddingTop: 20,
        position: 'absolute',
        fontWeight: 'bold',
        textAlign: 'center',
        color: '#fff',
        justifyContent: 'center',
        alignItems: 'center'
    },
    saveBtn2: {
        marginTop: 90,
        alignItems: 'center',
        position: 'absolute'
    },
    upcomingWorkouts_main_body: {
        backgroundColor: '#2d2e37',
        marginTop: 0,
        padding: 0,
        height: Dimensions.get('window').height,
        width: Dimensions.get('window').width
    },
    upcomingWorkouts_bg_img_view: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: undefined,
        height: undefined,
    },
    upcomingWorkouts_bg_img: {
        height: Dimensions.get('window').height,
        width: Dimensions.get('window').width,
    },
    upcomingWorkouts_heading: {
        color: '#ffffff',
        marginTop: 15,
        fontSize: 20,
        fontWeight: 'bold',
        paddingTop: 15,
        backgroundColor: 'rgba(0,0,0,0)',
        textAlign: 'center'
    },
    upcomingWorkouts_scrollView: {
        marginTop: 15,marginBottom: 170
    },
    upcomingWorkouts_content_view: {
        alignItems: 'center'
    },
    upcomingWorkouts_content: {
        width: '75%'
    },
    tuesday_heading: {
        fontSize: 15,
        color: '#ffffff',
        marginTop: 0,
        backgroundColor: 'rgba(0,0,0,0)',
        fontWeight: 'bold',
        paddingTop: 5,
        paddingBottom: 5,
        width: '100%'
    },
    whiteline: {
        borderBottomWidth: 3,
        borderBottomColor: '#FFF',
        marginBottom: 7,
        marginTop: 7
    },
    wat_log_track_icons: {
        flex: 1,
        flexDirection: 'row',
        paddingLeft: 20,
        paddingRight: 20,
        paddingTop: 20,
        position: 'absolute',
        bottom: 100
    },
    cross_icon: {
        position: 'absolute',
        bottom: 28,
        zIndex: 3,
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        width: Dimensions.get('window').width
    },
    cross_icon1: {
        position: 'absolute',
        bottom: 0,
        zIndex: 3,
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        width: Dimensions.get('window').width,
        //backgroundColor: 'hsl(129, 92%, 55%)',
        height: 60,
        borderColor: 'white',
        borderTopWidth: .5
    },
    trans_bg: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        bottom: 0,
        height: 90,
        zIndex: 2,
        width: Dimensions.get('window').width
    },
    btm_tabNavigation: {
        position: 'absolute',
        bottom: 0,
        backgroundColor: '#414249',
        flex: 1,
        flexDirection: 'row',
        paddingTop: 10,
        paddingBottom: 4
    },

    //Trackactivity styles
    trackactivity_container: {
        backgroundColor: '#2d2e37',
        marginTop: 0,
        padding: 0,
        height: Dimensions.get('window').height,
        width: Dimensions.get('window').width
    },
    trackactivity_image_container: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: undefined,
        height: undefined
    },
    trackactivity_bg_image: {
        resizeMode: 'stretch',
        height: Dimensions.get('window').height,
        width: Dimensions.get('window').width,
    },
    trackactivity_heading: {
        color: '#ffffff',
        textAlign: 'left',
        marginTop: 5,
        textAlign: 'center',
        paddingBottom: 20,
        fontSize: 20,
        fontWeight: 'bold',
        paddingTop: 15
    },
    trackactivity_heartimg_heartrate_viewc: {
        position: 'relative'
    },
    trackactivity_heart_img: {
        marginLeft: '6%',
        marginTop: 40,
        backgroundColor: 'rgba(0,0,0,0)',
        color: '#fff'
    },
    connectingscreen: {
        marginTop: '60%',
        backgroundColor: 'rgba(0,0,0,0)',
        borderColor: 'white',
        height: 150,
        width: '100%',
        borderRadius: 5,
        borderWidth: 2,
        justifyContent: 'center',
        padding: 20
    },
    trackactivity_subSection_view_part1_headingtext1: {
        fontWeight: 'bold',
        color: '#fff',
        fontSize: 18,
        fontFamily: 'arial',
        position: 'relative',
        top: -3,
        textAlign: 'center',
        marginBottom: 20
    },
    trackactivity_heartrate: {
        color: '#ffffff',
        textAlign: 'left',
        marginTop: 5,
        textAlign: 'center',
        paddingBottom: 20,
        fontSize: 134,
        fontWeight: 'bold',
        paddingTop: 15,
        position: 'absolute',
        top: -6,
        right: 20,
        backgroundColor: 'rgba(0,0,0,0)'
    },
    trackactivity_heartrate1: {
        color: '#ffffff',
        textAlign: 'left',
        marginTop: 5,
        textAlign: 'center',
        paddingBottom: 20,
        fontSize: 124,
        fontWeight: 'bold',
        paddingTop: 15,
        position: 'absolute',
        top: -6,
        right: 20,
        backgroundColor: 'rgba(0,0,0,0)'
    },
    trackactivity_subSection_view1: {
        marginTop: 50,
        flexDirection: 'row',
        width: '100%',
        height: 100,
    },
    trackactivity_subSection_view2: {
        marginTop: 0,
        flexDirection: 'row',
        width: '100%',
    },
    trackactivity_subSection_view_part1: {
        alignItems: 'center',
        width: '48%',
        backgroundColor: 'rgba(0,0,0,0)'
    },
    trackactivity_subSection_view_part1_headingtext: {
        fontWeight: 'bold',
        color: '#fff',
        fontSize: 14,
        fontFamily: 'arial',
        position: 'relative',
        top: -3
    },
    trackactivity_subSection_view_part1_calories: {
        fontWeight: 'bold',
        color: '#fff',
        fontSize: 36,
        fontFamily: 'arial',

    },
    stopactivity: {

        width: '100%',
        alignItems: 'center',
        marginTop: '55%',
        justifyContent: 'center',

    },
    trackactivity_subSection_view_part1_stop: {
        fontWeight: 'bold',
        color: '#fff',
        fontSize: 36,
        fontFamily: 'arial',
        backgroundColor: 'rgba(0,0,0,0)',
        textAlign: 'center'
    },

    trackactivity_start_stop_btn_view: {
        width: '100%',
        alignItems: 'center',
        marginTop: 50,
    },
    trackactivity_start_stop_btn_touchable_opacity: {
        width: '80%',
        borderColor: '#fff',
        borderWidth: 4,
        padding: 10,
        alignItems: 'center',
        borderRadius: 4
    },
    trackactivity_start_stop_btn_text: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
        backgroundColor: 'rgba(0,0,0,0)'
    },
    trackactivity_footer_img_view: {
        position: 'absolute',
        bottom: 28,
        zIndex: 3,
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        width: Dimensions.get('window').width
    },
    trackactivity_footer_main_view: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        bottom: 0,
        resizeMode: 'stretch',
        height: 87,
        zIndex: 2,
        width: Dimensions.get('window').width,
        backgroundColor: 'rgba(237, 75, 60, 0.8)'
    },
    trackactivity_footer_main_view2: {
        position: 'absolute',
        bottom: 0,
        backgroundColor: '#414249',
        flex: 1,
        flexDirection: 'row',
        paddingTop: 12,
        paddingBottom: 2
    },
    header: {
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        marginTop: -10,
        backgroundColor: 'rgba(0,0,0,0)'
    },
    chevron_left_icon: {
        position: 'absolute',
        paddingLeft: 16,
        paddingTop: 1,
        zIndex: 999,
        marginTop: 25,
        backgroundColor: 'rgba(0,0,0,0)'
    },

    topSignupTxt: {
        color: '#FFF',
        textAlign: 'center',
        fontSize: 20,
        fontWeight: 'bold',
        paddingTop: 15
    },
    button: {
        marginTop: 20
    }


});


export default styles;
