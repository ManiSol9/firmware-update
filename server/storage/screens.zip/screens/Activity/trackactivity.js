import React, { Component } from 'react';
import { AppRegistry, StyleSheet, Text, View, TouchableHighlight, NativeAppEventEmitter, NativeEventEmitter, NativeModules, Platform, PermissionsAndroid, ListView, ScrollView, AppState, TouchableOpacity, Image, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import { AsyncStorage } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import Dimensions from 'Dimensions';
import BleManager from 'react-native-ble-manager';
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';
import moment from "moment";
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { addToTable, addSensorData } from '../../template/api.js';
const window = Dimensions.get('window');
const ds = new ListView.DataSource({
    rowHasChanged: (r1, r2) => r1 !== r2
});

import RNSensors from 'react-native-sensors';
const { Accelerometer, Gyroscope } = RNSensors;
const accelerationObservable = new Accelerometer({
updateInterval: 100, // defaults to 100ms
});
const gyroscopeObservable = new Gyroscope({
updateInterval: 2000, // defaults to 100ms
});

import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import Video from 'react-native-video';

import { request } from 'graphql-request'

import Toast, { DURATION } from 'react-native-easy-toast'
import KeepAwake from 'react-native-keep-awake';
import StatusBarBackground from './statusbar.js'

import styles from './styles.js'


const BleManagerModule = NativeModules.BleManager;
const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);

export default class TrackExcierce extends Component {
    constructor() {
        super()

        this.state = {
            scanning: false,
            peripherals: new Map(),
            peripheralId: 0,
            appState: '',
            heartrate: 0,
            screenchange: '0',
            time: moment().format("LTS"),
            date: moment().format("LL"),
            totsec: 2400,
            item: 0,
            array: [],
            avg_heart_rate: [],
            sum: 0,
            average: 0,
            calories: 0,
            user_id: null,
            profile: [],
            height: '',
            weight: 0,
            timepassed: false,
            rate: 1,
            volume: 1,
            duration: 0.0,
            currentTime: 0.0,
            paused: true,
            loader: false,
            times: 0,
            age: '',
            time: {},
            seconds: 0,
            device_id: '',
            increment: 0,
            startbutton: 0,
            bleInfo: {},
            connected: false,
            contentLoader: true,
            connected: false,
            bleDeviceConnected: false,
            exerciseStarted: false,
            images: ['back1', 'back2', 'back3', 'back4', 'bg_a'],
            pauseReading: true,
            completeReading: false,
            startReading: true,
            gender: "Male",
            acceleration: {
                x: 'unknown',
                y: 'unknown',
                z: 'unknown',
            },
            gyroscope: {
                x: 'unknown',
                y: 'unknown',
                z: 'unknown',
            },
            length:0,
            length1:0,
            stepCountFlag:false,
            stepCount:0,
            gravity : {
                x: 0,
                y: 0,
                z: 0,
            },
            FilteredAccleration : {
                x: 0,
                y: 0,
                z: 0,
            },
            emaFilter : {
                x : 0,
                y : 0,
                z : 0,
            },
            sumAverage : 0,
            alpha : 0.8,
            alpha1 : 0.8,
            threshold : 0.7,
            loopCount : 0,
            minmaxFlag : false,
            frequencyCount : 0,
            miles:0            
        }

        this.handleDiscoverPeripheral = this.handleDiscoverPeripheral.bind(this);
        this.handleStopScan = this.handleStopScan.bind(this);
        this.handleUpdateValueForCharacteristic = this.handleUpdateValueForCharacteristic.bind(this);
        this.handleDisconnectedPeripheral = this.handleDisconnectedPeripheral.bind(this);
        this.handleAppStateChange = this.handleAppStateChange.bind(this);
        this.timer = 0;
        this.startTimer = this.startTimer.bind(this);
        this.countDown = this.countDown.bind(this);

    }


    async componentWillMount() {

        console.log('componentWillMount')

        let user_id = await AsyncStorage.getItem("USER_ID");
        let device_id = await AsyncStorage.getItem("DEVICE_ID");



        let device_name = await AsyncStorage.getItem("DEVICE_NAME");
        const {navigate} = this.props.navigation;
        console.log(device_id, device_name)
        if (!device_id || !device_name) {
            navigate('SearchDevices')
        }

        this._getStudentDetails(user_id);

        this.bleConnect(this.state.device_id)

        this.setTimeout(() => {

            console.log('asdasdasd')

            this.checkstate(this.state.connected)

        }, 10000);

        KeepAwake.activate();

    /**** Step counter ***/

        accelerationObservable
        .subscribe(acceleration => this.setState({
        acceleration,
        },function(){
            this.state.gravity.x = this.state.alpha*this.state.gravity.x + (1-this.state.alpha)*this.state.acceleration.x
            this.state.gravity.y = this.state.alpha*this.state.gravity.y + (1-this.state.alpha)*this.state.acceleration.y
            this.state.gravity.z = this.state.alpha*this.state.gravity.z + (1-this.state.alpha)*this.state.acceleration.z
            let tempObj = {}
            tempObj.x = this.state.acceleration.x-this.state.gravity.x;
            tempObj.y = this.state.acceleration.y-this.state.gravity.y;
            tempObj.z = this.state.acceleration.z-this.state.gravity.z;
            this.setState({FilteredAccleration:tempObj},function(){
            let tempObj1 = {}
            tempObj1.x = (1-this.state.alpha1)*this.state.emaFilter.x + this.state.alpha1*this.state.FilteredAccleration.x;
            tempObj1.y = (1-this.state.alpha1)*this.state.emaFilter.y + this.state.alpha1*this.state.FilteredAccleration.y;
            tempObj1.z = (1-this.state.alpha1)*this.state.emaFilter.z + this.state.alpha1*this.state.FilteredAccleration.z;
            this.setState({emaFilter:tempObj1})
        })
        let x = this.state.FilteredAccleration.x;
        let y = this.state.FilteredAccleration.y;
        let z = this.state.FilteredAccleration.z;
        let length = Math.sqrt(x*x + y*y + z*z)
        let length1 = Math.sqrt(this.state.emaFilter.x*this.state.emaFilter.x+this.state.emaFilter.y*this.state.emaFilter.y+this.state.emaFilter.z*this.state.emaFilter.z)
        this.setState({length1:length1},function(){
        if(this.state.frequencyCount<1000){
            this.setState({frequencyCount:this.state.frequencyCount+1})
        }
        if(this.state.loopCount<50){
            this.setState({sumAverage:this.state.sumAverage+this.state.length1,loopCount:this.state.loopCount+1});
            //console.log('if loopCount <50','sumAverage ',this.state.sumAverage,', length1 ',this.state.length1)
        }
        else{
            this.setState({threshold:this.state.sumAverage/50,loopCount:0,sumAverage:0})
            //console.log('else threshold',this.state.threshold)
        }
        if(this.state.stepCountFlag===false){
            //console.log('try',this.state.length1,this.state.threshold)
            if(this.state.length1>this.state.threshold){
                this.setState({stepCountFlag:true},function(){
                //console.log('if',this.state.stepCountFlag,this.state.length,this.state.threshold)
                })
            }
        }
        else if(this.state.stepCountFlag===true){
            //console.log('frequencyCount',this.state.frequencyCount)
            if(this.state.length1<this.state.threshold){
                if(this.state.frequencyCount<1000){
                   // console.log('threshold in 1000 range',this.state.threshold)
                    if(this.state.threshold>0.2){

                        this.setState({stepCountFlag:false,stepCount:this.state.stepCount+1,miles: (this.state.stepCount*0.00047)},function(){
                        //console.log('elseif',this.state.stepCountFlag,this.state.length,this.state.threshold)
                        })
                    }
                }
                else{
                    this.setState({frequencyCount:1001})
                   // console.log('threshold in 1001 range',this.state.threshold)

                    if(this.state.threshold>0.1){
                    // if(this.state.frequencyCount>50 && this.state.frequencyCount<200){
                        this.setState({stepCountFlag:false,stepCount:this.state.stepCount+1,frequencyCount:0, miles: (this.state.stepCount*0.00047)},function(){
                    //console.log('elseif',this.state.stepCountFlag,this.state.length,this.state.threshold)
                    


                    })
                    // }
                    // else{
                    // //console.log('else'+this.state.frequencyCount)
                    // }
                    }
                }
            }
        }
        })
        this.setState({length:length},function(){
        })
        }));
        gyroscopeObservable
        .subscribe(gyroscope => this.setState({
        gyroscope,
        }));

    /**** ***/

    }


    checkstate(connected) {
        const {navigate} = this.props.navigation;
        if (this.state.connected === false) {
            Alert.alert('Make Sure Your Device is Near By', 'Please Re Connect',
                [
                    {
                        text: 'Ok',
                        onPress: () => navigate('UpcomingWorkouts')
                    },
                ],
                {
                    cancelable: false
                }
            )
        } else {
            this.state.contentLoader = false

            this.startTimer()

            let timeLeftVar = this.secondsToTime(this.state.seconds1);

            this.setState({
                time: timeLeftVar
            });

        }

    }

    async componentDidMount() {
        console.log('componentDidMount')
        this.setState({
            device_id: await AsyncStorage.getItem("DEVICE_ID")
        }, () => {

        })


        //this.refs.toast.show('Connecting to saved device....' , DURATION.LENGTH_LONG);
        AppState.addEventListener('change', this.handleAppStateChange);



        this.handlerDiscover = bleManagerEmitter.addListener('BleManagerDiscoverPeripheral', this.handleDiscoverPeripheral);
        this.handlerStop = bleManagerEmitter.addListener('BleManagerStopScan', this.handleStopScan);
        this.handlerDisconnect = bleManagerEmitter.addListener('BleManagerDisconnectPeripheral', this.handleDisconnectedPeripheral);
        this.handlerUpdate = bleManagerEmitter.addListener('BleManagerDidUpdateValueForCharacteristic', this.handleUpdateValueForCharacteristic);

    }


    _getStudentDetails=(id) => {


        const query = `query profile_details($user_id:Int!){

                profile_details(user_id: $user_id) {
                    dob,
                    height_in_feet,
                    height_in_meters,
                    height_in_inches,
                    current_weight_in_lbs,
                    current_weight_in_kgs,
                    parameter_type,
                    gender,
                    profile_image_url
                }

                }`;

        const variables = {
            user_id: Number(id),
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/profile_details', query, variables)
            .then(async data => {
                response = data.profile_details[0]
                console.log(data.profile_details[0])

                this.setState({                        
                        current_weight_in_kgs: response.current_weight_in_kgs,
                        current_weight_in_lbs: response.current_weight_in_lbs,
                        gender: response.gender
                })

                if(response.parameter_type == 1){

                var weight = response.current_weight_in_lbs * 2.20412

                } else {

                var weight = response.current_weight_in_kgs

                }

                this.setState({weight: weight})

                dob = response.dob

                dob = dob.split("/")

                birthDate = new Date(dob[2], dob[1], dob[0])             

                var today = new Date();
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) 
                {
                    age--;
                }

                this.setState({
                    age: age
                })


            }
        )
            .catch(async err => {
                console.log(err)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })
            }
        )


    }


    addBLERoute=async () => {
        const {navigate} = this.props.navigation;
        Alert.alert(
            'Maku sure your device is near By', 'Start actvity again',
            [
                {
                    text: 'Ok',
                    onPress: () => navigate('UpcomingWorkouts')
                },
            ],
            {
                cancelable: false
            }
        )
    }


    bleConnect(device_id) {
        let x = 0

        console.log(device_id)

        BleManager.connect(device_id).then(() => {
            console.log('inside connect')

            this.setState({
                connected: true
            })

            this.setTimeout(() => {

                BleManager.retrieveServices(device_id).then((peripheralInfo) => {

                    var service = '180D';
                    var bakeCharacteristic = '2A37';
                    var crustCharacteristic = '13333333-3333-3333-3333-333333330001';

                    this.setTimeout(() => {
                        BleManager.startNotification(device_id, service, bakeCharacteristic).then(() => {


                            console.log('Started notification on ' + device_id);
                            this.state.startbutton = 1;


                        }).catch((error) => {

                            this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                            this.state.loader = false

                            this.state.startbutton = 0

                            console.log('Connection error', error);


                        });
                    }, 200);
                }).catch((error) => {

                    this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                    this.state.loader = false

                    this.state.startbutton = 0

                    console.log('Connection error', error);


                });

            }, 900);

        }).catch((error) => {

            this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

            this.state.loader = false

            this.state.startbutton = 0

            console.log('Connection error', error);

        });

    }


    handleAppStateChange(nextAppState) {
        if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
            console.log('App has come to the foreground!')
            BleManager.getConnectedPeripherals([]).then((peripheralsArray) => {
                console.log('Connected peripherals: ' + peripheralsArray.length);
            });
        }
        this.setState({
            appState: nextAppState
        });
    }



    handleDisconnectedPeripheral(data) {
        let peripherals = this.state.peripherals;
        let peripheral = peripherals.get(data.peripheral);
        if (peripheral) {
            peripheral.connected = false;
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            });

        }
        console.log('Disconnected from ' + data.peripheral);

    }


    handleUpdateValueForCharacteristic(data) {
        console.log('Received data from ' + data.peripheral + ' characteristic ' + data.characteristic, data.value);
        this.setState({
            heartrate: data.value[1]
        });

        if (!this.state.pauseReading) {
            this.savedata(data.value[1])
        }
    }

    savedata(data) {

        this.state.array[this.state.item] = data;

        if (this.state.item == 5) {
            this.setState(prevState => ({
                times: prevState.times + 20
            }))
            for (var i = 0; i < this.state.array.length; i++) {
                this.state.sum += parseInt(this.state.array[i]);
            }

            if (this.state.array.length > 0) {

                this.state.average = Math.round(this.state.sum / this.state.array.length);

                this.state.avg_heart_rate[this.state.increment] = this.state.average;

                if (this.state.age == null) {
                    this.state.age = 25
                }

                console.log(this.state.gender)

                console.log(this.state,"zdfdfsd")

                console.log('--------------')

                var calories = 0

                if(this.state.gender == 'Male'){

                 calories = Math.round(((this.state.age * 0.2017) + (this.state.weight * 0.1988) + (this.state.average * 0.6309) - 55.0969) * 0.03 / 4.184)

                } else {

                  calories = Math.round(((this.state.age * 0.074) + (this.state.weight * 0.1263) + (this.state.average * 0.4472) - 20.4022) * 0.03 / 4.184)

                }


                //let calories = Math.round((-55.0969 + (0.6309 * this.state.average) + (0.1988 * (this.state.weight/2.2046) + (0.2017 * this.state.age))/4.184) * 60 * 0.005)

                if (calories < 0 || calories == 'null') {
                    calories = 0
                }

                this.state.calories = calories + this.state.calories;

                this.state.increment++

                console.log(this.state.age)

                console.log(this.state.calories)

            }

            this.state.item = 0;

            this.state.array = [];

            this.state.sum = 0;

        } else {

            this.state.item = this.state.item + 1;

        }

    }


    handleStopScan() {
        console.log('Scan is stopped');
        this.setState({
            scanning: false
        });
    }

    startScan() {
        if (!this.state.scanning) {
            BleManager.scan([], 30, true).then((results) => {
                console.log('Scanning...');
                this.refs.toast.show('Scanning....', DURATION.LENGTH_LONG);
                this.setState({
                    scanning: true
                });
            }).catch((error) => {
                console.log('Connection error', error);
                this.refs.toast.show('Connection error.... Please Try To Reconnect', DURATION.LENGTH_LONG);
            });
        }
    }

    handleDiscoverPeripheral(peripheral) {
        var peripherals = this.state.peripherals;
        if (!peripherals.has(peripheral.id)) {
            console.log('Got ble peripheral', peripheral);
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            })
        }
    }


    /*** Timer Functionality ***/

    startTimer() {
        console.log('Starting')
        if (this.timer == 0) {
            this.timer = setInterval(this.countDown, 1000);
        }
    }

    countDown() {
        // Remove one second, set state so a re-render happens.

        if (!this.state.pauseReading) {
            var seconds = this.state.seconds + 1;
        } else {
            var seconds = this.state.seconds
        }
        this.setState({
            time: this.secondsToTime(seconds),
            seconds: seconds,
        });

        // Check if we're at zero.
        if (seconds == 0) {
            //clearInterval(this.timer);
        }
    }

    secondsToTime(secs) {

        let hours = Math.floor(secs / (60 * 60));

        let divisor_for_minutes = secs % (60 * 60);
        let minutes = Math.floor(divisor_for_minutes / 60);

        let divisor_for_seconds = divisor_for_minutes % 60;
        let seconds = Math.ceil(divisor_for_seconds);

        if (minutes < 10) {
            minutes = '0' + minutes
        }

        if (hours < 10) {
            hours = '0' + hours
        }

        if (seconds < 10) {
            seconds = '0' + seconds
        }

        let obj = {
            "h": hours,
            "m": minutes,
            "s": seconds
        };
        return obj;
    }

    _sendStatus(deviceid, avg_heart_rate, cal, hou, min, sec) {

        BleManager.disconnect(deviceid)
            .then(() => {
                // console.log('Disconnected');
            })
            .catch((error) => {
                //console.log(error);
            });

        let sum = 0

        //console.log(avg_heart_rate)
        for (var i = 0; i < avg_heart_rate.length; i++) {
            sum += parseInt(avg_heart_rate[i])
        }

        var time = hou + ':' + min + ':' + sec

        sum = Math.round(sum / avg_heart_rate.length);

        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();

        if (dd < 10) {
            dd = '0' + dd
        }

        if (mm < 10) {
            mm = '0' + mm
        }

        date = yyyy + '-' + mm + '-' + dd;

        const {navigate} = this.props.navigation;
        navigate("Logactivity", {
            calories: cal,
            time: time,
            date: date,
            heart_rate: sum,
            avg_heart_rate: avg_heart_rate,
            fromScreen: 'Trackactivity'
        });

        //navigate("Tabs")


    }

    completedReading = () => {


        if (!this.state.completeReading) {
            this.setState({
                completeReading: true,
                pauseReading: true
            })
        } else {
            this.setState({
                completeReading: false
            })
        }



    }


    componentWillUnmount() {

        BleManager.disconnect(this.state.device_id)
            .then(() => {
                //console.log('Disconnected');
            })
            .catch((error) => {
                //console.log(error);
            });
        this.setState({});
        this.handlerDiscover.remove();
        this.handlerStop.remove();
        this.handlerDisconnect.remove();
        this.handlerUpdate.remove();

        accelerationObservable.stop();
        gyroscopeObservable.stop();

    }

    onPressLearnMore = (e)=> {

        e.preventDefault()
        this.setState({stepCount:0,frequencyCount:0})

    }    

    render() {


        const list = Array.from(this.state.peripherals.values());

        for (i = 0; i < list.length; i++) {
            if (list[i].id == this.state.device_id) {
                var device_data = list[i]
            }
        }

        var {bleDeviceConnected, exerciseStarted, heartrate, images, contentLoader, completeReading, age,
            acceleration,
            gyroscope,
            length,
            length1,
            stepCount,
            FilteredAccleration,
            gravity,
            emaFilter,
            threshold,
            miles
            } = this.state;

        let imageURI = 'gradientbg'

        var maxheartrate = 220 - age

        heart_percenatge = Math.round((heartrate / maxheartrate)*100)
        
        if(heart_percenatge > 90) {

            imageURI = images[1]

        } else if(heart_percenatge < 90 && heart_percenatge > 80){

            imageURI = images[2]

        } else if(heart_percenatge < 80 && heart_percenatge > 70){

            imageURI = images[3]

        } else if(heart_percenatge < 70 && heart_percenatge > 50){

            imageURI = images[0]

        } else {

            imageURI = images[4]

        }


        return (
            <View>
          {contentLoader ?
                <View style={styles.trackactivity_container}>
              <View style={styles.trackactivity_image_container}>
                <Image style={styles.trackactivity_bg_image} source={{
                    uri: 'back1'
                }}/>
              </View>
              <View style={styles.connectingscreen}>

                <Text style={styles.trackactivity_subSection_view_part1_headingtext1}> Connecting to Heartrate Monitor</Text> 

                  <ActivityIndicator
                animating = "true"
                color = 'blue'
                size = "large"
                style = {styles.activityIndicator}
                />
              </View>
            </View>
                :
                <View>
                  {completeReading ?
                    <View style={styles.trackactivity_container}>
              <View style={styles.trackactivity_image_container}>
                <Image style={styles.trackactivity_bg_image} source={{
                        uri: 'back3'
                    }}/>
              </View>
                    <View style={styles.stopactivity}>

                    <Text style={styles.trackactivity_subSection_view_part1_stop}>STOP TRACKING ACTIVITY</Text>

                    <View style={styles.trackactivity_start_stop_btn_view}>
                      <TouchableOpacity
                    activeOpacity={1}
                    style={styles.trackactivity_start_stop_btn_touchable_opacity}
                    onPress={() => this._sendStatus(this.state.device_id, this.state.avg_heart_rate, this.state.calories, this.state.time.h, this.state.time.m, this.state.time.s)}>
                        <Text style={styles.trackactivity_start_stop_btn_text}>COMPLETE</Text>
                      </TouchableOpacity>
                    </View>

                    </View>

                    </View>

                    :
                    <View style={styles.trackactivity_container}>
                    <View style={styles.trackactivity_image_container}>
                      <Image style={styles.trackactivity_bg_image} source={{
                        uri: imageURI
                    }}/>
                    </View>
                    <StatusBarBackground style={{
                        backgroundColor: '#ff7200'
                    }}/>
                      <View style={styles.chevron_left_icon}>
                        <TouchableOpacity onPress={() => {
                        const {navigate} = this.props.navigation;
                        navigate('UpcomingWorkouts')
                    }}>
                          <Icon name="chevron-left" size={25} color="#FF7E00"   />
                        </TouchableOpacity>
                      </View>
                      <View style={styles.header}>
                        <Text style={styles.topSignupTxt}>
                          TRACK ACTIVITY!
                        </Text>
                      </View>
                    <View>
           <View style={styles.trackactivity_heartimg_heartrate_view}>
              {heartrate.toString().length < 3 ?
                        <View><Icon name="heart-o" size={120} style={styles.trackactivity_heart_img}   /><Text style={styles.trackactivity_heartrate}>{this.state.heartrate}</Text></View>
                        :
                        <View><Icon name="heart-o" size={100} style={styles.trackactivity_heart_img}   /><Text style={styles.trackactivity_heartrate1}>{this.state.heartrate}</Text></View>
                    }             
           </View>

           <View style={styles.trackactivity_subSection_view1}>
             <View style={styles.trackactivity_subSection_view_part1}>
               <Text style={styles.trackactivity_subSection_view_part1_calories}>{this.state.calories}</Text>
               <Text style={styles.trackactivity_subSection_view_part1_headingtext}>CALORIES</Text>
             </View>

             <View style={styles.trackactivity_subSection_view_part1}>
               <Text style={styles.trackactivity_subSection_view_part1_calories}>{this.state.average}</Text>
               <Text style={styles.trackactivity_subSection_view_part1_headingtext}>AVG BPM</Text>
             </View>

           </View>
           <View style={styles.trackactivity_subSection_view2}>
             <View style={styles.trackactivity_subSection_view_part1}>
              {this.state.startReading ?
                        <Text style={styles.trackactivity_subSection_view_part1_calories}>  0 </Text>
                        :
                        <Text style={styles.trackactivity_subSection_view_part1_calories}> {this.state.miles} </Text>
                    }               

               <Text style={styles.trackactivity_subSection_view_part1_headingtext}>MILES</Text>
             </View>

             <View style={styles.trackactivity_subSection_view_part1}>
              {this.state.startReading ?
                        <Text style={styles.trackactivity_subSection_view_part1_calories}>  00:00:00 </Text>
                        :
                        <Text style={styles.trackactivity_subSection_view_part1_calories}>  {this.state.time.h}:{this.state.time.m}:{this.state.time.s} </Text>
                    }
               <Text style={styles.trackactivity_subSection_view_part1_headingtext}>TIME</Text>
             </View>
           </View>

           {this.state.pauseReading ?

                        <View style={styles.trackactivity_start_stop_btn_view}>
             <TouchableOpacity
                        activeOpacity={1}
                        style={styles.trackactivity_start_stop_btn_touchable_opacity}
                        onPress={() => this.setState({
                            pauseReading: false,
                            startReading: false
                        })}>
               <Text style={styles.trackactivity_start_stop_btn_text}>{this.state.startReading ? 'START' : 'RESUME'}</Text>
                 </TouchableOpacity>
           </View>

                        :

                        <View style={styles.trackactivity_start_stop_btn_view}>
             <TouchableOpacity
                        activeOpacity={1}
                        style={styles.trackactivity_start_stop_btn_touchable_opacity}
                        onPress={() => this.setState({
                            pauseReading: true
                        })}>
               <Text style={styles.trackactivity_start_stop_btn_text}>PAUSE</Text>
                 </TouchableOpacity>
           </View>

                    }
          </View>
                      </View>


                } 

        <View style={styles.cross_icon1}>
          <TouchableOpacity
                activeOpacity={1} onPress={() => this.completedReading()
                }>
            <Image style={{
                    width: 45,
                    height: 45
                }} source={{
                    uri: 'cross'
                }} />
          </TouchableOpacity>
        </View>


        <View style={styles.trans_bg}>
          <Image style={{
                    width: '100%',
                    height: 84
                }} source={{
                    uri: 'trans_bg'
                }} />
        </View>
  

                </View>
            }
          </View>
        );
    }
}
reactMixin(TrackExcierce.prototype, TimerMixin);


