import React, { Component } from 'react';
import { getUpcomingWorkouts } from '../../template/Workout/workout.js'
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, ActivityIndicator, ToastAndroid, Alert, NativeModules, NativeEventEmitter } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import Toast, { DURATION } from 'react-native-easy-toast'

import KeepAwake from 'react-native-keep-awake';


import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'

import { TabNavigator } from 'react-navigation';

import styles from './styles.js'

import { request } from 'graphql-request'

import moment from "moment";


export default class UpcomingWorkouts extends Component<{}> {
    constructor(props) {
        super(props);
        this.state = {
            workouts: [],
            loader: null,
            upcoming_workouts: []
        };
    }
    async componentWillMount() {
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        this._getAllWorkouts(USER_ID)
        KeepAwake.activate();
        console.log(USER_ID, 'hgjjgj')
    }
    _getAllWorkouts=(user_id) => {
        this.setState({
            loader: true
        })

        /*
        getUpcomingWorkouts(user_id).then(response => {
            console.log(response);
            if (response.status) {
                this.setState({
                    workouts: response.data.data,
                    loader: false
                }, () => console.log(this.state.workouts));
            } else {
                this.setState({
                    workouts: response.data,
                    loader: false
                });
            }
        }, err => {
            console.log(err)
        })

        */

        const query = `query fetch_workout_by_day($student_id: Int!){
                          fetch_workout_by_day(student_id: $student_id){
                            course_id
                            start_date
                            status
                            course_to_plan{
                              plan_id
                              index
                              week
                              day_index
                              date
                              plan_slot{
                                workout_id
                                workout{
                                  date_created
                                  title
                                  duration
                                  id
                                  backThumbnail_url
                                }
                              }
                            }
                          }
                        }
                        `;


        const variables = {
            student_id: user_id
        }

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout', query, variables)
            .then(async data => {

                console.log(data)

                this.setState({
                    workouts: data.fetch_workout_by_day,
                    loader: false
                }, () => {console.log(this.state.workouts)
                    var workouts=[];

                    for(i=0;i<this.state.workouts.length;i++){

                        if(this.state.workouts[i].status == 'approved')
                        {

                                this.state.workouts[i].course_to_plan.map((slot, index)=>{
                                    if(slot.index){
                                        if(slot.plan_slot.length > 0) {
                                            slot.plan_slot[0].workout_id.map((id, index)=>{
                                                var temp = slot.plan_slot[0].workout.filter(workout=>workout.id==id);
                                                console.log(temp)
                                                var date = slot.date

                                                var object = [temp[0], date]

                                                workouts.push(object);
                                            })
                                        }
                                    }else{
                                        console.log('rest day')
                                    }
                                })
                        }

                    }

                    this.setState({upcoming_workouts: workouts})
                });

                console.log(this.state.upcoming_workouts)
                
            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    loader: false
                })
            }
        )


    }

    logactivity() {
        const {navigate} = this.props.navigation;
        navigate("Logactivity", {
            calories: '',
            time: '00:00',
            date: '',
            heart_rate: 0,
            avg_heart_rate: []
        });

    }

    async trackactivity(routeData) {
        console.log("Manikant")
        if (await AsyncStorage.getItem("DEVICE_NAME") && await AsyncStorage.getItem("DEVICE_ID")) {
            const {navigate} = this.props.navigation;
            navigate("Trackactivity");
        } else {
            this.addBLERoute(routeData);
        }
    }

    addBLERoute=async (routeData) => {
        const {navigate} = this.props.navigation;
        Alert.alert('Add Bluetooth device', 'To continue the workout',
            [
                {
                    text: 'Add later',
                    onPress: () => console.log('cancelled the workout process')
                },
                {
                    text: 'Add',
                    onPress: () => navigate('SearchDevices', {
                        fromRoute: routeData.routeFrom,
                        toRoute: routeData.routeTo,
                        enableBack: true,
                        data: routeData.workout
                    })
                },
            ],
            {
                cancelable: false
            }
        )
    }

    routing=async(routeData) => {
        console.log(routeData)
        const {workouts, loader} = this.state;
        const {navigate} = this.props.navigation;

        this.addBLERoute(routeData);

        
        if (await AsyncStorage.getItem("DEVICE_NAME") && await AsyncStorage.getItem("DEVICE_ID")) {
            routeData.key ? this.refs.toast.show('Start first workout', DURATION.LENGTH_LONG) : workouts.length ? navigate(routeData.routeTo, {
                params: routeData.workout
            }) : navigate('Courses')
        } else {
            this.addBLERoute(routeData);
        }
        

    }


    sendWorkout = (workout) => {
        const {navigate} = this.props.navigation;
        console.log(workout)

        workouts = this.state.workouts

        console.log(workouts)

        navigate("WorkoutDetails", {id: workout, course_id: workouts[0].course_id})
    }

    futureworkout = () => {
        alert("It's a future workout")
    }

    render() {
        const {navigation} = this.props;
        const {workouts, loader, upcoming_workouts} = this.state;
        todayDate = moment().format("YYYY-M-D");
        console.log(todayDate,"today Date")
        return (
            <View style={styles.upcomingWorkouts_main_body}>
        <View style={styles.upcomingWorkouts_bg_img_view}>
          <Image style={styles.upcomingWorkouts_bg_img} source={{
                uri: 'gradientbg'
            }}/>
        </View>
        <View style={styles.upcomingWorkouts_header}>
          <Text style={styles.upcomingWorkouts_heading}>
            UPCOMING WORKOUTS
          </Text>
        </View>
        <ScrollView style={styles.upcomingWorkouts_scrollView}>
        {loader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View style={styles.upcomingWorkouts_content_view}>
            {upcoming_workouts.length ?
                    upcoming_workouts.map((workout, i) => {


                        return (
          <View style={styles.upcomingWorkouts_content} key={i}>
                    <Text  style={styles.tuesday_heading}>
                      {workout[1] ? moment(workout[1]).format('dddd,MMMM Do') : "MONDAY, MARCH 12TH"}
                    </Text>

                    {todayDate === workout[1] ?

                    <TouchableOpacity onPress = {() => this.sendWorkout(workout[0].id)}>
                      <Image
                            style={{
                                height: 185,
                                width: '100%'
                            }}
                            source={{
                                uri: workout[0].backThumbnail_url
                            }}
                            />
                    </TouchableOpacity>
                    :
                    <TouchableOpacity onPress = {() => this.futureworkout()}>
                      <Image
                            style={{
                                height: 185,
                                width: '100%'
                            }}
                            source={{
                                uri: workout[0].backThumbnail_url
                            }}
                            />
                    </TouchableOpacity>

                }

                    <Text  style={styles.tuesday_heading}>
                      {workout[0].title} 
                    </Text>
          <Text style={{
                                textAlign: "right",
                                marginTop: -23,
                                backgroundColor: 'rgba(0,0,0,0)',
                                color: '#fff',
                                fontWeight: 'bold'
                            }}>{workout[0].duration ? workout[0].duration : "00:00"}</Text>          
                    <View style={styles.whiteline}></View>
                  </View>                  
                        );
                    })
                    :
                    <Text style={styles.upcomingWorkouts_heading}>
                ITS EMPTY IN HERE.
                SIGNUP FOR A WORKOUT
                AND TO GET STARTED!
              </Text>
                }
          </View>
            }
        </ScrollView>
        <View style={styles.wat_log_track_icons}>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity>
              <Image style={{
                width: 50,
                height: 50
            }} source={{
                uri: 'rgtarrow_a'
            }} />
              <Text style={{
                fontSize: 10,
                color: '#fff',
                backgroundColor: 'rgba(0,0,0,0)',
                marginLeft: -4
            }}>
                Watch Video
              </Text>
            </TouchableOpacity>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity
            activeOpacity={1} onPress = {() => {
                var a = [];
                this.trackactivity({
                    routeTo: 'Trackactivity',
                    'routeFrom': 'UpcomingWorkouts',
                    workout: [],
                    key: 0
                })
            }}>
              <Image style={{
                width: 50,
                height: 50
            }} source={{
                uri: 'timer_a'
            }} />
              <Text style={{
                fontSize: 10,
                color: '#fff',
                backgroundColor: 'rgba(0,0,0,0)',
                marginLeft: -5
            }}>
                Track activity
              </Text>
            </TouchableOpacity>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity
            activeOpacity={1} onPress = {() => this.logactivity()}>
              <Image style={{
                width: 50,
                height: 50
            }} source={{
                uri: 'fingerup_a'
            }} />
              <Text style={{
                fontSize: 10,
                color: '#fff',
                backgroundColor: 'rgba(0,0,0,0)',
                marginLeft: -2
            }}>
                Log activity
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.cross_icon}>
          <TouchableOpacity
            activeOpacity={1} onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('Tabs')
            }}>
            <Image style={{
                width: 45,
                height: 45
            }} source={{
                uri: 'cross'
            }} />
          </TouchableOpacity>
        </View>
        <View style={styles.trans_bg}>
          <Image style={{
                width: '100%',
                height: 84
            }} source={{
                uri: 'trans_bg'
            }} />
        </View>
        <View style={styles.btm_tabNavigation}>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: 0.3
            }}>
            <Image style={{
                width: 32,
                height: 28,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'feedicon_inactive_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 12
            }}>
              FEED
            </Text>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: 0.3
            }}>
            <Image style={{
                width: 28,
                height: 28,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'profileicon_inactive'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 12
            }}>
              PROFILE
            </Text>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <Image style={{
                width: 45,
                height: 45,
                marginTop: 3
            }} source={{
                uri: 'bottom_tab_middlelogo_inactive'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 12
            }}> </Text>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: 0.3
            }}>
            <Image style={{
                width: 28,
                height: 31,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'notificationicon_inactive_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 12
            }}>
              NOTIFICATION
            </Text>
          </View>
          <View style = {{
                flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: 0.3
            }}>
            <Image style={{
                width: 28,
                height: 28,
                top: 3,
                position: 'absolute'
            }} source={{
                uri: 'btnmenuicon_inactive_a'
            }} />
            <Text style={{
                fontSize: 10,
                color: '#fff',
                marginTop: 12
            }}>
              MORE
            </Text>
          </View>
        </View>

                <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />       

      </View>
        );
    }
}
