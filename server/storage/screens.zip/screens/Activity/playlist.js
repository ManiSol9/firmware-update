import React, { Component } from 'react';
import Video from 'react-native-video';
import { TouchableWithoutFeedback, Switch, Dimensions, NativeAppEventEmitter, NativeEventEmitter, Alert, NativeModules, PermissionsAndroid, ListView, TouchableHighlight, AppState, ImageBackground, PanResponder, TouchableOpacity, StyleSheet, Touchable, Animated, Platform, Easing, Image, View, Text } from 'react-native';
import _ from 'lodash';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';
import moment from 'moment';
import { AsyncStorage } from "react-native";
import BleManager from 'react-native-ble-manager';

import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { addToTable, addSensorData } from '../../template/api.js';
const window = Dimensions.get('window');
const ds = new ListView.DataSource({
    rowHasChanged: (r1, r2) => r1 !== r2
});
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import { getExercises, getExerciseDetails, getSensorData, sendStatus } from '../../template/api.js';
import { addToSQLiteTable } from '../../template/SQLiteOperationsOffline.js';
import KeepAwake from 'react-native-keep-awake';
import Orientation from 'react-native-orientation';

import Toast, { DURATION } from 'react-native-easy-toast'

const BleManagerModule = NativeModules.BleManager;
const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);


import { request } from 'graphql-request'


export default class VideoExcierce extends Component {
    constructor(props) {
        super(props);

        /**
         * All of our values that are updated by the
         * methods and listeners in this class
         */
        this.state = {
            // Video
            resizeMode: 'stretch',
            paused: this.props.paused || false,
            muted: this.props.muted || false,
            volume: this.props.volume || 1,
            rate: this.props.rate || 1,

            // Controls
            isFullscreen: true,
            showTimeRemaining: true,
            volumeTrackWidth: 0,
            lastScreenPress: 0,
            volumeFillWidth: 0,
            seekerFillWidth: 0,
            showControls: true,
            volumePosition: 0,
            seekerPosition: 0,
            volumeOffset: 0,
            seekerOffset: 0,
            seeking: false,
            loading: false,
            currentTime: 0,
            error: false,
            duration: 0,

            //Subtitle
            subtitleIndex: 0,
            currentTimeInDeciSeconds: 0,
            isVideoCompleted: 0,
            showPlayControls: true,
            showHeartandTime: true,
            scanning: false,
            peripherals: new Map(),
            appState: '',
            heartrate: 0,
            screenchange: '0',
            time: moment().format("LTS"),
            date: moment().format("LL"),
            totsec: 2400,
            item: 0,
            array: [],
            sum: 0,
            average: 0,
            calories: 0,
            user_id: null,
            profile: [],
            height: '',
            weight: '',
            showplaypause: false,
            timepassed: false,
            rate: 1,
            duration: 0.0,
            currentTime: 0.0,
            paused: true,
            loader: false,
            times: 0,
            timevalue: '0:0',
            started: false,
            seconds1: 0,
            /**/
            bleDeviceConnected: false,
            exerciseStarted: false,
            connected: false,
            contentLoader: true,
            connected: false,
            bleDeviceConnected: false,
            exerciseStarted: false,
            images: ['back1', 'back2', 'back3', 'back4', 'main'],
            pauseReading: true,
            completeReading: false,
            startReading: true,
            startvideo:0,
            streaming_uri: null
        };

        /**
         * Any options that can be set at init.
         */
        this.opts = {
            playWhenInactive: this.props.playWhenInactive || false,
            playInBackground: this.props.playInBackground || false,
            repeat: this.props.repeat || false,
            title: this.props.title || ''
        };

        /**
         * Our app listeners and associated methods
         */
        this.events = {
            onError: this.props.onError || this._onError.bind(this),
            onEnd: this.props.onEnd || this._onEnd.bind(this),
            onLoadStart: this._onLoadStart.bind(this),
            onProgress: this._onProgress.bind(this),
            onLoad: this._onLoad.bind(this)
        };

        /**
         * Functions used throughout the application
         */
        this.methods = {
            onBack: this.props.onBack || this._onBack.bind(this),
            toggleFullscreen: this._toggleFullscreen.bind(this),
            togglePlayPause: this._togglePlayPause.bind(this),
            toggleControls: this._toggleControls.bind(this),
            toggleTimer: this._toggleTimer.bind(this)
        };

        /**
         * Player information
         */
        this.player = {
            controlTimeoutDelay: this.props.controlTimeout || 3000,
            volumePanResponder: PanResponder,
            seekPanResponder: PanResponder,
            controlTimeout: null,
            volumeWidth: 150,
            iconOffset: 7,
            seekWidth: 0,
            ref: Video
        };

        /**
         * Various animations
         */
        this.animations = {
            bottomControl: {
                marginBottom: new Animated.Value(0),
                opacity: new Animated.Value(1)
            },
            topControl: {
                marginTop: new Animated.Value(0),
                opacity: new Animated.Value(1)
            },
            video: {
                opacity: new Animated.Value(1)
            },
            loader: {
                rotate: new Animated.Value(0),
                MAX_VALUE: 720
            }
        };

        /**
         * Various styles that be added...
         */
        this.styles = {
            videoStyle: this.props.videoStyle || {},
            containerStyle: this.props.style || {}
        };

        this.handleDiscoverPeripheral = this.handleDiscoverPeripheral.bind(this);
        this.handleStopScan = this.handleStopScan.bind(this);
        this.handleUpdateValueForCharacteristic = this.handleUpdateValueForCharacteristic.bind(this);
        this.handleDisconnectedPeripheral = this.handleDisconnectedPeripheral.bind(this);
        this.handleAppStateChange = this.handleAppStateChange.bind(this);



    }

    /**
      | -------------------------------------------------------
      | Events
      | -------------------------------------------------------
      |
      | These are the events that the <Video> component uses
      | and can be overridden by assigning it as a prop.
      | It is suggested that you override onEnd.
      |
      */

    /**
     * When load starts we display a loading icon
     * and show the controls.
     */
    _onLoadStart() {
        let state = this.state;
        state.loading = true;
        this.loadAnimation();
        this.setState(state);

        if (typeof this.props.onLoadStart === 'function') {
            this.props.onLoadStart(...arguments);
        }
    }

    /**
     * When load is finished we hide the load icon
     * and hide the controls. We also set the
     * video duration.
     *
     * @param {object} data The video meta data
     */
    _onLoad(data = {}) {
        let state = this.state;

        state.duration = data.duration;
        state.loading = false;
        this.setState(state);

        if (state.showControls) {
            this.setControlTimeout();
        }

        if (typeof this.props.onLoad === 'function') {
            this.props.onLoad(...arguments);
        }
    }

    /**
     * For onprogress we fire listeners that
     * update our seekbar and timer.
     *
     * @param {object} data The video meta data
     */
    _onProgress(data = {}) {
        let state = this.state;
        state.currentTime = data.currentTime;

        if (!state.seeking) {
            const position = this.calculateSeekerPosition();
            this.setSeekerPosition(position);
        }

        if (typeof this.props.onProgress === 'function') {
            this.props.onProgress(...arguments);
        }
        state.currentTimeInDeciSeconds = Math.floor(data.currentTime * 10) / 10.0;

        this.setState(state);
    }

    /**
     * It is suggested that you override this
     * command so your app knows what to do.
     * Either close the video or go to a
     * new page.
     */
    _onEnd() {
        this.setState({
            paused: true
        })
    }
    _onEndPlay = () => {

      this.state.startvideo = this.state.startvideo + 1

      var mediaJSON = { "categories" : [ { "name" : "Movies",
              "videos" : [ 
              { "description" : "Big Buck Bunny tells the story of a giant rabbit with a heart bigger than himself. When one sunny day three rodents rudely harass him, something snaps... and the rabbit ain't no bunny anymore! In the typical cartoon tradition he prepares the nasty rodents a comical revenge.\n\nLicensed under the Creative Commons Attribution license\nhttp://www.bigbuckbunny.org",
                    "sources" : [ "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" ],
                    "subtitle" : "By Blender Foundation",
                    "thumb" : "images/BigBuckBunny.jpg",
                    "title" : "Big Buck Bunny"
                  },
                  { "description" : "The first Blender Open Movie from 2006",
                    "sources" : [ "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" ],
                    "subtitle" : "By Blender Foundation",
                    "thumb" : "images/ElephantsDream.jpg",
                    "title" : "Elephant Dream"
                  },

          ]}]};


        var videos = mediaJSON.categories[0].videos

        if(this.state.startvideo < videos.length) {

        playlist_next_video = videos[this.state.startvideo].sources[0]

        console.log(this.state.startvideo)

        this.setState({streaming_uri: playlist_next_video})

        console.log(this.state.streaming_uri)


        this.setState({
            isVideoCompleted: false,
            paused: false
        })          

        } else {

          this._sendStatus()

        }
    }

    _replay = () => {

        //alert('asdadadsa')

        console.log(this.state.isVideoCompleted)
        this.seekTo(0)

        this.setState({
            isVideoCompleted: false,
            paused: false
        })

    }

    /**
     * Set the error state to true which then
     * changes our renderError function
     *
     * @param {object} err  Err obj returned from <Video> component
     */
    _onError(err) {
        let state = this.state;
        state.error = true;
        state.loading = false;

        this.setState(state);
    }

    /**
     * This is a single and double tap listener
     * when the user taps the screen anywhere.
     * One tap toggles controls, two toggles
     * fullscreen mode.
     */
    _onScreenTouch() {
        let state = this.state;
        const time = new Date().getTime();
        const delta = time - state.lastScreenPress;

        if (delta < 300) {
            //this.methods.toggleFullscreen();
            this.setState({
                showPlayControls: false
            })
        }

        this.methods.toggleControls();
        state.lastScreenPress = time;

        this.setState(state);
    }

    /**
      | -------------------------------------------------------
      | Methods
      | -------------------------------------------------------
      |
      | These are all of our functions that interact with
      | various parts of the class. Anything from
      | calculating time remaining in a video
      | to handling control operations.
      |
      */

    /**
     * Set a timeout when the controls are shown
     * that hides them after a length of time.
     * Default is 15s
     */
    setControlTimeout() {
        this.player.controlTimeout = setTimeout(() => {
            this._hideControls();
        }, this.player.controlTimeoutDelay);
    }

    /**
     * Clear the hide controls timeout.
     */
    clearControlTimeout() {
        clearTimeout(this.player.controlTimeout);
    }

    /**
     * Reset the timer completely
     */
    resetControlTimeout() {
        this.clearControlTimeout();
        this.setControlTimeout();
    }

    /**
     * Animation to hide controls. We fade the
     * display to 0 then move them off the
     * screen so they're not interactable
     */
    hideControlAnimation() {
        Animated.parallel([
            Animated.timing(this.animations.topControl.opacity, {
                toValue: 0
            }),
            Animated.timing(this.animations.topControl.marginTop, {
                toValue: -100
            }),
            Animated.timing(this.animations.bottomControl.opacity, {
                toValue: 0
            }),
            Animated.timing(this.animations.bottomControl.marginBottom, {
                toValue: -100
            })
        ]).start();
    }

    /**
     * Animation to show controls...opposite of
     * above...move onto the screen and then
     * fade in.
     */
    showControlAnimation() {
        Animated.parallel([
            Animated.timing(this.animations.topControl.opacity, {
                toValue: 1
            }),
            Animated.timing(this.animations.topControl.marginTop, {
                toValue: 0
            }),
            Animated.timing(this.animations.bottomControl.opacity, {
                toValue: 1
            }),
            Animated.timing(this.animations.bottomControl.marginBottom, {
                toValue: 0
            })
        ]).start();
    }

    /**
     * Loop animation to spin loader icon. If not loading then stop loop.
     */
    loadAnimation() {
        if (this.state.loading) {
            Animated.sequence([
                Animated.timing(this.animations.loader.rotate, {
                    toValue: this.animations.loader.MAX_VALUE,
                    duration: 1500,
                    easing: Easing.linear
                }),
                Animated.timing(this.animations.loader.rotate, {
                    toValue: 0,
                    duration: 0,
                    easing: Easing.linear
                })
            ]).start(this.loadAnimation.bind(this));
        }
    }

    /**
     * Function to hide the controls. Sets our
     * state then calls the animation.
     */
    _hideControls() {
        this.setState({
            showControls: false
        })
    }

    _hidePlayControls = () => {
        this.setState({
            showPlayControls: true
        })

        this.setTimeout(() => {

            this.setState({
                showPlayControls: false
            })

        }, 10000);

    }


    /**
     * Function to toggle controls based on
     * current state.
     */
    _toggleControls() {
        let state = this.state;
        state.showControls = !state.showControls;

        if (state.showControls) {
            this.showControlAnimation();
            this.setControlTimeout();
        } else {
            this.hideControlAnimation();
            this.clearControlTimeout();
        }

        this.setState(state);
    }

    /**
     * Toggle fullscreen changes resizeMode on
     * the <Video> component then updates the
     * isFullscreen state.
     */
    _toggleFullscreen() {
        if (this.props.toggleFullscreen) {
            this.props.toggleFullscreen();
        } else {
            let state = this.state;
            state.isFullscreen = !state.isFullscreen;
            state.resizeMode = state.isFullscreen === true ? 'cover' : 'contain';

            this.setState(state);
        }
    }

    /**
     * Toggle playing state on <Video> component
     */
    _togglePlayPause() {
        let state = this.state;
        state.paused = !state.paused;
        this.setState(state);
    }

    /**
     * Toggle between showing time remaining or
     * video duration in the timer control
     */
    _toggleTimer() {
        let state = this.state;
        state.showTimeRemaining = !state.showTimeRemaining;
        this.setState(state);
    }

    /**
     * The default 'onBack' function pops the navigator
     * and as such the video player requires a
     * navigator prop by default.
     */
    _onBack() {
        if (this.props.navigator && this.props.navigator.pop) {
            this.props.navigator.pop();
        } else {
            console.warn(
                'Warning: _onBack requires navigator property to function. Either modify the onBack prop or pass a navigator prop'
            );
        }
    }

    /**
     * Calculate the time to show in the timer area
     * based on if they want to see time remaining
     * or duration. Formatted to look as 00:00.
     */
    calculateTime() {
        if (this.state.showTimeRemaining) {
            const time = this.state.duration - this.state.currentTime;
            return `${this.formatTime(time)}`;
        }

        return this.formatTime(this.state.currentTime);
    }

    /**
     * Format a time string as mm:ss
     *
     * @param {int} time time in milliseconds
     * @return {string} formatted time string in mm:ss format
     */
    formatTime(time = 0) {
        const symbol = this.state.showRemainingTime ? '-' : '';
        time = Math.min(Math.max(time, 0), this.state.duration);

        const formattedMinutes = _.padStart(Math.floor(time / 60).toFixed(0), 2, 0);
        const formattedSeconds = _.padStart(Math.floor(time % 60).toFixed(0), 2, 0);

        return `${symbol}${formattedMinutes}:${formattedSeconds}`;
    }

    /**
     * Set the position of the seekbar's components
     * (both fill and handle) according to the
     * position supplied.
     *
     * @param {float} position position in px of seeker handle}
     */
    setSeekerPosition(position = 0) {
        let state = this.state;
        position = this.constrainToSeekerMinMax(position);
        state.seekerFillWidth = position;
        state.seekerPosition = position;

        if (!state.seeking) {
            state.seekerOffset = position;
        }

        this.setState(state);
    }

    /**
     * Contrain the location of the seeker to the
     * min/max value based on how big the
     * seeker is.
     *
     * @param {float} val position of seeker handle in px
     * @return {float} contrained position of seeker handle in px
     */
    constrainToSeekerMinMax(val = 0) {
        if (val <= 0) {
            return 0;
        } else if (val >= this.player.seekerWidth) {
            return this.player.seekerWidth;
        }
        return val;
    }

    /**
     * Calculate the position that the seeker should be
     * at along its track.
     *
     * @return {float} position of seeker handle in px based on currentTime
     */
    calculateSeekerPosition() {
        const percent = this.state.currentTime / this.state.duration;
        return this.player.seekerWidth * percent;
    }

    /**
     * Return the time that the video should be at
     * based on where the seeker handle is.
     *
     * @return {float} time in ms based on seekerPosition.
     */
    calculateTimeFromSeekerPosition() {
        const percent = this.state.seekerPosition / this.player.seekerWidth;
        return this.state.duration * percent;
    }

    /**
     * Seek to a time in the video.
     *
     * @param {float} time time to seek to in ms
     */
    seekTo(time = 0) {
        let state = this.state;
        state.currentTime = time;
        this.player.ref.seek(time);
        this.setState(state);
    }

    /**
     * Set the position of the volume slider
     *
     * @param {float} position position of the volume handle in px
     */
    setVolumePosition(position = 0) {
        let state = this.state;
        position = this.constrainToVolumeMinMax(position);
        state.volumePosition = position + this.player.iconOffset;
        state.volumeFillWidth = position;

        state.volumeTrackWidth = this.player.volumeWidth - state.volumeFillWidth;

        if (state.volumeFillWidth < 0) {
            state.volumeFillWidth = 0;
        }

        if (state.volumeTrackWidth > 150) {
            state.volumeTrackWidth = 150;
        }

        this.setState(state);
    }

    /**
     * Constrain the volume bar to the min/max of
     * its track's width.
     *
     * @param {float} val position of the volume handle in px
     * @return {float} contrained position of the volume handle in px
     */
    constrainToVolumeMinMax(val = 0) {
        if (val <= 0) {
            return 0;
        } else if (val >= this.player.volumeWidth + 9) {
            return this.player.volumeWidth + 9;
        }
        return val;
    }

    /**
     * Get the volume based on the position of the
     * volume object.
     *
     * @return {float} volume level based on volume handle position
     */
    calculateVolumeFromVolumePosition() {
        return this.state.volumePosition / this.player.volumeWidth;
    }

    /**
     * Get the position of the volume handle based
     * on the volume
     *
     * @return {float} volume handle position in px based on volume
     */
    calculateVolumePositionFromVolume() {
        return this.player.volumeWidth / this.state.volume;
    }

    /**
      | -------------------------------------------------------
      | React Component functions
      | -------------------------------------------------------
      |
      | Here we're initializing our listeners and getting
      | the component ready using the built-in React
      | Component methods
      |
      */

    /**
     * Before mounting, init our seekbar and volume bar
     * pan responders.
     */
    async componentWillMount() {
        this.initSeekPanResponder();
        this.initVolumePanResponder();
        const init = Orientation.getInitialOrientation();
        this.setState({
            init,
            orientation: init,
            specificOrientation: init,
            resizeMode: 'stretch'
        });

        this.setTimeout(() => {

            this.setState({
                showPlayControls: false,
                isVideoCompleted: false
            })

        }, 10000);

        /*

        var {exerciseID, user_id, workoutID, workout_day, courseID} = this.props.navigation.state.params.params;

        let device_id = await AsyncStorage.getItem("DEVICE_ID");
        let device_name = await AsyncStorage.getItem("DEVICE_NAME");
        const {navigate} = this.props.navigation;
        console.log(device_id, device_name)
        if (!device_id || !device_name) {
            navigate('SearchDevices')
        }

        this._getStudentDetails(user_id);

        this.bleConnect(this.state.device_id)

        /*

        this.setTimeout(() => {

            this.checkstate(this.state.connected)

        }, 10000);

        */

        KeepAwake.activate();

        const initial = Orientation.getInitialOrientation();
        if (initial === 'PORTRAIT') {
            console.log(initial)
        } else {
            console.log(initial)
        }

        const query = `{
                        fetch_workout_segment(workout_id:149){
                          workout_id
                          exercise_id
                          rest_time
                          exercise_index
                          
                          workout_segment_details{
                            exercise_index
                            title
                            description
                            start_time
                            end_time
                            streaming_url
                            back_thumbnail_url
                            exercise_id
                          }
                        }
                      }`;


        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_segment', query)
            .then(async data => {
                
                console.log(data.fetch_workout_segment[0].workout_segment_details)               

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    loader: false,
                    ontentLoader: false
                })
            }
        )



    }

    /**
     * To allow basic playback management from the outside
     * we have to handle possible props changes to state changes
     */
    componentWillReceiveProps(nextProps) {
        if (this.state.paused !== nextProps.paused) {
            this.setState({
                paused: nextProps.paused,
                showControls: true
            });
        }
    }

    /**
     * Upon mounting, calculate the position of the volume
     * bar based on the volume property supplied to it.
     */
    async componentDidMount() {


        const position = this.calculateVolumePositionFromVolume();
        let state = this.state;
        this.setVolumePosition(position);
        state.volumeOffset = position;
        Orientation.addOrientationListener(this._updateOrientation);
        Orientation.addSpecificOrientationListener(this._updateSpecificOrientation);
        Orientation.lockToLandscape();

        this.setState(state);

        this.setState({
            device_id: await AsyncStorage.getItem("DEVICE_ID")
        }, () => {

        })

        /*

        AppState.addEventListener('change', this.handleAppStateChange);

        this.handlerDiscover = bleManagerEmitter.addListener('BleManagerDiscoverPeripheral', this.handleDiscoverPeripheral);
        this.handlerStop = bleManagerEmitter.addListener('BleManagerStopScan', this.handleStopScan);
        this.handlerDisconnect = bleManagerEmitter.addListener('BleManagerDisconnectPeripheral', this.handleDisconnectedPeripheral);
        this.handlerUpdate = bleManagerEmitter.addListener('BleManagerDidUpdateValueForCharacteristic', this.handleUpdateValueForCharacteristic);


        */
    }

    _getOrientation() {
        Orientation.getOrientation((err, orientation) => {
            //Alert.alert(`Orientation is ${orientation}`);
        });
    }

    _getSpecificOrientation() {
        Orientation.getSpecificOrientation((err, orientation) => {
            Alert.alert(`Specific orientation is ${orientation}`);
        });
    }

    _updateOrientation = (orientation) => {
        this.setState({
            orientation
        });
        console.log(orientation)

        if (orientation == 'LANDSCAPE') {
            this.setState({
                resizeMode: 'stretch',
                isFullscreen: true
            })
        } else {
            this.setState({
                resizeMode: 'contain',
                isFullscreen: false
            })
        }
    }
    _updateSpecificOrientation = (specificOrientation) => this.setState({
        specificOrientation
    });


    _handlePress = () => {
        this.setState({
            showHeartandTime: !this.state.showHeartandTime
        })
        console.log(this.state.showHeartandTime)
    }


    /**
     * When the component is about to unmount kill the
     * timeout less it fire in the prev/next scene
     
    componentWillUnmount() {
        this.clearControlTimeout();
    }

    /**
     * Get our seekbar responder going
     */
    initSeekPanResponder() {
        this.player.seekPanResponder = PanResponder.create({
            // Ask to be the responder.
            onStartShouldSetPanResponder: (evt, gestureState) => true,
            onMoveShouldSetPanResponder: (evt, gestureState) => true,

            /**
             * When we start the pan tell the machine that we're
             * seeking. This stops it from updating the seekbar
             * position in the onProgress listener.
             */
            onPanResponderGrant: (evt, gestureState) => {
                let state = this.state;
                this.clearControlTimeout();
                state.seeking = true;
                this.setState(state);
            },

            /**
             * When panning, update the seekbar position, duh.
             */
            onPanResponderMove: (evt, gestureState) => {
                const position = this.state.seekerOffset + gestureState.dx;
                this.setSeekerPosition(position);

                this.setState({
                    showPlayControls: false,
                    isVideoCompleted: false
                })

            },

            /**
             * On release we update the time and seek to it in the video.
             * If you seek to the end of the video we fire the
             * onEnd callback
             */
            onPanResponderRelease: (evt, gestureState) => {
                const time = this.calculateTimeFromSeekerPosition();
                let state = this.state;
                if (time >= state.duration && !state.loading) {
                    state.paused = true;
                    this.events.onEnd();
                } else {
                    this.seekTo(time);
                    this.setControlTimeout();
                    state.seeking = false;
                }
                this.setState(state);
            }
        });
    }

    /**
     * Initialize the volume pan responder.
     */
    initVolumePanResponder() {
        this.player.volumePanResponder = PanResponder.create({
            onStartShouldSetPanResponder: (evt, gestureState) => true,
            onMoveShouldSetPanResponder: (evt, gestureState) => true,
            onPanResponderGrant: (evt, gestureState) => {
                this.clearControlTimeout();
            },

            /**
             * Update the volume as we change the position.
             * If we go to 0 then turn on the mute prop
             * to avoid that weird static-y sound.
             */

            onPanResponderMove: (evt, gestureState) => {
                let state = this.state;
                const position = this.state.volumeOffset + gestureState.dx;

                this.setVolumePosition(position);
                state.volume = this.calculateVolumeFromVolumePosition();
                if (state.volume <= 0.046666667) {
                    state.muted = true;
                } else {
                    state.muted = false;
                }

                this.setState(state);
            },

            /**
             * Update the offset...
             */
            onPanResponderRelease: (evt, gestureState) => {
                let state = this.state;
                state.volumeOffset = state.volumePosition;
                this.setControlTimeout();
                this.setState(state);
            }
        });
    }
    /**
     * Subtitle Rendering Part
     *
     *
     */
    binarySearch = (subtitles, first, last, value) => {
        if (first > last) return -1;
        let mid = Math.floor((first + last) / 2);
        if (
                value > this.parseTimeStringToDeciSecond(subtitles[mid].startTime) &&
                value < this.parseTimeStringToDeciSecond(subtitles[mid].endTime)
            )
            return mid;
        else if (value < this.parseTimeStringToDeciSecond(subtitles[mid].startTime))
            return this.binarySearch(subtitles, first, mid - 1, value);
        else if (value > this.parseTimeStringToDeciSecond(subtitles[mid].endTime))
            return this.binarySearch(subtitles, mid + 1, last, value);
    };
    parseTimeStringToDeciSecond = str => {
        let splitByComma = str.split(',');
        let result = 0.0;
        result = Math.round(parseInt(splitByComma[1]) / 100.0) / 10.0;
        let splitByColon = splitByComma[0].split(':');
        for (let i = 0; i < 3; i++) {
            result += splitByColon[i] * Math.pow(60, 2 - i);
        }
        return (Math.floor(result * 10) / 10.0).toFixed(1);
    };
    showSubtitle() {
        if (!this.props.subtitle) return null;
        let currentTime = this.state.currentTimeInDeciSeconds;
        let subtitleIndex = this.state.subtitleIndex;
        let subtitles = this.props.subtitle;
        if (!subtitles[subtitleIndex])
            return null;
        let startTime = this.parseTimeStringToDeciSecond(
            subtitles[subtitleIndex].startTime
        );
        let endTime = this.parseTimeStringToDeciSecond(
            subtitles[subtitleIndex].endTime
        );
        if (currentTime > endTime)
            this.setState({
                subtitleIndex: subtitleIndex + 1
            });
        if (currentTime < endTime && currentTime > startTime) {
            return subtitles[subtitleIndex].text;
        } else return null;
    }
    /**End of Subtitle Part */
    /**
      | -------------------------------------------------------
      | Rendering
      | -------------------------------------------------------
      |
      | This section contains all of our render methods.
      | In addition to the typical React render func
      | we also have all the render methods for
      | the controls.
      |
      */

    /**
     * Standard render control function that handles
     * everything except the sliders. Adds a
     * consistent <TouchableHighlight>
     * wrapper and styling.
     */
    renderControl(children, callback, style = {}) {
        return (
            <TouchableHighlight
            underlayColor="transparent"
            activeOpacity={0.3}
            onPress={() => {
                this.resetControlTimeout();
            //callback();
            }}
            style={[styles.controls.control, style]}>
        {children}
      </TouchableHighlight>
        );
    }

    /**
     * Groups the top bar controls together in an animated
     * view and spaces them out.
     */
    renderTopControls() {
        const backControl = !this.props.disableBack
            ? this.renderBack()
            : this.renderNullControl();
        const volumeControl = !this.props.disableVolume
            ? this.renderVolume()
            : this.renderNullControl();
        const fullscreenControl = !this.props.disableFullscreen
            ? this.renderFullscreen()
            : this.renderNullControl();

        return (
            <Animated.View
            style={[
                styles.controls.top,
                {
                    opacity: this.animations.topControl.opacity,
                    marginTop: this.animations.topControl.marginTop
                }
            ]}>
        <ImageBackground
            source={require('./assets/img/top-vignette.png')}
            style={[styles.controls.column]}
            imageStyle={[styles.controls.vignette]}>
          <View style={styles.controls.topControlGroup}>
            {backControl}
            <View style={styles.controls.pullRight}>
              {volumeControl}
              {fullscreenControl}
            </View>
          </View>
        </ImageBackground>
      </Animated.View>
        );
    }

    /**
     * Back button control
     */
    renderBack() {
        return this.renderControl(
            <View></View>,
            this.methods.onBack,
            styles.controls.back
        );
    }

    /**
     * Render the volume slider and attach the pan handlers
     */
    renderVolume() {
        return (
            <View style={styles.volume.container}>
            </View>
        );
    }

    /**
     * Render fullscreen toggle and set icon based on the fullscreen state.
     */
    renderFullscreen() {
        return this.renderControl(
            <View style={{
                backgroundColor: 'transparent'
            }}>
            </View>
        );
    }

    /**
     * Render bottom control group and wrap it in a holder
     */
    renderBottomControls() {
        const playPauseControl = !this.props.disablePlayPause
            ? this.renderNullControl()
            : this.renderNullControl();
        const timerControl = !this.props.disableTimer
            ? this.renderTimer()
            : this.renderNullControl();
        const seekbarControl = !this.props.disableSeekbar
            ? this.renderSeekbar()
            : this.renderNullControl();

        return (
            <Animated.View
            style={[
                styles.controls.bottom,
                {
                    opacity: this.animations.bottomControl.opacity,
                    marginBottom: this.animations.bottomControl.marginBottom
                }
            ]}>
        <ImageBackground
            source={require('./assets/img/bottom-vignette.png')}
            style={[styles.controls.column]}
            imageStyle={[styles.controls.vignette]}>
          
          <View
            style={[styles.controls.row, styles.controls.bottomControlGroup]}>
            {playPauseControl}
            {this.renderTitle()}
            {timerControl}
          </View>
          {seekbarControl}
        </ImageBackground>
      </Animated.View>
        );
    }

    /**
     * Render the seekbar and attach its handlers
     */
    renderSeekbar() {
        return (
            <View style={styles.seekbar.container}>
        <View
            style={styles.seekbar.track}
            onLayout={event => (this.player.seekerWidth = event.nativeEvent.layout.width)
            }>
          <View
            style={[
                styles.seekbar.fill,
                {
                    width: this.state.seekerFillWidth,
                    backgroundColor: this.props.seekColor || '#ff7200'
                }
            ]}
            />
        </View>
        <View
            style={[styles.seekbar.handle, {
                left: this.state.seekerPosition
            }]}
            {...this.player.seekPanResponder.panHandlers}>
          <View
            style={[
                styles.seekbar.circle,
                {
                    backgroundColor: this.props.seekColor || '#ff7200'
                }
            ]}
            />
        </View>
      </View>
        );
    }





    /**
     * Render the play/pause button and show the respective icon
     */
    renderPlayPause() {
        console.log(this.state.isVideoCompleted)
        return this.renderControl(
            <View style={{
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 0,
                backgroundColor: 'transparent',
                marginTop: this.state.resizeMode === 'stretch' ? 50 : -20,
                flex:1,
                flexDirection: 'column'
            }}>
            {this.state.showPlayControls ? this.state.isVideoCompleted ?
                <View style={{borderWidth: 2, width: 150}}><Icon name="repeat" size={45} style={{
                    color: "#ff7200",
                    backgroundColor: 'transparent'                
                }}
                onPress={() => this._replay()}/>
                <Icon name="repeat" size={45} style={{
                    color: "#ff7200",
                    backgroundColor: 'transparent'
                }}
                onPress={() => this._nextVideo()}/>
                </View>


                : this.state.paused ? <Icon name="play" size={45} style={{
                    color: "#ff7200",
                    backgroundColor: 'transparent'
                }}
                onPress={() => this.setState({
                    paused: !this.state.paused,
                })}
                /> :
                    <Icon name="pause" size={45} style={{
                        color: "#ff7200",
                        backgroundColor: 'transparent'
                    }}
                    onPress={() => this.setState({
                        paused: !this.state.paused,
                    })}
                    /> : <Text></Text>
            } 
            </View>,
            this.methods.togglePlayPause,
            styles.controls.playPause
        );
    }

    /**
     * Render our title...if supplied.
     */
    renderTitle() {
        if (this.opts.title) {
            return (
                <View style={[styles.controls.control, styles.controls.title]}>
          <Text
                style={[styles.controls.text, styles.controls.titleText]}
                numberOfLines={1}>
            {this.opts.title || ''}
          </Text>
        </View>
            );
        }

        return null;
    }

    /**
     * Show our timer.
     */
    renderTimer() {

        const {showHeartandTime} = this.state

        return this.renderControl(

            <View style={{
                width: 120,
                borderRadius: 75,
                height: 120,
                borderWidth: 5,
                alignItems: 'center',
                justifyContent: 'center',
                borderColor: '#ff7200',
                marginLeft: -55,
                marginTop: -40,
                backgroundColor: 'transparent'
            }}>
            <Icon name="clock-o" size={30} style={{
                color: "#ff7200",
                marginBottom: 5,
                marginTop: -10
            }} />
                    <Text style={{
                color: '#fff',
                fontSize: 12,
                fontWeight: 'bold',
                backgroundColor: 'transparent'
            }}>Remaining</Text>             
            <Text style={{
                color: '#fff',
                fontSize: 30,
                fontWeight: 'bold'
            }}>{this.calculateTime()}</Text>
          </View>
            ,
            this.methods.toggleTimer,
            styles.controls.timer
        );
    }

    /**
     * Renders an empty control, used to disable a control without breaking the view layout.
     */
    renderNullControl() {
        return this.renderControl(<View style={{
            backgroundColor: 'transparent'
        }}/>);
    }


    /**
     * Show loading icon
     */
    renderLoader() {
        if (this.state.loading) {
            return (
                <View style={styles.loader.container}>
          <Animated.Image
                source={require('./assets/img/loader-icon.png')}
                style={[
                    styles.loader.icon,
                    {
                        transform: [
                            {
                                rotate: this.animations.loader.rotate.interpolate({
                                    inputRange: [0, 360],
                                    outputRange: ['0deg', '360deg']
                                })
                            }
                        ]
                    }
                ]}
                />
        </View>
            );
        }
        return null;
    }

    renderError() {
        if (this.state.error) {
            return (
                <View style={styles.error.container}>
          <Image
                source={require('./assets/img/error-icon.png')}
                style={styles.error.icon}
                />
          <Text style={styles.error.text}>Video unavailable</Text>
        </View>
            );
        }
        return null;
    }
    renderSubtitle() {
        return (
            <View
            style={
            this.props.isFullscreen
                ? styles.player.subtitleContainerLandscape
                : styles.player.subtitleContainerPortrait
            }>
        <Text style={styles.player.subtitle}>{this.showSubtitle()}</Text>
      </View>
        );
    }

    /**
     * Provide all of our options and render the whole component.
     */



    addBLERoute=async () => {
        const {navigate} = this.props.navigation;
        Alert.alert(
            'Maku sure your device is near By', 'Start actvity again',
            [
                {
                    text: 'Ok',
                    onPress: () => navigate('UpcomingWorkouts')
                },
            ],
            {
                cancelable: false
            }
        )
    }

    _getStudentDetails=(id) => {
        getProfileDetails(id).then(response => {
            console.log(response)
            if (response.status) {
                this.setState({
                    profile: response.data
                }, () => {
                    console.log(this.state.profile)
                    this.setState({
                        height: this.state.profile.height_in_feet,
                        age: this.state.profile.age,
                        weight: this.state.profile.current_weight,
                        gender: this.state.profile.gender
                    }, () => {

                        if (this.state.profile.parameter_type == 1) {

                            this.setState({
                                height: this.state.profile.height_in_centimeter
                            })

                        } else {

                            var height_incm = (this.state.feet * 30.48) + (this.state.inches * 2.54)

                            this.setState({
                                height: height_incm
                            })
                        }

                    });
                });
                console.log(this.state)
            //this.setState({Loader:false, contentLoader:false})
            } else {
                //this.setState({Loader:false, contentLoader:false})
                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
            }
        }, err => {
            console.log(err)
        })
    }


    checkstate(connected) {
        const {navigate} = this.props.navigation;
        if (this.state.connected === false) {
            Alert.alert('Make Sure Your Device is Near By', 'Please Re Connect',
                [
                    {
                        text: 'Ok',
                        onPress: () => this.mani()
                    },
                ],
                {
                    cancelable: false
                }
            )
        } else {
            this.state.contentLoader = false

        }

    }

    mani = () => {
        alert('asdasdasda')
    }


    bleConnect(device_id) {
        let x = 0

        console.log(device_id)

        BleManager.connect(device_id).then(() => {
            console.log('inside connect')

            this.setState({
                connected: true
            })

            this.setTimeout(() => {

                BleManager.retrieveServices(device_id).then((peripheralInfo) => {

                    var service = '180D';
                    var bakeCharacteristic = '2A37';
                    var crustCharacteristic = '13333333-3333-3333-3333-333333330001';

                    this.setTimeout(() => {
                        BleManager.startNotification(device_id, service, bakeCharacteristic).then(() => {


                            console.log('Started notification on ' + device_id);
                            this.state.startbutton = 1;


                        }).catch((error) => {

                            //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                            this.state.loader = false

                            this.state.startbutton = 0

                            console.log('Connection error', error);


                        });
                    }, 200);
                }).catch((error) => {

                    //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                    this.state.loader = false

                    this.state.startbutton = 0

                    console.log('Connection error', error);


                });

            }, 900);

        }).catch((error) => {

            //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

            this.state.loader = false

            this.state.startbutton = 0

            console.log('Connection error', error);

        });

    }


    handleAppStateChange(nextAppState) {
        if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
            console.log('App has come to the foreground!')
            BleManager.getConnectedPeripherals([]).then((peripheralsArray) => {
                console.log('Connected peripherals: ' + peripheralsArray.length);
            });
        }
        this.setState({
            appState: nextAppState
        });
    }



    handleDisconnectedPeripheral(data) {
        let peripherals = this.state.peripherals;
        let peripheral = peripherals.get(data.peripheral);
        if (peripheral) {
            peripheral.connected = false;
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            });

        }
        console.log('Disconnected from ' + data.peripheral);

    }


    handleUpdateValueForCharacteristic(data) {
        console.log('Received data from ' + data.peripheral + ' characteristic ' + data.characteristic, data.value);
        this.setState({
            heartrate: data.value[1]
        });
        this.savedata(data.value[1])
    }

    savedata(data) {

        this.state.array[this.state.item] = data;

        if (this.state.item == 20) {
            this.setState(prevState => ({
                times: prevState.times + 20
            }))
            for (var i = 0; i < this.state.array.length; i++) {
                this.state.sum += parseInt(this.state.array[i]);
            }

            if (this.state.array.length > 0) {

                this.state.average = Math.round(this.state.sum / this.state.array.length);

                this.state.avg_heart_rate[this.state.increment] = this.state.average;

                if (this.state.age == null) {
                    this.state.age = 25
                }

                //console.log(this.state.age)  

                let calories = Math.round((0.4472 * this.state.average - 0.05741 * this.state.weight + 0.074 * this.state.age - 20.4022) * 0.333 / 4.184)

                //let calories = Math.round((-55.0969 + (0.6309 * this.state.average) + (0.1988 * (this.state.weight/2.2046) + (0.2017 * this.state.age))/4.184) * 60 * 0.005)

                if (calories < 0 || calories == 'null') {
                    calories = 0
                }

                this.state.calories = calories + this.state.calories;

                this.state.increment++

                console.log(this.state.age)

                console.log(this.state.calories)

            }

            this.state.item = 0;

            this.state.array = [];

            this.state.sum = 0;

        } else {

            this.state.item = this.state.item + 1;

        }

    }


    handleStopScan() {
        console.log('Scan is stopped');
        this.setState({
            scanning: false
        });
    }

    startScan() {
        if (!this.state.scanning) {
            BleManager.scan([], 30, true).then((results) => {
                console.log('Scanning...');
                this.refs.toast.show('Scanning....', DURATION.LENGTH_LONG);
                this.setState({
                    scanning: true
                });
            }).catch((error) => {
                console.log('Connection error', error);
                this.refs.toast.show('Connection error.... Please Try To Reconnect', DURATION.LENGTH_LONG);
            });
        }
    }

    handleDiscoverPeripheral(peripheral) {
        var peripherals = this.state.peripherals;
        if (!peripherals.has(peripheral.id)) {
            console.log('Got ble peripheral', peripheral);
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            })
        }
    }


    componentWillUnmount() {

        BleManager.disconnect(this.state.device_id)
            .then(() => {
                console.log('Disconnected');
            })
            .catch((error) => {
                console.log(error);
            });
        this.setState({});
        this.handlerDiscover.remove();
        this.handlerStop.remove();
        this.handlerDisconnect.remove();
        this.handlerUpdate.remove();

        Orientation.lockToPortrait();

        this.clearControlTimeout();


    }

    savedata(data) {

        //console.log(calories)

        this.state.array[this.state.item] = data;

        if (this.state.item == 20) {
            this.setState(prevState => ({
                times: prevState.times + 20
            }))
            for (var i = 0; i < this.state.array.length; i++) {
                this.state.sum += parseInt(this.state.array[i]);
                console.log('Value is ' + this.state.array.length);
            }

            if (this.state.array.length > 0) {

                this.state.average = Math.round(this.state.sum / this.state.array.length);

                if (this.state.age == null) {
                    this.state.age = 25
                }

                let calories = Math.round((0.4472 * this.state.average - 0.05741 * this.state.weight + 0.074 * this.state.age - 20.4022) * 0.333 / 4.184)

                //let calories = Math.round((-55.0969 + (0.6309 * this.state.average) + (0.1988 * (this.state.weight/2.2046) + (0.2017 * this.state.age))/4.184) * 60 * 0.005)

                if (calories < 0) {
                    calories = 0
                }

                this.state.calories = calories + this.state.calories;

                console.log(this.state.age)

                console.log(this.state.calories)

                this._storeInDB();

            }

            this.state.item = 0;

            this.state.array = [];

            this.state.sum = 0;

        } else {

            this.state.item = this.state.item + 1;

        }

    }


    _storeInDB() {

        console.log('assassa')

        var {user_id, exerciseID, workoutID, courseID, workout_day} = this.props.navigation.state.params.params;
        var {average, calories, times} = this.state;
        var data = {
            "user_id": user_id,
            "avg_heart_rate": average,
            "calories": calories,
            "exercise_id": exerciseID,
            "course_id": courseID,
            "workout_id": workoutID,
            "workout_day": workout_day
        }
        var toSQL = [user_id, exerciseID, average, times];
        addToSQLiteTable({
            table_name: 'sensor_data',
            table_data: toSQL
        }).then(response => {
            console.log(response);
        }, error => {
            console.log(error);
        })
        addSensorData(data).then(response => {
            console.log(response);
        }, error => {
            console.log(error);
        })
    }

    _sendStatus() {
        let statusvalue = 'completed'

        console.log(this)

        BleManager.disconnect(this.state.device_id)
            .then(() => {
                console.log('Disconnected');
            })
            .catch((error) => {
                console.log(error);
            });


        var cal = this.state.calories

        var min = 20

        var sec = 20

        var {exerciseID, user_id, workoutID, courseID, workout_day, workout_title} = this.props.navigation.state.params.params;


        let temp = {
            "user_id": user_id,
            "exercise_id": exerciseID,
            "workout_id": workoutID,
            "course_id": courseID,
            "workout_day": workout_day,
            "exercise_status": statusvalue
        };

        sendStatus(temp).then(res => {

            const {navigate} = this.props.navigation;

            var time = min + ':' + sec

            clearInterval(this.timer);

            navigate("WorkoutSummary", {
                workoutID: workoutID,
                calories: cal,
                time: time,
                workout_title: workout_title,
                courseID: courseID,
                workout_day: workout_day,
                user_id: user_id,
                exerciseID: exerciseID
            });

        },
            err => {
                console.log(err);
            })
    }

    onEndCall=() => {

        this.setState({
            paused: true
        })

        Alert.alert('Complete the workout?', '',
            [
                {
                    text: 'Ok',
                    onPress: () => this._sendStatus()
                },
                {
                    text: 'Cancel'
                }
            ],
            {
                cancelable: false
            }
        )

    }



    render() {

        /*

        var {exerciseID, streaming_uri, user_id, workoutID, courseID, workout_day, workout_title} = this.props.navigation.state.params.params;
        var {bleDeviceConnected, exerciseStarted} = this.state;
        const list = Array.from(this.state.peripherals.values());

        for (i = 0; i < list.length; i++) {
            if (list[i].id == this.state.device_id) {
                var device_data = list[i]
            }
        }

        */




        return (
            <TouchableWithoutFeedback
            onPress={() => this._hidePlayControls()}
            style={[styles.player.container, this.styles.containerStyle]}>
        <View style={[styles.player.container, this.styles.containerStyle]}>
               <Video source={{
                uri: this.state.streaming_uri
            }} // Can be a URL or a local file.
            ref={videoPlayer => (this.player.ref = videoPlayer)}
            resizeMode={this.state.resizeMode}
            volume={this.state.volume}
            paused={this.state.paused}
            muted={this.state.muted}
            rate={this.state.rate}
            onLoadStart={this.events.onLoadStart}
            onProgress={this.events.onProgress}
            onError={this.events.onError}
            onLoad={this.events.onLoad}
            onEnd={this._onEndPlay}
            //onEnd={this.props.onEnd}
            style={[styles.player.video, this.styles.videoStyle]} /> 
            

            <View style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'space-between',
                marginTop: 10
            }}>
        
            <View style={{
                width: '100%',
                backgroundColor: 'transparent',
                marginTop: 20,
                marginBottom: 10,
                height: this.state.resizeMode === 'stretch' ? 120 : 130,
                alignItems: 'flex-start',
            }}>

            {this.state.showHeartandTime ?
                <View style={{
                    width: '100%'
                }}><View style={{
                    width: 120,
                    borderRadius: 60,
                    height: 120,
                    borderWidth: 5,
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderColor: '#ff7200',
                    marginLeft: 20,
                    marginTop: this.state.resizeMode === 'stretch' ? 0 : 0
                }}>
                    <Icon
                name="heart" size={25} style={{
                    color: "#ff7200",
                    marginBottom: 5,
                    marginTop: -10,
                    backgroundColor: 'transparent'
                }} /> 
                    <Text style={{
                    color: '#fff',
                    fontSize: 12,
                    fontWeight: 'bold',
                    backgroundColor: 'transparent'
                }}>Hear rate</Text>                       
                    <Text style={{
                    color: '#fff',
                    fontSize: 37,
                    fontWeight: 'bold',
                    backgroundColor: 'transparent'
                }}>

                    {this.state.heartrate}
                    </Text>
                </View>
                <View style={{
                    alignItems: 'flex-end',
                    marginRight: 20,
                }}>

                    <TouchableOpacity onPress={this.onEndCall}>                      
                    <Icon
                name="close" size={30} style={{
                    color: "#ff7200",
                    marginBottom: 5,
                    marginTop: -130,

                    backgroundColor: 'transparent'
                }}
                /> 
                  </TouchableOpacity>
                </View>
                </View> :
                <View>
                </View>
            }

            </View>
            <View style={{
                width: '100%',
                height: 100,
                backgroundColor: 'transparent',
                flex: 1,
                flexDirection: 'row',
            }}>
            <View
            style={{
                height: 100,
                backgroundColor: 'transparent',
                width: this.state.resizeMode === 'stretch' ? '45%' : '37%',
            //marginTop: this.state.resizeMode === 'stretch' ? 50 : -20,
            }}
            >

             <View style={{
                backgroundColor: 'white',
                width: 100,
                borderRadius: 20,
                height: 40,
                marginLeft: 30,
                marginBottom: 140
            }}>
                    <TouchableOpacity onPress={this._handlePress}>  
                        <Text style={styles.player.innertext}> {this.state.showHeartandTime ? 'Hide' : 'Show'} all</Text>
                    </TouchableOpacity>
            </View>            

            </View>


                <View
            style={{
                //height: 100,
                width: this.state.resizeMode === 'stretch' ? '55%' : '68%',
                backgroundColor: 'transparent',
                height: this.state.resizeMode === 'stretch' ? 120 : 130,
                marginTop: this.state.resizeMode === 'stretch' ? -60 : 150,
            }}
            >
            {this.renderLoader()}
          {this.renderPlayPause()}
           </View>


            </View>


            {this.state.showHeartandTime ? this.renderBottomControls() : <Text></Text>}

             </View>

             </View>

       </TouchableWithoutFeedback>
        );
    }
}

/**
 * This object houses our styles. There's player
 * specific styles and control specific ones.
 * And then there's volume/seeker styles.
 */

reactMixin(VideoExcierce.prototype, TimerMixin);



const styles = {
    player: StyleSheet.create({
        container: {
            backgroundColor: '#000',
            flex: 1,
            alignSelf: 'stretch',
            justifyContent: 'space-between'
        },
        subtitle: {
            color: 'white',
            textAlign: 'center',
            textShadowColor: 'black',
            textShadowOffset: {
                width: 1,
                height: 1
            },
            paddingRight: 10,
            paddingLeft: 10
        },
        switchcomponent: {

        },
        innertext: {
            marginTop: 10,
            marginLeft: 17,
            width: '60%',
            textAlign: 'center',
            color: "#ff7200",
            fontWeight: 'bold'
        },
        subtitleContainerPortrait: {
            position: 'absolute',
            top: 200,
            left: 100,
            alignItems: 'center'
        },
        subtitleContainerLandscape: {
            position: 'absolute',
            bottom: 50,
            left: 250
        },
        video: {
            overflow: 'hidden',
            position: 'absolute',
            top: 0,
            right: 0,
            bottom: 0,
            left: 0
        }
    }),
    error: StyleSheet.create({
        container: {
            backgroundColor: 'rgba( 0, 0, 0, 0.5 )',
            position: 'absolute',
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            justifyContent: 'center',
            alignItems: 'center'
        },
        icon: {
            marginBottom: 16
        },
        text: {
            backgroundColor: 'transparent',
            color: '#f27474'
        }
    }),
    loader: StyleSheet.create({
        container: {
            position: 'absolute',
            top: 0,
            right: 0,
            bottom: 0,
            left: 15,
        }
    }),
    controls: StyleSheet.create({
        row: {
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: null,
            width: null
        },
        column: {
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'space-between',
            height: null,
            width: null
        },
        vignette: {
            resizeMode: 'stretch'
        },
        control: {
            padding: 16
        },
        text: {
            backgroundColor: 'transparent',
            color: '#FFF',
            fontSize: 14,
            textAlign: 'center'
        },
        pullRight: {
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center'
        },
        top: {
            flex: 1,
            alignItems: 'stretch',
            justifyContent: 'flex-start'
        },
        bottom: {
            alignItems: 'stretch',
            flex: 2,
            justifyContent: 'flex-end'
        },
        topControlGroup: {
            alignSelf: 'stretch',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexDirection: 'row',
            width: null,
            margin: 12,
            marginBottom: 18
        },
        bottomControlGroup: {
            alignSelf: 'stretch',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginLeft: 12,
            marginRight: 12,
            marginBottom: 0
        },
        volume: {
            flexDirection: 'row'
        },
        fullscreen: {
            flexDirection: 'row'
        },
        playPause: {
            position: 'relative',
            width: 80,
            zIndex: 0
        },
        title: {
            alignItems: 'center',
            flex: 0.6,
            flexDirection: 'column',
            padding: 0
        },
        titleText: {
            textAlign: 'center'
        },
        timer: {
            width: 80
        },
        timerText: {
            backgroundColor: 'transparent',
            color: '#FFF',
            fontSize: 11,
            textAlign: 'right'
        }
    }),
    volume: StyleSheet.create({
        container: {
            alignItems: 'center',
            justifyContent: 'flex-start',
            flexDirection: 'row',
            height: 1,
            marginLeft: 20,
            marginRight: 20,
            width: 150
        },
        track: {
            backgroundColor: '#333',
            height: 1,
            marginLeft: 7
        },
        fill: {
            backgroundColor: '#FFF',
            height: 1
        },
        handle: {
            position: 'absolute',
            marginTop: -24,
            marginLeft: -24,
            padding: 16
        }
    }),
    seekbar: StyleSheet.create({
        container: {
            alignSelf: 'stretch',
            height: 50,
            marginLeft: 20,
            marginRight: 20
        },
        track: {
            backgroundColor: '#333',
            height: 5,
            position: 'relative',
            top: 14,
            width: '100%',
            marginBottom: 10
        },
        fill: {
            backgroundColor: '#ff7200',
            height: 5,
            width: '100%'
        },
        handle: {
            position: 'absolute',
            marginLeft: -7,
            height: 28,
            width: 28
        },
        circle: {
            borderRadius: 16,
            position: 'relative',
            top: 9,
            left: 6,
            height: 16,
            width: 16,
            backgroundColor: '#ff7200'
        }
    })
};