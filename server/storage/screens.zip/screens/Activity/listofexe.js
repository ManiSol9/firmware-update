/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, ActivityIndicator, TouchableHighlight, TouchableOpacity, TextInput } from 'react-native';


import Orientation from 'react-native-orientation';


import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { LineChart, YAxis } from 'react-native-svg-charts'
import { LinearGradient, Stop } from 'react-native-svg'

import * as shape from 'd3-shape'
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { AsyncStorage } from "react-native";


import styles from '../styles.js'

import { request } from 'graphql-request'

import StatusBarBackground from './statusbar.js'


export default class ListofExe extends Component {

    constructor(props) {
        super(props);
        this.state = {
            workoutdata: null,
            user_id: '',
            contentLoader: true,
            exercise_list: [],
            workout_id: null
        }
    }


    async componentWillMount() {
        console.log(this.props.navigation.state.params)
        var {params} = this.props.navigation.state.params;
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        this.setState({
            user_id: USER_ID
        })
        this.getWorkoutDetails(this.props.navigation.state.params.id)
        console.log(this.props.navigation.state.params)
    }


    getWorkoutDetails() {

        /*    

        getWorkoutDetails(workoutID).then(response => {
            console.log(response.data.workout)
            this.setState({
                workoutdata: response.data.workout.id
            });
            this.setState({
                ImageUrl: response.data.workout.thumbnail_url
            });
            this.setState({
                Title: response.data.workout.title
            });
            this.setState({
                Duration: response.data.workout.duration
            });
            this.setState({
                intensity: response.data.workout.intensity
            });
            console.log(response.data.workout.back_thumbnail_url)
        }, err => {
            console.log(err)
        })

        */

        const query = `query{
                          fetch_workout_segment(workout_id:149){
                            workout_id
                            exercise_id
                            rest_time
                            exercise_index
                            
                            completed_workout_segment_details{
                              exercise_index
                              title
                              description
                              start_time
                              end_time
                              streaming_url
                              back_thumbnail_url
                              exercise_id
                            }
                            uncompleted_workout_segment_details{
                              exercise_index
                              title
                              description
                              start_time
                              end_time
                              streaming_url
                              back_thumbnail_url
                              exercise_id
                            }
                          }
                        }`;


        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_segment', query)
            .then(async data => {
                
                console.log(data)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })

                this.setState({exercise_list: data.fetch_workout_segment[0].uncompleted_workout_segment_details})
                this.setState({workout_id: data.fetch_workout_segment[0].workout_id})

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    loader: false,
                    ontentLoader: false
                })
            }
        )


    }


    onPressChevronLeft() {
        const {navigate} = this.props.navigation;
        navigate('WorkoutDetails', {id: 150});
    }

    async nextpage(streaming_url, exercise_id, exercise_index) {

        
        const {navigate} = this.props.navigation;
/*
        

        let USER_ID = await AsyncStorage.getItem("USER_ID");

            const query = `mutation addexercisestatus($exercise_id:Int!, $user_id:Int!, $workout_id: Int!, $course_id:Int!, $exercise_status:Int!, $completion_date: String!, $exercise_index: Int!){

                        addexercisestatus(exercise_id:$exercise_id, user_id:$user_id, workout_id:$workout_id, course_id:$course_id, exercise_status:$exercise_status, completion_date: $completion_date, exercise_index: $exercise_index){
                            status
                            id
                          }

                }`;

            console.log(query)

            const variables = {
                exercise_id: Number(exercise_id),
                user_id: Number(USER_ID),
                workout_id: Number(this.state.workout_id),
                course_id: 20,
                exercise_status: 0,
                completion_date: "",
                exercise_index: exercise_index
            }

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_by_id', query, variables)
                .then(async data => {
                    console.log(data)


                }
            )
                .catch(async err => {
                    console.log(err)
                    alert("Something Went Wrong, Please try again later")
                    this.setState({
                        contentLoader: false
                    })
                }
            )        

        */

        navigate('Videoactivity', {
            streaming_uri: streaming_url + '(format=m3u8-aapl)',
            exerciseID: 139,
            workoutID: 150,
            courseID: 2,
            workout_day: 2,
            user_id: 220,
            workout_title: "sdasdasaaddsd",
        }); 
 
    }


    render() {
        const {navigation} = this.props
        const resizeMode = 'center';
        const text = 'I am some centered text';

        const {contentLoader, exercise_list} = this.state;

        console.log(this.state.exercise_list)


        return (

            <View style={styles.mainBody} >

        <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

          {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
            :
            <View>
                <View style={{ height: 50, backgroundColor: '#ff7200'}}>
                    <Text style={{fontSize: 22, marginTop: 10, color: '#FFF',fontWeight: 'bold', textAlign: 'center'}}> Workout Details</Text>
                    <View style={{marginTop: -30, width: 50,padding: 5}}>
                      <TouchableOpacity onPress={() => this.onPressChevronLeft()}>
                          <FontAwesome name="chevron-left" size={25} color="#FFF"   />
                      </TouchableOpacity>
                    </View>                
                </View>            
                <ScrollView>

              {exercise_list.map(data => {
                    return (
                        <TouchableOpacity onPress={() => this.nextpage(data.streaming_url, data.exercise_id, data.exercise_index)} style={styles.emailItem}>
                            <View style={{flex: 1, flexDirection: 'column', padding: 15, borderBottomWidth: 1, borderColor: '#000'}}>

                              <View>
                                    <Text style={{fontSize: 22, marginTop: 10, color: '#FFF',fontWeight: 'bold', textAlign: 'left'}}>{data.title}</Text>
                              </View>  

                              <View>
                                    <Text style={{fontSize: 16, marginTop: 10, color: '#FFF',fontWeight: 'bold', textAlign: 'left'}}>{data.end_time}</Text>
                              </View>

                            </View>
                        </TouchableOpacity>
                    )
                })}






                </ScrollView>
            </View>

        }


        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress = {() => this.nextpage()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                    

                    <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Complete Workout</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 




            </View>

        );
    }
}
