import React, { Component } from 'react';
import { AppRegistry, TextInput, FlatList, StyleSheet,ScrollView, TouchableWithoutFeedback, Keyboard, StatusBar, PickerIOS, Text, View, DatePickerIOS, TouchableHighlight, Animated , Picker, TouchableOpacity, Image, ToastAndroid } from 'react-native';
import { sendActivitylog } from '../../template/Workout/workout.js'
import DatePicker from 'react-native-datepicker'
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Carousel, { Pagination,ParallaxImage } from 'react-native-snap-carousel';
import { onSignIn, isSignedIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { AsyncStorage } from "react-native";
import { NavigationActions } from 'react-navigation';
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import  Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon from 'react-native-vector-icons/Ionicons';

import Toast, {DURATION} from 'react-native-easy-toast'
import Modal from 'react-native-modal'

import StatusBarBackground from './statusbar.js'

import styles from '../Tabs/style.js'
import { Dropdown } from 'react-native-material-dropdown';


const { width: viewportWidth, height: viewportHeight } = Dimensions.get('window');

function wp (percentage) {
  const value = (percentage * viewportWidth) / 100;
  return Math.round(value);
}

const slideHeight = viewportHeight * 0.4;
const slideWidth = wp(90);
const itemHorizontalMargin = wp(2);
const sliderWidth = viewportWidth;
const itemWidth = slideWidth + itemHorizontalMargin * 2;
export default class LogActivity extends Component {

  constructor(props) {
    super(props);
    this.state={
      workoutdata: "", visibleModal: null, date:"", time:"00:00", sport:"",title:"",user_id:"",calories:"",avg_heart_rate:[],fromScreen:'',isModalVisible: false,minites: "",hours:"",seconds:"",minites:"",year:"",month:"",day:""
    }

  }



  _renderButton = (text, onPress) => (
    <TouchableOpacity onPress={onPress}>
      <View style={{width: 50}}>
        <Text style={{fontSize: 25}}>{text}</Text>
      </View>
    </TouchableOpacity>

  );


  _renderButton1 = (text, onPress) => (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.button}>
        <Text>{text}</Text>
      </View>
    </TouchableOpacity>
  );

  _renderModalContent = () => (
    <View style={styles.modalContent}>
      {this._renderButton("Close", () => this.setState({ visibleModal: null }))}
    </View>
  );


  componentWillMount(){

    var { time , date, heart_rate, avg_heart_rate, fromScreen, calories  } = this.props.navigation.state.params;

    this.state.date = date

    this.state.time = time

    this.state.heartrate = heart_rate

    this.state.avg_heart_rate = avg_heart_rate

    this.state.fromScreen = fromScreen

    this.state.calories = calories

    if(this.state.date != '')
    {

      completed_date = this.state.date
      completed_date = completed_date.split("-");
      this.state.year = completed_date[0]
      this.state.month = completed_date[1]
      this.state.day = completed_date[2]

    }

    if(this.state.time != '')
    {

      completed_time = this.state.time
      completed_time = completed_time.split(":");
      this.state.hours = completed_time[0]
      this.state.minites = completed_time[1]

    }    

    console.log(this.props.navigation.state.params)

  }


  onChangeMin1 = (val) => {

    console.log(minites)
    this.state.minites = val

  }

  onChangeMin = (val) => {
    console.log(this.state.hours)
    if(this.state.hours === '')
    {
      this.refs.toast.show('Activity Details Updated Successfully' , DURATION.LENGTH_LONG);
    }
    else {
      this.state.minites = val
    }
    
  } 

  onChangeHour = (val) => {
    console.log(val)
    this.state.hours = val
  }

  onChangeYear = (val) => {

    this.setState({year: val})

  }


  onChangeMonth = (val) => {

    this.setState({month: val})

  }

  onChangeDay = (val) => {

    this.setState({day: val})

  }

  onChangeSport = (val) => {

    Keyboard.dismiss()

    this.setState({sport: val})

  }  

  async nextpage() {

    const { navigate  } = this.props.navigation;
    const { title, sport, time, date, user_id, calories, avg_heart_rate, fromScreen, minites, hours, year, month, day } = this.state;

    if(minites != '' && hours !='')
    {
      this.setState({time: hours+':'+minites})
    }

    let USER_ID = await AsyncStorage.getItem("USER_ID");

    console.log(this.state)

    if(title != ''&sport!=''&&time!=''&&time!='00:00'&date!='')
    {

    todaydate = new Date().toISOString();

    var temp={};
    temp.title=title;
    temp.activity_type=sport;
    temp.workout_id="0";
    temp.course_id="0";
    temp.user_id=USER_ID;
    temp.exercise_id="0";
    temp.completed_at=date;
    temp.completed_on=todaydate;
    temp.distance=0;
    temp.duration=time;
    this.setState({loader:true})

    console.log(time)

    this.refs.toast.show('Activity Details Updated Successfully' , DURATION.LENGTH_LONG);

    sendActivitylog(title, '0', sport, date, todaydate, USER_ID, avg_heart_rate).then(response=>{
        console.log(response);

        const { navigate  } = this.props.navigation;

        if(fromScreen == 'Trackactivity')
        {
          navigate("TrackActivitySummary", { calories:calories, time: time, avg_heart_rate: avg_heart_rate, workout_title: title});
        }else {
          navigate("FinishExcierce");
        }


      },error=>{
        console.log(error);
      })    

  }
  else
  {
    this.refs.toast.show('Please Fill all the fields...' , DURATION.LENGTH_LONG);
    console.log('Mani')
    console.log(this.state)
  }

}

   updateHour = (hour) => {
      this.setState({ hours: hour })
      alert('hi')
      this.state.hours = hour
      console.log(this.state.hours)
   }

   updateMinites = (minites) => {
      this.setState({ minites: minites })
   }

   updateSeconds = (seconds) => {
      this.setState({ seconds: seconds })
   }   


_toggleModal = () => this.setState({ isModalVisible: !this.state.isModalVisible })

render() {

    let data = [{
      value: 'CrossFit',
    }, {
      value: 'Running',
    }, {
      value: 'Weights',
    },{
      value: 'Cycling',
    },{
      value: 'Yoga',
    },{
      value: 'Swmming'
    },{
      value: 'Aerobics'
    },{
      value: 'Football'
    }];

    let year = [{value: 2000},{value: 2001},{value: 2002},{value: 2003},{value: 2004},{value: 2005},{value: 2006},{value: 2007},{value: 2008},{value: 2009},{value: 2010},{value: 2011},{value: 2012},{value: 2013},{value: 2014},{value: 2015},{value: 2016},{value: 2017},{value: 2018},{value: 2019},{value: 2020},{value: 2021},{value: 2022},{value: 2023}]
    let month = [{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12}]
    let day = [{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24},{value: 25},{value: 26},{value: 27},{value: 28},{value: 29},{value: 30},{value: 31}]
    let min= [{value: ''},{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24},{value: 25},{value: 26},{value: 27},{value: 28},{value: 29},{value: 30},{value: 31}, {value: '32'},{value: '33'},{value: '34'},{value: '35'},{value: '36'},{value: '37'},{value: '38'},{value: '39'},{value: '40'},{value: '41'},{value: 42},{value: 43},{value: 44},{value: 45},{value: 46},{value: 47},{value: 48},{value: 49},{value: 50},{value: 51},{value: 52},{value: 53},{value: 54},{value: 55},{value: 56},{value: 57},{value: 58},{value: 59},{value: 60}]
    let hours_data = [{value: ''},{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24}]


    if(this.state.seconds == '')
    {
      this.setState({seconds: '00'})
    }

    let time = this.state.hours+':'+this.state.minites

  return (
      <View style={styles.mainBody} >
        <StatusBarBackground style={{backgroundColor:'#FF7E00'}}/>

              <View style={styles.listofWrkouts1}>
                <View style={styles.chevron_left_icon}>
                  <TouchableOpacity onPress={()=>{
          const { navigate } = this.props.navigation;
          navigate('UpcomingWorkouts')}}>
                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                  </TouchableOpacity>
                </View>

                <View style={styles.header}>
                      <Text style={styles.topSignupTxt}>
                        Activity
                      </Text>
                </View>

                <View>
                  <Text style = {styles.text_workout_heading}>
                    Log your activity
                  </Text>
                  <Text style = {styles.text_workout_sub_heading}>
                    ADO YOUR SPORT. TIME & RATE TO TRACK YOUR RESULTS
                  </Text>
                </View>


              </View>

        <ScrollView
              style={{flex:1}}
              contentContainerStyle={{paddingBottom: 50}}
              indicatorStyle={'white'}
              scrollEventThrottle={200}
              directionalLockEnabled={true}
            >

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Title :</Text>
                <View style={styles.log_act1}>

                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                <TextInput
                  placeholder="Title"
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  value={String(this.state.title)}
                  placeholderTextColor='#626264'
                  style={styles.textInput_signup}

                  onChangeText={ (text) => this.setState({title:text, enable:true}) }
                />
                </TouchableWithoutFeedback>

                </View>
              </View>

              

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Activity type :</Text>
                <View style={styles.log_act1}>


                    <Dropdown
                      label='Select Activity type'
                      data={data}
                      value={this.state.sport}
                      textColor='white'
                      selectedItemColor='black'
                      onChangeText={this.onChangeSport}
                    />

                </View>


              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Calories :</Text>
                <View style={styles.log_act1}>
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>

                <TextInput
                  placeholder="Calories"
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  keyboardType='numeric'
                  value={String(this.state.calories)}
                  placeholderTextColor='#626264'
                  style={styles.textInput_signup}
                  onChangeText={ (text) => this.setState({calories:text, enable:true}) }
                  onBlur={this.blurevent}
                />

                </TouchableWithoutFeedback>

                </View>
              </View>


              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Completed Date :</Text>
                <View style={styles.log_act1}>
        
                    <Text style={{paddingBottom: 4}}></Text>

                     <DatePicker
                      style={styles.textInput_signup}
                      date={this.state.date}
                      mode="date"
                      placeholder="select date"
                      format="YYYY-MM-DD"
                      confirmBtnText="Confirm"
                      cancelBtnText="Cancel"
                      showIcon="false"
                      customStyles={{
                        dateIcon: {
                          position: 'absolute',
                          left: 0,
                          top: 14,
                          marginLeft: 0,
                        },
                        dateInput: {
                          marginLeft: -150,

                        }
                        // ... You can check the source to find the other keys.
                      }}
                      onDateChange={(date) => {this.setState({date: date})}}
                    />

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Time :</Text>
                <View style={styles.log_act1}>
                     

                        <View style={{ flexDirection: 'row', marginBottom: 0 }}>
                          <View style={{ flex: 1 }}>



                            <TextInput
                              placeholder="Title"
                              underlineColorAndroid='transparent'
                              autoCorrect={false}
                              editable={false}
                              value={time}
                              placeholderTextColor='#626264'
                              style={styles.textInput_signup}
                              
                            />

                          </View>

                          <View style={{ width: 56, marginLeft: 8 }}>

                            {this._renderButton(<Icon name="ios-alarm" color="#FF7E00" size={35}  />, () =>
                              this.setState({ visibleModal: 5 })
                            )} 

                          </View>   
                        </View>

                    <Modal
                      isVisible={this.state.visibleModal === 5}
                      style={styles.bottomModal}
                    >
                      <View style={styles.modalContent}>
                        <View style={{ flexDirection: 'row', marginBottom: 0 }}>
                          <View style={{ flex: 1 }}>
                            <Picker selectedValue = {this.state.hours} onValueChange = {(itemValue, itemIndex) => this.setState({hours: itemValue})}>
                               <Picker.Item label = "" value = "Select Hours" />
                               <Picker.Item label = "00" value = "00" />
                               <Picker.Item label = "01" value = "01" />
                               <Picker.Item label = "02" value = "02" />
                               <Picker.Item label = "03" value = "03" />
                               <Picker.Item label = "04" value = "04" />
                               <Picker.Item label = "05" value = "05" />
                               <Picker.Item label = "06" value = "06" />
                               <Picker.Item label = "07" value = "07" />
                               <Picker.Item label = "08" value = "08" />
                               <Picker.Item label = "09" value = "09" />
                               <Picker.Item label = "10" value = "10" />
                               <Picker.Item label = "11" value = "11" />
                               <Picker.Item label = "12" value = "12" />
                               <Picker.Item label = "13" value = "13" />
                               <Picker.Item label = "14" value = "14" />
                               <Picker.Item label = "15" value = "15" />
                               <Picker.Item label = "16" value = "16" />
                               <Picker.Item label = "17" value = "17" />
                               <Picker.Item label = "18" value = "18" />
                               <Picker.Item label = "19" value = "19" />
                               <Picker.Item label = "20" value = "20" />
                               <Picker.Item label = "21" value = "21" />
                               <Picker.Item label = "22" value = "22" />
                               <Picker.Item label = "23" value = "23" />
                               <Picker.Item label = "24" value = "24" />
                            </Picker>
                          </View>

                          <View style={{ width: 156, marginLeft: 8 }}>
                            <Picker selectedValue = {this.state.minites} onValueChange = {(itemValue, itemIndex) => this.setState({minites: itemValue})}>
                               <Picker.Item label = "" value = "Minites" />
                               <Picker.Item label = "00" value = "00" />
                               <Picker.Item label = "01" value = "01" />
                               <Picker.Item label = "02" value = "02" />
                               <Picker.Item label = "03" value = "03" />
                               <Picker.Item label = "04" value = "04" />
                               <Picker.Item label = "05" value = "05" />
                               <Picker.Item label = "06" value = "06" />
                               <Picker.Item label = "07" value = "07" />
                               <Picker.Item label = "08" value = "08" />
                               <Picker.Item label = "09" value = "09" />
                               <Picker.Item label = "10" value = "10" />
                               <Picker.Item label = "11" value = "11" />
                               <Picker.Item label = "12" value = "12" />
                               <Picker.Item label = "13" value = "13" />
                               <Picker.Item label = "14" value = "14" />
                               <Picker.Item label = "15" value = "15" />
                               <Picker.Item label = "16" value = "16" />
                               <Picker.Item label = "17" value = "17" />
                               <Picker.Item label = "18" value = "18" />
                               <Picker.Item label = "19" value = "19" />
                               <Picker.Item label = "20" value = "20" />
                               <Picker.Item label = "21" value = "21" />
                               <Picker.Item label = "22" value = "22" />
                               <Picker.Item label = "23" value = "23" />
                               <Picker.Item label = "24" value = "24" />
                               <Picker.Item label = "25" value = "25" />                               
                               <Picker.Item label = "26" value = "26" />
                               <Picker.Item label = "27" value = "27" />
                               <Picker.Item label = "28" value = "28" />
                               <Picker.Item label = "29" value = "29" />
                               <Picker.Item label = "30" value = "30" />
                               <Picker.Item label = "31" value = "31" />
                               <Picker.Item label = "32" value = "32" />
                               <Picker.Item label = "33" value = "33" />
                               <Picker.Item label = "34" value = "34" />
                               <Picker.Item label = "35" value = "35" />
                               <Picker.Item label = "36" value = "36" />
                               <Picker.Item label = "37" value = "37" />
                               <Picker.Item label = "38" value = "38" />
                               <Picker.Item label = "39" value = "39" />
                               <Picker.Item label = "40" value = "40" />
                               <Picker.Item label = "41" value = "41" />
                               <Picker.Item label = "42" value = "42" />
                               <Picker.Item label = "43" value = "43" />
                               <Picker.Item label = "44" value = "44" />
                               <Picker.Item label = "45" value = "45" />
                               <Picker.Item label = "46" value = "46" />
                               <Picker.Item label = "47" value = "47" />
                               <Picker.Item label = "48" value = "48" />
                               <Picker.Item label = "49" value = "59" />
                               <Picker.Item label = "50" value = "50" />
                               <Picker.Item label = "51" value = "51" />
                               <Picker.Item label = "52" value = "52" />
                               <Picker.Item label = "53" value = "53" />
                               <Picker.Item label = "54" value = "54" />
                               <Picker.Item label = "55" value = "55" />
                               <Picker.Item label = "56" value = "56" />
                               <Picker.Item label = "57" value = "57" />
                               <Picker.Item label = "58" value = "58" />
                               <Picker.Item label = "59" value = "59" />
                               <Picker.Item label = "60" value = "60" />                                                             
                            </Picker>
                          </View>   
                        </View>
                        {this._renderButton1("Close", () => this.setState({ visibleModal: null }))}
                      </View>


                    </Modal>


                </View>

              </View>              

            </ScrollView>


        <View style={{bottom:0,position:'absolute',alignItems:'center',justifyContent:'center'}}>
            <TouchableOpacity onPress = {()=>this.nextpage()}>
                <View style={{zIndex:999,alignItems:'center',justifyContent:'center',height:50,width:width}}>
                    

                    <Text style={{backgroundColor:'transparent',alignSelf:'center',fontFamily:'CircularStd-Black',color:'#fff',fontSize:19}}>Complete Workout</Text>
          
                </View>
                <Image style={{width:width,height:50,position:'absolute',bottom:0}} source={{ uri: 'btn_gradi_bg' }}/>
            </TouchableOpacity>
        </View> 

                <Toast
                    ref="toast"
                    style={{backgroundColor:'#000',bottom:0}}
                    position='top'
                    positionValue={200}
                    fadeInDuration={750}
                    fadeOutDuration={1000}
                    opacity={0.8}
                    textStyle={{color:'white'}}
                /> 

              
            </View>



    );
}
}
