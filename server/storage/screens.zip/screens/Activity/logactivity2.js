import React, { Component } from 'react';
import { AppRegistry, TextInput, FlatList, StyleSheet,ScrollView, PickerIOS, Text, View, DatePickerIOS, TouchableHighlight, Animated , Picker, TouchableOpacity, Image, ToastAndroid } from 'react-native';
import { sendActivitylog } from '../../template/Workout/workout.js'
import DatePicker from 'react-native-datepicker'
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Carousel, { Pagination,ParallaxImage } from 'react-native-snap-carousel';
import { onSignIn, isSignedIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { AsyncStorage } from "react-native";
import { NavigationActions } from 'react-navigation';
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import  Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'

import Toast, {DURATION} from 'react-native-easy-toast'
import Modal from 'react-native-modal'


import styles from '../Tabs/style.js'
import { Dropdown } from 'react-native-material-dropdown';


const { width: viewportWidth, height: viewportHeight } = Dimensions.get('window');

function wp (percentage) {
  const value = (percentage * viewportWidth) / 100;
  return Math.round(value);
}

const slideHeight = viewportHeight * 0.4;
const slideWidth = wp(90);
const itemHorizontalMargin = wp(2);
const sliderWidth = viewportWidth;
const itemWidth = slideWidth + itemHorizontalMargin * 2;
export default class LogActivity extends Component {

  constructor(props) {
    super(props);
    this.state={
      workoutdata: "", visibleModal: null, date:"", time:"00:00", sport:"",title:"",user_id:"",heartrate:"",avg_heart_rate:[],fromScreen:'',isModalVisible: false,minites: "",hours:"",minites:"",year:"",month:"",day:""
    }


    this._hours = [];
    this._minutes = [];

    for (let j = 0; j < 24 * (this.props.loop ? 100 : 1); j++) {
      this._hours.push(j);
    }

    for (let j = 0; j < 60 * (this.props.loop ? 100 : 1); j += this._getInterval(this.props.minuteInterval || 1)) {
      this._minutes.push(j);
    }

    this.state = {
      selectedHour: this._getHourIndex(this.props.selectedHour || 0),
      selectedMinute: this._getMinuteIndex(this.props.selectedMinute || 0, this.props.minuteInterval || 1)
    }    

  }



  _renderButton = (text, onPress) => (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.button}>
        <Text>{text}</Text>
      </View>
    </TouchableOpacity>
  );

  _renderModalContent = () => (
    <View style={styles.modalContent}>

      {this._renderButton("Close", () => this.setState({ visibleModal: null }))}
    </View>
  );


  componentWillMount(){

    var { time , date, heart_rate, avg_heart_rate, fromScreen, calories  } = this.props.navigation.state.params;

    this.state.date = date

    this.state.time = time

    this.state.heartrate = heart_rate

    this.state.avg_heart_rate = avg_heart_rate

    this.state.fromScreen = fromScreen

    this.state.calories = calories

    if(this.state.date != '')
    {

      completed_date = this.state.date
      completed_date = completed_date.split("-");
      this.state.year = completed_date[0]
      this.state.month = completed_date[1]
      this.state.day = completed_date[2]

    }

    if(this.state.time != '')
    {

      completed_time = this.state.time
      completed_time = completed_time.split(":");
      this.state.hours = completed_time[0]
      this.state.minites = completed_time[1]

    }    

    console.log(this.props.navigation.state.params)

  }


  onChangeMin1 = (val) => {

    console.log(minites)
    this.state.minites = val

  }

  onChangeMin = (val) => {
    console.log(this.state.hours)
    if(this.state.hours === '')
    {
      this.refs.toast.show('Select Hours First' , DURATION.LENGTH_LONG);
    }
    else {
      this.state.minites = val
    }
    
  } 

  onChangeHour = (val) => {
    console.log(val)
    this.state.hours = val
  }

  onChangeYear = (val) => {

    this.setState({year: val})

  }

  onChangeMonth = (val) => {

    this.setState({month: val})

  }

  onChangeDay = (val) => {

    this.setState({day: val})

  }

  onChangeSport = (val) => {

    this.setState({sport: val})

  }  

  async nextpage() {

    const { navigate  } = this.props.navigation;
    const { title, sport, time, date, user_id, calories, avg_heart_rate, fromScreen, minites, hours, year, month, day } = this.state;

    if(minites != '' && hours !='')
    {
      this.setState({time: hours+':'+minites})
    }

    if(year != '' && day !='' && month !='')
    {
      let completed_Date = year+'-'+month+'-'+day
      this.setState({date: completed_Date})
    }


    let USER_ID = await AsyncStorage.getItem("USER_ID");

    console.log(this.state)

    if(title != ''&sport!=''&&time!=''&date!='')
    {
    console.log(this.state)

    todaydate = new Date().toISOString();

    var temp={};
    temp.title=title;
    temp.activity_type=sport;
    temp.workout_id="0";
    temp.course_id="0";
    temp.user_id=USER_ID;
    temp.exercise_id="0";
    temp.completed_at=date;
    temp.completed_on=todaydate;
    temp.distance=0;
    temp.duration=time;
    this.setState({loader:true})

    console.log(time)

    this.refs.toast.show('Activity Details Updated Successfully' , DURATION.LENGTH_LONG);

    sendActivitylog(title, '0', sport, date, todaydate, USER_ID, avg_heart_rate).then(response=>{
        console.log(response);

        const { navigate  } = this.props.navigation;

        if(fromScreen == 'Trackactivity')
        {
          navigate("TrackActivitySummary", { calories:calories, time: time, avg_heart_rate: avg_heart_rate, workout_title: title});
        }else {
          navigate("FinishExcierce");
        }


      },error=>{
        console.log(error);
      })

  }
  else
  {
    this.refs.toast.show('Please Fill all the fields...' , DURATION.LENGTH_LONG);
  }

}

  _getInterval = (interval) => {
    let matched = false;
    
    for (let i of [1, 2, 3, 4, 5, 6, 10, 12, 15, 20, 30]) {
      if (i === interval) {
        return interval;
      }
    }

    if (!matched) {
      return 1;
    }
  };

  _getHourIndex = (h) => {
    return (this.props.loop ? (this._hours.length / 2) : 0) + h;
  };

  _getMinuteIndex = (m, interval) => {
    return (this.props.loop ? (this._minutes.length / 2 * this._getInterval(interval)) : 0) + (m % this._getInterval(interval) === 0 ? m : 0);
  };

  _getHourValue = (h) => {
    return h % 24;
  };

  _getMinuteValue = (m) => {
    return m % 60;
  };

  _onValueChangeCallback = (newHour, newMin) => {
    if ('onValueChange' in this.props) {
      this.props.onValueChange(
        this._getHourValue((newHour !== null) ? newHour : this.state.selectedHour),
        this._getMinuteValue((newMin !== null) ? newMin : this.state.selectedMinute)
      );
    }
  };

  _setHour = (hour) => {
    this.setState({
      selectedHour: hour
    });

    this._onValueChangeCallback(hour, null);
  };

  _setMinute = (minute) => {
    this.setState({
      selectedMinute: minute
    });

    this._onValueChangeCallback(null, minute);
  };





_toggleModal = () => this.setState({ isModalVisible: !this.state.isModalVisible })

render() {

    let data = [{
      value: 'CrossFit',
    }, {
      value: 'Running',
    }, {
      value: 'Weights',
    },{
      value: 'Cycling',
    },{
      value: 'Yoga',
    },{
      value: 'Swmming'
    },{
      value: 'Aerobics'
    },{
      value: 'Football'
    }];

    let year = [{value: 2000},{value: 2001},{value: 2002},{value: 2003},{value: 2004},{value: 2005},{value: 2006},{value: 2007},{value: 2008},{value: 2009},{value: 2010},{value: 2011},{value: 2012},{value: 2013},{value: 2014},{value: 2015},{value: 2016},{value: 2017},{value: 2018},{value: 2019},{value: 2020},{value: 2021},{value: 2022},{value: 2023}]
    let month = [{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12}]
    let day = [{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24},{value: 25},{value: 26},{value: 27},{value: 28},{value: 29},{value: 30},{value: 31}]
    let min= [{value: ''},{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24},{value: 25},{value: 26},{value: 27},{value: 28},{value: 29},{value: 30},{value: 31}, {value: '32'},{value: '33'},{value: '34'},{value: '35'},{value: '36'},{value: '37'},{value: '38'},{value: '39'},{value: '40'},{value: '41'},{value: 42},{value: 43},{value: 44},{value: 45},{value: 46},{value: 47},{value: 48},{value: 49},{value: 50},{value: 51},{value: 52},{value: 53},{value: 54},{value: 55},{value: 56},{value: 57},{value: 58},{value: 59},{value: 60}]
    let hours_data = [{value: ''},{value: '00'},{value: '01'},{value: '02'},{value: '03'},{value: '04'},{value: '05'},{value: '06'},{value: '07'},{value: '08'},{value: '09'},{value: 10},{value: 11},{value: 12},{value: 13},{value: 14},{value: 15},{value: 16},{value: 17},{value: 18},{value: 19},{value: 20},{value: 21},{value: 22},{value: 23},{value: 24}]


  return (
      <View style={styles.mainBody} >
        <ScrollView
              style={{flex:1}}
              contentContainerStyle={{paddingBottom: 50}}
              indicatorStyle={'white'}
              scrollEventThrottle={200}
              directionalLockEnabled={true}
            >
              <View style={styles.listofWrkouts1}>
                <View style={styles.chevron_left_icon}>
                  <TouchableOpacity onPress={()=>{
          const { navigate } = this.props.navigation;
          navigate('UpcomingWorkouts')}}>
                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                  </TouchableOpacity>
                </View>

                <View style={styles.header}>
                      <Text style={styles.topSignupTxt}>
                        Activity
                      </Text>
                </View>

                <View>
                  <Text style = {styles.text_workout_heading}>
                    Log your activity
                  </Text>
                  <Text style = {styles.text_workout_sub_heading}>
                    ADO YOUR SPORT. TIME & RATE TO TRACK YOUR RESULTS
                  </Text>
                </View>


              </View>
              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Title :</Text>
                <View style={styles.log_act1}>

                <TextInput
                  placeholder="Title"
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  value={String(this.state.title)}
                  placeholderTextColor='#626264'
                  style={styles.textInput_signup}
                  onChangeText={ (text) => this.setState({title:text, enable:true}) }
                />

                </View>
              </View>
              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Calories :</Text>
                <View style={styles.log_act1}>

                <TextInput
                  placeholder="Calories"
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  value={String(this.state.heartrate)}
                  placeholderTextColor='#626264'
                  style={styles.textInput_signup}
                  onChangeText={ (text) => this.setState({heartrate:text, enable:true}) }
                />

                </View>
              </View>
              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Activity type :</Text>
                <View style={styles.log_act1}>

                    <Dropdown
                      label='Select Activity type'
                      data={data}
                      value={this.state.sport}
                      textColor='white'
                      selectedItemColor='black'
                      onChangeText={this.onChangeSport}                     
                    />

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>COMPLETED DATE :</Text>
                <View style={styles.log_act1}>

                  <View style={{ flexDirection: 'row' }}>
                    <View style={{ flex: 1 }}>
                      <Dropdown
                            label='00'
                            data={day}
                            value={this.state.day}
                            textColor='white'
                            selectedItemColor='black'                            
                            onChangeText={this.onChangeDay}
                      />
                    </View>

                    <View style={{ width: 96, marginLeft: 8 }}>
                      <Dropdown
                            label='00'
                            data={month}
                            value={this.state.month}
                            onChangeText={this.onChangeMonth} 
                            textColor='white'
                            selectedItemColor='black'                                                       
                      />
                    </View>
                    <View style={{ width: 136, marginLeft: 8 }}>
                      <Dropdown
                            label='00'
                            data={year}
                            value={this.state.year}
                            onChangeText={this.onChangeYear} 
                            textColor='white'
                            selectedItemColor='black'                                                       
                      />
                    </View>              
                  </View> 

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>TIME :</Text>
                <View>

                      <View style={styles.modalContent1}>
                              <View style={{ flexDirection: 'row', marginBottom: 80 }}>
                                <View style={{ flex: 1 }}>
                                  <Dropdown
                                        label='hours'
                                        data={hours_data}
                                        value={this.state.hours}
                                        onChangeText={this.onChangeHour}
                                        textColor='black'
                                        selectedItemColor='black' 
                                                                 
                                  />
                                </View>

                                <View style={{ width: 96, marginLeft: 8 }}>
                                  <Dropdown
                                        label='Minites'
                                        data={min}
                                        value={this.state.minites}
                                        onChangeText={this.onChangeMin}
                                        textColor='black'
                                        selectedItemColor='black'                            
                                  />
                                </View>   


                                <View style={{ width: 106, marginLeft: 8 }}>
                                  <Dropdown
                                        label='Seconds'
                                        data={min}
                                        value={this.state.minites}
                                        onChangeText={this.onChangeMin}
                                        textColor='black'
                                        selectedItemColor='black'                            
                                  />
                                </View> 

                              </View>
                          </View>                       

                </View>

              </View>              

        <DatePicker
          style={{width: 200}}
          date={this.state.time}
          mode="time"
          format="HH:mm"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          minuteInterval={10}
          onDateChange={(time) => {this.setState({time: time});}}
        />
        <Text style={styles.instructions}>time: {this.state.time}</Text>

            </ScrollView>


        <View style={{bottom:0,position:'absolute',alignItems:'center',justifyContent:'center'}}>
            <TouchableOpacity onPress = {()=>this.nextpage()}>
                <View style={{zIndex:999,alignItems:'center',justifyContent:'center',height:50,width:width}}>
                    

                    <Text style={{backgroundColor:'transparent',alignSelf:'center',fontFamily:'CircularStd-Black',color:'#fff',fontSize:19}}>Complete Workout</Text>
          
                </View>
                <Image style={{width:width,height:50,position:'absolute',bottom:0}} source={{ uri: 'btn_gradi_bg' }}/>
            </TouchableOpacity>
        </View> 

                <Toast
                    ref="toast"
                    style={{backgroundColor:'#000',bottom:0}}
                    position='top'
                    positionValue={200}
                    fadeInDuration={750}
                    fadeOutDuration={1000}
                    opacity={0.8}
                    textStyle={{color:'white'}}
                /> 

              
            </View>



    );
}
}
