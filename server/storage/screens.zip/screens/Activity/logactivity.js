import React, { Component } from 'react';
import { AppRegistry, TextInput, FlatList, StyleSheet, ScrollView, TouchableWithoutFeedback, Keyboard, ActivityIndicator, StatusBar, PickerIOS, Text, View, DatePickerIOS, TouchableHighlight, Animated, Picker, TouchableOpacity, Image, ToastAndroid } from 'react-native';
import { sendActivitylog } from '../../template/Workout/workout.js'
import DatePicker from 'react-native-datepicker'
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Carousel, { Pagination, ParallaxImage } from 'react-native-snap-carousel';
import { onSignIn, isSignedIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { AsyncStorage } from "react-native";
import { NavigationActions } from 'react-navigation';
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon from 'react-native-vector-icons/Ionicons';
import moment from "moment";
import PhotoUpload from 'react-native-photo-upload'
import ImageResizer from 'react-native-image-resizer';
import axios from 'axios';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import Modal from 'react-native-modal'

import StatusBarBackground from './statusbar.js'

import styles from '../Tabs/style.js'
import { Dropdown } from 'react-native-material-dropdown';


const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

function wp(percentage) {
    const value = (percentage * viewportWidth) / 100;
    return Math.round(value);
}

import Orientation from 'react-native-orientation';

import { request } from 'graphql-request'

const slideHeight = viewportHeight * 0.4;
const slideWidth = wp(90);
const itemHorizontalMargin = wp(2);
const sliderWidth = viewportWidth;
const itemWidth = slideWidth + itemHorizontalMargin * 2;
export default class LogActivity extends Component {

  static navigatorStyle = {
    drawUnderNavBar: true,
    navBarTranslucent: true,
    orientation: 'landscape'
  };

    constructor(props) {
        super(props);
        this.state = {
            workoutdata: "",
            visibleModal: null,
            date: new Date(),
            time: "00:00",
            completedtime: "",
            sport: "",
            title: "",
            user_id: "",
            calories: "",
            avg_heart_rate: [],
            fromScreen: '',
            isModalVisible: false,
            minites: "",
            hours: "",
            seconds: "",
            minites: "",
            year: "",
            month: "",
            day: "",
            contentLoader: false,
            visible: true,
            profile_img_url: null,
            upload_uri: "https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg",
            upload_uri_check: false,
            visible: true,
            upload_text: "Add Image"            
        }

    }



    _renderButton = (text, onPress) => (
        <TouchableOpacity onPress={onPress}>
      <View style={{
            width: 50
        }}>
        <Text style={{
            fontSize: 25
        }}>{text}</Text>
      </View>
    </TouchableOpacity>

    );


    _renderButton1 = (text, onPress) => (
        <TouchableOpacity onPress={onPress}>
      <View style={styles.button}>
        <Text>{text}</Text>
      </View>
    </TouchableOpacity>
    );

    _renderModalContent = () => (
        <View style={styles.modalContent}>
      {this._renderButton("Close", () => this.setState({
            visibleModal: null
        }))}
    </View>
    );


    componentWillMount() {

        console.log(this.state.avg_heart_rate,"jjhjjh")

        var {time, date, heart_rate, avg_heart_rate, fromScreen, calories} = this.props.navigation.state.params;

        console.log(this.props.navigation.state.params)   

        if (date != '') {

            activity_date = moment(date, "YYYY-MM-DD").format('dddd Do, MMMM YYYY');

            console.log(activity_date)

            workout_time = new Date();

            work_hour = workout_time.getHours();

            work_min = workout_time.getMinutes();

            this.state.completedtime = work_hour + ':' + work_min

            this.state.date = activity_date

        } else {
            workout_time = new Date();

            work_hour = workout_time.getHours();

            work_min = workout_time.getMinutes();

            this.state.completedtime = work_hour + ':' + work_min

            activity_date = moment(this.state.date, "YYYY-MM-DD").format('dddd Do, MMMM YYYY');

            this.state.date = activity_date
        }


        this.state.time = time

        this.state.heartrate = heart_rate

        if(avg_heart_rate != ''){

            this.state.avg_heart_rate = avg_heart_rate

        }

        this.state.fromScreen = fromScreen

        this.state.calories = calories

        if (this.state.time != '') {

            completed_time = this.state.time
            completed_time = completed_time.split(":");
            this.state.hours = completed_time[0]
            this.state.minites = completed_time[1]
            this.state.seconds = completed_time[2]
        }

        console.log(this.props.navigation.state.params)


    const initial = Orientation.getInitialOrientation();
    if (initial === 'PORTRAIT') {
      Orientation.lockToPortrait();
    } else {
      Orientation.lockToPortrait();
    }


    console.log(this.state.avg_heart_rate,"jjhjjh")

    }

      componentDidMount() {
        // this locks the view to Portrait Mode
        Orientation.lockToPortrait();
     
        // this locks the view to Landscape Mode
        // Orientation.lockToLandscape();
     
        // this unlocks any previous locks to all Orientations
        // Orientation.unlockAllOrientations();
     
        Orientation.addOrientationListener(this._orientationDidChange);
      }
     
      _orientationDidChange = (orientation) => {
        if (orientation === 'LANDSCAPE') {
          // do something with landscape layout
          //alert("ASddadsa")
          Orientation.lockToPortrait();
        } else {
          Orientation.lockToPortrait();
        }
      }
 

    onChangeMin1 = (val) => {

        console.log(minites)
        this.state.minites = val

    }

    onChangeMin = (val) => {
        console.log(this.state.hours)
        if (this.state.hours === '') {
            this.refs.toast.show('Activity Details Updated Successfully', DURATION.LENGTH_LONG);
        } else {
            this.state.minites = val
        }

    }

    onChangeHour = (val) => {
        console.log(val)
        this.state.hours = val
    }

    onChangeYear = (val) => {

        this.setState({
            year: val
        })

    }


    onChangeMonth = (val) => {

        this.setState({
            month: val
        })

    }

    onChangeDay = (val) => {

        this.setState({
            day: val
        })

    }

    onChangeSport = (val) => {

        Keyboard.dismiss()

        this.setState({
            sport: val
        })

    }

    async nextpage() {

        //this.state.contentLoader = false

        

        const {navigate} = this.props.navigation;
        const {title, sport, time, date, user_id, calories, avg_heart_rate, fromScreen, minites, hours, year, month, day, completedtime} = this.state;

        if (minites != '' && hours != '') {
            this.setState({
                time: hours + ':' + minites
            })
        }

        let USER_ID = await AsyncStorage.getItem("USER_ID");

        console.log(this.state, String(time))

        if(title == '') {

            alert("Please enter workout title")

        } else if(sport == ''){

            alert("Please enter sport")
 
        } else if(calories == '') {

            alert("Please enter Calories")

        } else if(date == '') {

            alert("Please enter date")

        } else if(completedtime == '') {

            alert("Please completed time")

        } else if(time == '') {

            alert("Please enter time")

        } else if(String(this.state.time) == '00:00') {

            console.log(this.state)

            alert("Please enter time 00:00")

        } else {

            this.setState({contentLoader: true})

            months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

            completed_dateandtime = String(this.state.date)

            completed_date = completed_dateandtime.split(' ')

            console.log(completed_date)

            for (var i = 0; i < months.length; i++) {
                if (completed_date[2] == months[i]) {
                    completed_month = i + 1
                }
            }


            completed_year = completed_date[3]
            completed_day = completed_date[1].slice(0, -3)            

            workout_date = completed_month + '/' + completed_day + '/' + completed_year + ' ' + completedtime

            console.log(workout_date)

            workout_data_time = new Date(workout_date).toISOString();

            todaydate = new Date().toISOString();

            console.log(this.state.avg_heart_rate, "Sdasdadadas")


            const query = `mutation 

                            addactivity(
                                
                                $user_id:Int!, 
                                $title:String!, 
                                $workout_type: String!, 
                                $date_completed: String!, 
                                $date_created: String!, 
                                $calories: Int!, 
                                $duration: String!, 
                                $max_heart_rate: Int!,
                                $activity_image_url: String!,
                                $heart_rates: [Int]!
                                $rating: Int!
                            ){

                                addactivity(
                                    user_id: $user_id, 
                                    title: $title, 
                                    workout_type: $workout_type, 
                                    date_completed: $date_completed, 
                                    date_created: $date_created, 
                                    calories: $calories, 
                                    duration: $duration, 
                                    max_heart_rate: $max_heart_rate,
                                    activity_image_url:$activity_image_url,
                                    heart_rates: $heart_rates,
                                    rating: $rating

                                ) {

                                    id,
                                    status

                            }

                        }`;


            const variables = {
                title: title,
                user_id: Number(USER_ID),
                date_completed: workout_data_time,
                date_created: todaydate,
                workout_type: sport,
                max_heart_rate: 0,
                duration: this.state.time,
                calories: calories,
                activity_image_url: String(this.state.upload_uri),
                heart_rates: avg_heart_rate,
                rating: 0
            }

            console.log(variables)

            request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_activity', query, variables)
                .then(async data => {
                    console.log(data)

                    console.log(data.addactivity[0].status)

                    if(String(data.addactivity[0].status) == "success"){

                            const { navigate  } = this.props.navigation;

                            if(fromScreen == 'Trackactivity')
                            {
                              navigate("TrackActivitySummary", { calories:calories, time: time, avg_heart_rate: avg_heart_rate, workout_title: title});
                            }else {
                              navigate("FinishExcierce");
                            }

                    } else {
                        console.log("Sdfsdfsfsdfsfsfdsfd")
                    }

                    this.setState({contentLoader: false})

                }
            )
                .catch(async err => {
                    console.log(err)

                    this.setState({contentLoader: false})
                }
            )


        }
    }


    photouploadserver = (file) => {
        console.log('response', file)

        let formData = new FormData();

        if (file.fileName) {
            name = file.fileName
        } else {
            image_source = file.uri
            image = image_source.split("/");
            image_length = image.length
            name = image[image_length - 1];
        }

        console.log(file.uri.toString(),"gggg")

        ImageResizer.createResizedImage(file.uri, 150, 150, 'PNG', 20).then((response) => {
            console.log(response, "response")

            formData.append('myfile', {
                type: 'image/png',
                name: name,
                uri: response.uri
            })

        axios.post(API.Image_url, formData).then(response => {
            updated_img = response.data
            console.log(updated_img)

            this.setState({
                visible: true
            })
            this.setState({
                upload_uri: updated_img.url,
                upload_text: "Image Uploaded"
            })
            this.setState({
                enable: true
            })


        }).catch(err => {
            console.log('err')
            console.log(err)
            alert("Please Do it Again!!!!")
            this.setState({
                visible: false,
                enable: false
            })
        })

        }).catch((err) => {
            console.log(err)
        });        



    }


    changeTime = (itemvalue, itemIndex) => {

        var hours = parseInt(this.state.hours)

        console.log(hours,'hjjhhj')

        if (itemIndex == 60) {

            if (hours < 23) {
                var hours = hours + 1
            } else {
                var hours = hours
            }

            if(hours < 10) {
                hours = '0'+hours.toString()
            } else {
                hours = hours.toString()
            }


            console.log(hours,"asdasdadas")

            this.setState({
                hours: hours,
                minites: '00'
            })
        } else {

            if(hours < 10) {
                hours = '0'+hours.toString()
            } else {
                hours = hours.toString()
            }

            this.setState({
                hours: hours,
                minites: itemvalue
            })
        }

    }

    updateHour = (hour) => {
        this.setState({
            hours: hour
        })
        //alert('hi')
        this.state.hours = hour
        console.log(this.state.hours)
    }

    updateMinites = (minites) => {
        this.setState({
            minites: minites
        })
    }

    updateSeconds = (seconds) => {
        this.setState({
            seconds: seconds
        })
    }



    openTimer = () => {
        this.setState({
            visibleModal: 5
        })
    }

    _toggleModal = () => this.setState({
        isModalVisible: !this.state.isModalVisible
    })

    render() {

        let data = [{
            value: 'CrossFit',
        }, {
            value: 'Running',
        }, {
            value: 'Weights',
        }, {
            value: 'Cycling',
        }, {
            value: 'Yoga',
        }, {
            value: 'Swmming'
        }, {
            value: 'Aerobics'
        }, {
            value: 'Football'
        }];


        if (this.state.seconds == '') {
            this.setState({
                seconds: '00'
            })
        }

        let time = this.state.hours + ':' + this.state.minites + ':00'

        const { contentLoader } = this.state


        return (
            <View style={styles.mainBody} >
        <StatusBarBackground style={{
                backgroundColor: '#FF7E00'
            }}/>

            
              <View style={styles.listofWrkouts1}>
                <View style={styles.chevron_left_icon1}>
                  <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('UpcomingWorkouts')
            }}>
                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                  </TouchableOpacity>
                </View>

                <View style={styles.header}>
                      <Text style={styles.topSignupTxt1}>
                        Activity
                      </Text>
                </View>

                <View>
                  <Text style = {styles.text_workout_heading}>
                    Log your activity
                  </Text>
                  <Text style = {styles.text_workout_sub_heading}>
                    ADO YOUR SPORT. TIME & RATE TO TRACK YOUR RESULTS
                  </Text>
                </View>


              </View>

            {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :              

        <ScrollView
            style={{
                flex: 1
            }}
            contentContainerStyle={{
                paddingBottom: 50
            }}
            indicatorStyle={'white'}
            scrollEventThrottle={200}
            directionalLockEnabled={true}
            >



              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Title :</Text>
                <View style={styles.log_act1}>

                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                <TextInput
            placeholder="Title"
            underlineColorAndroid='transparent'
            autoCorrect={false}
            value={String(this.state.title)}
            placeholderTextColor='#626264'
            style={styles.textInput_signup}

            onChangeText={ (text) => this.setState({
                title: text,
                enable: true
            })}
            />
                </TouchableWithoutFeedback>

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Add Image :</Text>
                <View style={styles.log_act1}>
                    <PhotoUpload
                     onPhotoSelect={avatar => {
                       if (avatar) {
                         console.log('Image base64 string: ', avatar)
                        
                       }
                       else{
                        console.log('Maniaknta')
                       }
                     }}
                     
                     onStart = {start => {
                      console.log('start',start)
                        this.setState({visible:false})
                     }}
                     onResponse = {response => {
                                                //this.setState({contentLoader:false})
                                                console.log('response', response)
                                                
                                                if(response.didCancel == true) {
                                                    this.setState({
                                                        visible: true
                                                    })                                                    
                                                } else {
                                                    this.photouploadserver(response)
                                                }
                     }}
                     onError = {error => {
                      console.log('error',error)
                     }}
                     onRender = {render => {
                      console.log('render',render)
                     }}
                     >
                    <View style={{height:50,width:150,borderRadius:40,paddingVertical:10,backgroundColor:'#FF7E00'}}>
                        {this.state.visible ?                        
                        <Text style={{textAlign: 'center', marginTop: 6, color: "white", fontWeight: "bold", backgroundColor: 'transparent'}}>{this.state.upload_text}</Text>
                        : <ActivityIndicator
                            animating = {true}
                            color = '#cccccc'
                            size = "large"
                            style = {{
                                paddingTop: 0
                            }}
                          />
                        }
                    </View>                        
                       
                     </PhotoUpload>
                </View>
              </View>
              

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Activity type :</Text>
                <View style={styles.log_act1}>


                    <Dropdown
            data={data}
            value={this.state.sport}
            textColor='white'
            selectedItemColor='black'
            onChangeText={this.onChangeSport}
            />

                </View>


              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Calories :</Text>
                <View style={styles.log_act2}>
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>

                <TextInput
            placeholder="Calories"
            underlineColorAndroid='transparent'
            autoCorrect={false}
            keyboardType='numeric'
            value={String(this.state.calories)}
            placeholderTextColor='#626264'
            style={styles.textInput_signup}
            onChangeText={ (text) => this.setState({
                calories: text,
                enable: true
            })}
            onBlur={this.blurevent}
            />

                </TouchableWithoutFeedback>

                </View>
              </View>


              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Completed Date :</Text>
                <View style={styles.log_act1}>
        
                    <Text style={{
                paddingBottom: 4
            }}></Text>

                     <DatePicker
            style={styles.textInput_signup}
            date={this.state.date}
            mode="date"
            placeholder="Select date"
            format="dddd Do, MMMM YYYY"
            confirmBtnText="Confirm"
            cancelBtnText="Cancel"
            maxDate={new Date()}
            showIcon="false"
            onDateChange={(date) => {
                console.log(date)
                this.setState({
                    date: date
                })
                console.log(this.state.date)
            }}
            />

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Completed Time :</Text>
                <View style={styles.log_act1}>
        
                    <Text style={{
                paddingBottom: 4
            }}></Text>

                <DatePicker
            style={{
                width: 200
            }}
            date={this.state.completedtime}
            mode="time"
            format="HH:mm"
            confirmBtnText="Confirm"
            cancelBtnText="Cancel"
            minuteInterval={10}
            style={styles.textInput_signup}
            onDateChange={(time) => {
                this.setState({
                    completedtime: time
                });
            }}
            />    
                </View>
              </View>


              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>Workout Time :</Text>
                <View style={styles.log_act2}>
                     

                        <View style={{
                flexDirection: 'row',
                marginBottom: 0
            }}>
                          <View style={{
                flex: 1
            }}>


                          <TouchableOpacity onPress = {() => this.openTimer()}>
                            <TextInput
            placeholder="Title"
            underlineColorAndroid='transparent'
            autoCorrect={false}
            editable={false}
            value={time}
            placeholderTextColor='#626264'
            style={styles.textInput_signup}
            pointerEvents="none"
            />
                          </TouchableOpacity>  
                          </View>

                          <View style={{
                width: 56,
                marginLeft: 8
            }}>

                            {this._renderButton(<Icon name="ios-alarm" color="#FF7E00" size={35}  />, () => this.setState({
                visibleModal: 5
            })
            )} 

                          </View>   
                        </View>

                    <Modal
            isVisible={this.state.visibleModal === 5}
            style={styles.bottomModal}
            >
                      <View style={styles.modalContent}>
                        <View style={{
                flexDirection: 'row',
                marginBottom: 0
            }}>
                          <View style={{
                flex: 1
            }}>
                            <Picker selectedValue = {this.state.hours} onValueChange = {(itemValue, itemIndex) => this.setState({
                hours: itemValue
            })}>
                               <Picker.Item label = "00 Hour" value = "00" />
                               <Picker.Item label = "01 Hour" value = "01" />
                               <Picker.Item label = "02 Hours" value = "02" />
                               <Picker.Item label = "03 Hours" value = "03" />
                               <Picker.Item label = "04 Hours" value = "04" />
                               <Picker.Item label = "05 Hours" value = "05" />
                               <Picker.Item label = "06 Hours" value = "06" />
                               <Picker.Item label = "07 Hours" value = "07" />
                               <Picker.Item label = "08 Hours" value = "08" />
                               <Picker.Item label = "09 Hours" value = "09" />
                               <Picker.Item label = "10 Hours" value = "10" />
                               <Picker.Item label = "11 Hours" value = "11" />
                               <Picker.Item label = "12 Hours" value = "12" />
                               <Picker.Item label = "13 Hours" value = "13" />
                               <Picker.Item label = "14 Hours" value = "14" />
                               <Picker.Item label = "15 Hours" value = "15" />
                               <Picker.Item label = "16 Hours" value = "16" />
                               <Picker.Item label = "17 Hours" value = "17" />
                               <Picker.Item label = "18 Hours" value = "18" />
                               <Picker.Item label = "19 Hours" value = "19" />
                               <Picker.Item label = "20 Hours" value = "20" />
                               <Picker.Item label = "21 Hours" value = "21" />
                               <Picker.Item label = "22 Hours" value = "22" />
                               <Picker.Item label = "23 Hours" value = "23" />
                            </Picker>
                          </View>

                          <View style={{
                width: 156,
                marginLeft: 8
            }}>
                            <Picker selectedValue = {this.state.minites} onValueChange = {(itemValue, itemIndex) => this.changeTime(itemValue, itemIndex)}>
                               <Picker.Item label = "00 Minute" value = "00" />
                               <Picker.Item label = "01 Minute" value = "01" />
                               <Picker.Item label = "02 Minutes" value = "02" />
                               <Picker.Item label = "03 Minutes" value = "03" />
                               <Picker.Item label = "04 Minutes" value = "04" />
                               <Picker.Item label = "05 Minutes" value = "05" />
                               <Picker.Item label = "06 Minutes" value = "06" />
                               <Picker.Item label = "07 Minutes" value = "07" />
                               <Picker.Item label = "08 Minutes" value = "08" />
                               <Picker.Item label = "09 Minutes" value = "09" />
                               <Picker.Item label = "10 Minutes" value = "10" />
                               <Picker.Item label = "11 Minutes" value = "11" />
                               <Picker.Item label = "12 Minutes" value = "12" />
                               <Picker.Item label = "13 Minutes" value = "13" />
                               <Picker.Item label = "14 Minutes" value = "14" />
                               <Picker.Item label = "15 Minutes" value = "15" />
                               <Picker.Item label = "16 Minutes" value = "16" />
                               <Picker.Item label = "17 Minutes" value = "17" />
                               <Picker.Item label = "18 Minutes" value = "18" />
                               <Picker.Item label = "19 Minutes" value = "19" />
                               <Picker.Item label = "20 Minutes" value = "20" />
                               <Picker.Item label = "21 Minutes" value = "21" />
                               <Picker.Item label = "22 Minutes" value = "22" />
                               <Picker.Item label = "23 Minutes" value = "23" />
                               <Picker.Item label = "24 Minutes" value = "24" />
                               <Picker.Item label = "25 Minutes" value = "25" />                               
                               <Picker.Item label = "26 Minutes" value = "26" />
                               <Picker.Item label = "27 Minutes" value = "27" />
                               <Picker.Item label = "28 Minutes" value = "28" />
                               <Picker.Item label = "29 Minutes" value = "29" />
                               <Picker.Item label = "30 Minutes" value = "30" />
                               <Picker.Item label = "31 Minutes" value = "31" />
                               <Picker.Item label = "32 Minutes" value = "32" />
                               <Picker.Item label = "33 Minutes" value = "33" />
                               <Picker.Item label = "34 Minutes" value = "34" />
                               <Picker.Item label = "35 Minutes" value = "35" />
                               <Picker.Item label = "36 Minutes" value = "36" />
                               <Picker.Item label = "37 Minutes" value = "37" />
                               <Picker.Item label = "38 Minutes" value = "38" />
                               <Picker.Item label = "39 Minutes" value = "39" />
                               <Picker.Item label = "40 Minutes" value = "40" />
                               <Picker.Item label = "41 Minutes" value = "41" />
                               <Picker.Item label = "42 Minutes" value = "42" />
                               <Picker.Item label = "43 Minutes" value = "43" />
                               <Picker.Item label = "44 Minutes" value = "44" />
                               <Picker.Item label = "45 Minutes" value = "45" />
                               <Picker.Item label = "46 Minutes" value = "46" />
                               <Picker.Item label = "47 Minutes" value = "47" />
                               <Picker.Item label = "48 Minutes" value = "48" />
                               <Picker.Item label = "49 Minutes" value = "59" />
                               <Picker.Item label = "50 Minutes" value = "50" />
                               <Picker.Item label = "51 Minutes" value = "51" />
                               <Picker.Item label = "52 Minutes" value = "52" />
                               <Picker.Item label = "53 Minutes" value = "53" />
                               <Picker.Item label = "54 Minutes" value = "54" />
                               <Picker.Item label = "55 Minutes" value = "55" />
                               <Picker.Item label = "56 Minutes" value = "56" />
                               <Picker.Item label = "57 Minutes" value = "57" />
                               <Picker.Item label = "58 Minutes" value = "58" />
                               <Picker.Item label = "59 Minutes" value = "59" />
                               <Picker.Item label = "" value = "60" />
                            </Picker>
                          </View>   
                        </View>
                        {this._renderButton1("Close", () => this.setState({
                visibleModal: null
            }))}
                      </View>


                    </Modal>


                </View>

              </View>              

            </ScrollView>

        }

        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress = {() => this.nextpage()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                    

                    <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Complete Workout</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 


              
            </View>



        );
    }
}
