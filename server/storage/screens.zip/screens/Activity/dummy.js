              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>SPORT :</Text>
                <View style={styles.log_act1}>

                <Picker style={{borderWidth: 4, width: 350, marginTop: 10}}
                  selectedValue={this.state.sport}
                  onValueChange={(itemValue, itemIndex) => this.setState({sport: itemValue})}>
                  <Picker.Item color="#fff" label="SELECT FROM LIST" value="" />
                  <Picker.Item color="#fff" label="CrossFit" value="CrossFit" />
                  <Picker.Item color="#fff" label="Running" value="Running" />
                  <Picker.Item color="#fff" label="Weights" value="Weights" />
                  <Picker.Item color="#fff" label="Cycling" value="Cycling" />
                  <Picker.Item color="#fff" label="Yoga" value="Yoga" />
                  <Picker.Item color="#fff" label="Swmming" value="Swmming" />
                  <Picker.Item color="#fff" label="Aerobics" value="Aerobics" />
                  <Picker.Item color="#fff" label="Footbal" value="Footbal" />
                </Picker>

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>COMPLETED DATE :</Text>
                <View style={styles.log_act1}>

                <DatePicker
                  style={styles.textInput_signup}
                  date={this.state.date}
                  mode="date"
                  placeholder="select date"
                  format="YYYY-MM-DD"
                  minDate="2017-05-01"
                  maxDate="2020-06-01"
                  confirmBtnText="Confirm"
                  cancelBtnText="Cancel"
                  customStyles={{
                    dateInput:{
                      borderWidth: 0,
                    },
                    dateText:{
                      color: '#c7c8ca',
                      justifyContent: 'flex-start'
                    }
                  }}
                  onDateChange={(date) => {this.setState({date: date})}}
                />           

                </View>
              </View>

              <View style={styles.feed_img_mas2a}>
                <Text style={styles.sport1}>DURATION :</Text>
                <View style={styles.log_act1}>
                <Text>{this.state.time}</Text>
                <TextInput
                  placeholder="Time"
                  underlineColorAndroid='transparent'
                  autoCorrect={false}
                  value={String(this.state.time)}
                  placeholderTextColor='#626264'
                  style={styles.textInput_signup}
                  onChangeText={ (time) => this.setState({time:time}) }
                />

                </View>
              </View>