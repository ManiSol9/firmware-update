import React, { Component } from 'react';
import { AppRegistry, StyleSheet, Text, View, Alert, TouchableHighlight, NativeAppEventEmitter, NativeEventEmitter, NativeModules, Platform, PermissionsAndroid, ListView, ScrollView, AppState, TouchableOpacity, Image, ToastAndroid } from 'react-native';
import { AsyncStorage } from "react-native";
import Dimensions from 'Dimensions';
import BleManager from 'react-native-ble-manager';
import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';
import moment from "moment";
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { addToTable, addSensorData } from '../../template/api.js';
const window = Dimensions.get('window');
const ds = new ListView.DataSource({
    rowHasChanged: (r1, r2) => r1 !== r2
});
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import Video from 'react-native-video';
import { getExercises, getExerciseDetails, getSensorData, sendStatus } from '../../template/api.js';
import { addToSQLiteTable } from '../../template/SQLiteOperationsOffline.js';
import KeepAwake from 'react-native-keep-awake';
import VideoPlayer from 'awesome-react-native-video-controls';
import Orientation from 'react-native-orientation';

import Toast, { DURATION } from 'react-native-easy-toast'

const BleManagerModule = NativeModules.BleManager;
const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);

export default class VideoExcierce extends Component {

    constructor() {
        super()

        this.state = {
            scanning: false,
            peripherals: new Map(),
            appState: '',
            heartrate: 0,
            screenchange: '0',
            time: moment().format("LTS"),
            date: moment().format("LL"),
            totsec: 2400,
            item: 0,
            array: [],
            sum: 0,
            average: 0,
            calories: 0,
            user_id: null,
            profile: [],
            height: '',
            weight: '',
            showplaypause: false,
            timepassed: false,
            rate: 1,
            volume: 1,
            duration: 0.0,
            currentTime: 0.0,
            paused: true,
            loader: false,
            times: 0,
            timevalue: '0:0',
            started: false,
            seconds1: 0,
            /**/
            bleDeviceConnected: false,
            exerciseStarted: false,
            connected: false,
            contentLoader: true,
            connected: false,
            bleDeviceConnected: false,
            exerciseStarted: false,
            images: ['back1', 'back2', 'back3', 'back4', 'main'],
            pauseReading: true,
            completeReading: false,
            startReading: true,
        /**/
        }

        this.handleDiscoverPeripheral = this.handleDiscoverPeripheral.bind(this);
        this.handleStopScan = this.handleStopScan.bind(this);
        this.handleUpdateValueForCharacteristic = this.handleUpdateValueForCharacteristic.bind(this);
        this.handleDisconnectedPeripheral = this.handleDisconnectedPeripheral.bind(this);
        this.handleAppStateChange = this.handleAppStateChange.bind(this);
    }


    /**** Bluetooth Connectivity **/

    async componentWillMount() {
        var {exerciseID, user_id, workoutID, workout_day, courseID} = this.props.navigation.state.params.params;

        let device_id = await AsyncStorage.getItem("DEVICE_ID");
        let device_name = await AsyncStorage.getItem("DEVICE_NAME");
        const {navigate} = this.props.navigation;
        console.log(device_id, device_name)
        if (!device_id || !device_name) {
            navigate('SearchDevices')
        }

        this._getStudentDetails(user_id);

        this.bleConnect(this.state.device_id)

        /*

        this.setTimeout(() => {

            this.checkstate(this.state.connected)

        }, 10000);

        */

        KeepAwake.activate();

        const initial = Orientation.getInitialOrientation();
        if (initial === 'PORTRAIT') {
            console.log(initial)
        } else {
            console.log(initial)
        }


    }




    async componentDidMount() {


        Orientation.lockToLandscape();

        this.setState({
            device_id: await AsyncStorage.getItem("DEVICE_ID")
        }, () => {

        })

        AppState.addEventListener('change', this.handleAppStateChange);

        this.handlerDiscover = bleManagerEmitter.addListener('BleManagerDiscoverPeripheral', this.handleDiscoverPeripheral);
        this.handlerStop = bleManagerEmitter.addListener('BleManagerStopScan', this.handleStopScan);
        this.handlerDisconnect = bleManagerEmitter.addListener('BleManagerDisconnectPeripheral', this.handleDisconnectedPeripheral);
        this.handlerUpdate = bleManagerEmitter.addListener('BleManagerDidUpdateValueForCharacteristic', this.handleUpdateValueForCharacteristic);



    }

    addBLERoute=async () => {
        const {navigate} = this.props.navigation;
        Alert.alert(
            'Maku sure your device is near By', 'Start actvity again',
            [
                {
                    text: 'Ok',
                    onPress: () => navigate('UpcomingWorkouts')
                },
            ],
            {
                cancelable: false
            }
        )
    }

    _getStudentDetails=(id) => {
        getProfileDetails(id).then(response => {
            console.log(response)
            if (response.status) {
                this.setState({
                    profile: response.data
                }, () => {
                    console.log(this.state.profile)
                    this.setState({
                        height: this.state.profile.height_in_feet,
                        age: this.state.profile.age,
                        weight: this.state.profile.current_weight,
                        gender: this.state.profile.gender
                    }, () => {

                        if (this.state.profile.parameter_type == 1) {

                            this.setState({
                                height: this.state.profile.height_in_centimeter
                            })

                        } else {

                            var height_incm = (this.state.feet * 30.48) + (this.state.inches * 2.54)

                            this.setState({
                                height: height_incm
                            })
                        }

                    });
                });
                console.log(this.state)
            //this.setState({Loader:false, contentLoader:false})
            } else {
                //this.setState({Loader:false, contentLoader:false})
                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
            }
        }, err => {
            console.log(err)
        })
    }


    checkstate(connected) {
        const {navigate} = this.props.navigation;
        if (this.state.connected === false) {
            Alert.alert('Make Sure Your Device is Near By', 'Please Re Connect',
                [
                    {
                        text: 'Ok',
                        onPress: () => this.mani()
                    },
                ],
                {
                    cancelable: false
                }
            )
        } else {
            this.state.contentLoader = false

        }

    }

    mani = () => {
        alert('asdasdasda')
    }


    bleConnect(device_id) {
        let x = 0

        console.log(device_id)

        BleManager.connect(device_id).then(() => {
            console.log('inside connect')

            this.setState({
                connected: true
            })

            this.setTimeout(() => {

                BleManager.retrieveServices(device_id).then((peripheralInfo) => {

                    var service = '180D';
                    var bakeCharacteristic = '2A37';
                    var crustCharacteristic = '13333333-3333-3333-3333-333333330001';

                    this.setTimeout(() => {
                        BleManager.startNotification(device_id, service, bakeCharacteristic).then(() => {


                            console.log('Started notification on ' + device_id);
                            this.state.startbutton = 1;


                        }).catch((error) => {

                            //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                            this.state.loader = false

                            this.state.startbutton = 0

                            console.log('Connection error', error);


                        });
                    }, 200);
                }).catch((error) => {

                    //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

                    this.state.loader = false

                    this.state.startbutton = 0

                    console.log('Connection error', error);


                });

            }, 900);

        }).catch((error) => {

            //this.refs.toast.show('Make Sure your Device is near by.', DURATION.LENGTH_LONG);

            this.state.loader = false

            this.state.startbutton = 0

            console.log('Connection error', error);

        });

    }


    handleAppStateChange(nextAppState) {
        if (this.state.appState.match(/inactive|background/) && nextAppState === 'active') {
            console.log('App has come to the foreground!')
            BleManager.getConnectedPeripherals([]).then((peripheralsArray) => {
                console.log('Connected peripherals: ' + peripheralsArray.length);
            });
        }
        this.setState({
            appState: nextAppState
        });
    }



    handleDisconnectedPeripheral(data) {
        let peripherals = this.state.peripherals;
        let peripheral = peripherals.get(data.peripheral);
        if (peripheral) {
            peripheral.connected = false;
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            });

        }
        console.log('Disconnected from ' + data.peripheral);

    }


    handleUpdateValueForCharacteristic(data) {
        //console.log('Received data from ' + data.peripheral + ' characteristic ' + data.characteristic, data.value);
        this.setState({
            heartrate: data.value[1]
        });
        this.savedata(data.value[1])
    }

    savedata(data) {

        this.state.array[this.state.item] = data;

        if (this.state.item == 20) {
            this.setState(prevState => ({
                times: prevState.times + 20
            }))
            for (var i = 0; i < this.state.array.length; i++) {
                this.state.sum += parseInt(this.state.array[i]);
            }

            if (this.state.array.length > 0) {

                this.state.average = Math.round(this.state.sum / this.state.array.length);

                this.state.avg_heart_rate[this.state.increment] = this.state.average;

                if (this.state.age == null) {
                    this.state.age = 25
                }

                //console.log(this.state.age)  

                let calories = Math.round((0.4472 * this.state.average - 0.05741 * this.state.weight + 0.074 * this.state.age - 20.4022) * 0.333 / 4.184)

                //let calories = Math.round((-55.0969 + (0.6309 * this.state.average) + (0.1988 * (this.state.weight/2.2046) + (0.2017 * this.state.age))/4.184) * 60 * 0.005)

                if (calories < 0 || calories == 'null') {
                    calories = 0
                }

                this.state.calories = calories + this.state.calories;

                this.state.increment++

                console.log(this.state.age)

                console.log(this.state.calories)

            }

            this.state.item = 0;

            this.state.array = [];

            this.state.sum = 0;

        } else {

            this.state.item = this.state.item + 1;

        }

    }


    handleStopScan() {
        console.log('Scan is stopped');
        this.setState({
            scanning: false
        });
    }

    startScan() {
        if (!this.state.scanning) {
            BleManager.scan([], 30, true).then((results) => {
                console.log('Scanning...');
                this.refs.toast.show('Scanning....', DURATION.LENGTH_LONG);
                this.setState({
                    scanning: true
                });
            }).catch((error) => {
                console.log('Connection error', error);
                this.refs.toast.show('Connection error.... Please Try To Reconnect', DURATION.LENGTH_LONG);
            });
        }
    }

    handleDiscoverPeripheral(peripheral) {
        var peripherals = this.state.peripherals;
        if (!peripherals.has(peripheral.id)) {
            console.log('Got ble peripheral', peripheral);
            peripherals.set(peripheral.id, peripheral);
            this.setState({
                peripherals
            })
        }
    }


    componentWillUnmount() {

        BleManager.disconnect(this.state.device_id)
            .then(() => {
                //console.log('Disconnected');
            })
            .catch((error) => {
                //console.log(error);
            });
        this.setState({});
        this.handlerDiscover.remove();
        this.handlerStop.remove();
        this.handlerDisconnect.remove();
        this.handlerUpdate.remove();

        Orientation.lockToPortrait();


    }

    savedata(data) {

        //console.log(calories)

        this.state.array[this.state.item] = data;

        if (this.state.item == 20) {
            this.setState(prevState => ({
                times: prevState.times + 20
            }))
            for (var i = 0; i < this.state.array.length; i++) {
                this.state.sum += parseInt(this.state.array[i]);
                console.log('Value is ' + this.state.array.length);
            }

            if (this.state.array.length > 0) {

                this.state.average = Math.round(this.state.sum / this.state.array.length);

                if (this.state.age == null) {
                    this.state.age = 25
                }

                let calories = Math.round((0.4472 * this.state.average - 0.05741 * this.state.weight + 0.074 * this.state.age - 20.4022) * 0.333 / 4.184)

                //let calories = Math.round((-55.0969 + (0.6309 * this.state.average) + (0.1988 * (this.state.weight/2.2046) + (0.2017 * this.state.age))/4.184) * 60 * 0.005)

                if (calories < 0) {
                    calories = 0
                }

                this.state.calories = calories + this.state.calories;

                console.log(this.state.age)

                console.log(this.state.calories)

                this._storeInDB();

            }

            this.state.item = 0;

            this.state.array = [];

            this.state.sum = 0;

        } else {

            this.state.item = this.state.item + 1;

        }

    }


    _storeInDB() {

        console.log('assassa')

        var {user_id, exerciseID, workoutID, courseID, workout_day} = this.props.navigation.state.params.params;
        var {average, calories, times} = this.state;
        var data = {
            "user_id": user_id,
            "avg_heart_rate": average,
            "calories": calories,
            "exercise_id": exerciseID,
            "course_id": courseID,
            "workout_id": workoutID,
            "workout_day": workout_day
        }
        var toSQL = [user_id, exerciseID, average, times];
        addToSQLiteTable({
            table_name: 'sensor_data',
            table_data: toSQL
        }).then(response => {
            console.log(response);
        }, error => {
            console.log(error);
        })
        addSensorData(data).then(response => {
            console.log(response);
        }, error => {
            console.log(error);
        })
    }

    _sendStatus() {
        let statusvalue = 'completed'

        console.log(this)

        BleManager.disconnect(this.state.device_id)
            .then(() => {
                console.log('Disconnected');
            })
            .catch((error) => {
                console.log(error);
            });


        var cal = this.state.calories

        var min = 20

        var sec = 20

        var {exerciseID, user_id, workoutID, courseID, workout_day, workout_title} = this.props.navigation.state.params.params;


        let temp = {
            "user_id": user_id,
            "exercise_id": exerciseID,
            "workout_id": workoutID,
            "course_id": courseID,
            "workout_day": workout_day,
            "exercise_status": statusvalue
        };

        sendStatus(temp).then(res => {

            const {navigate} = this.props.navigation;

            var time = min + ':' + sec

            clearInterval(this.timer);

            navigate("WorkoutSummary", {
                workoutID: workoutID,
                calories: cal,
                time: time,
                workout_title: workout_title,
                courseID: courseID,
                workout_day: workout_day,
                user_id: user_id,
                exerciseID: exerciseID
            });

        },
            err => {
                console.log(err);
            })
    }

    onEndCall=() => {

        if (this.state.connected === false) {
            Alert.alert('Complete the workout?', '',
                [
                    {
                        text: 'Ok',
                        onPress: () => this._sendStatus()
                    },
                    {
                        text: 'Cancel'
                    }
                ],
                {
                    cancelable: false
                }
            )
        }

    }



    render() {

        var {exerciseID, streaming_uri, user_id, workoutID, courseID, workout_day, workout_title} = this.props.navigation.state.params.params;
        var {bleDeviceConnected, exerciseStarted} = this.state;
        const list = Array.from(this.state.peripherals.values());

        for (i = 0; i < list.length; i++) {
            if (list[i].id == this.state.device_id) {
                var device_data = list[i]
            }
        }

        return (
            <View style={style.container}>
                    <VideoPlayer
            source={{
                uri: 'https://www.w3schools.com/html/mov_bbb.mp4'
            }}
            heartrate={this.state.heartrate}
            onEnd={this.onEndCall}
            navigator={ this.props.navigator }
            />
                </View>
        );
    }

}

reactMixin(VideoExcierce.prototype, TimerMixin);

const style = StyleSheet.create({
    container: {
        backgroundColor: 'red',
        height: '100%'
    }
});
