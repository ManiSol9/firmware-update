import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Switch,
  Image,
  PixelRatio,
  KeyboardAvoidingView,
  ScrollView,
  TouchableHighlight,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  ActivityIndicator
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

import { onSignIn } from '../../../config/auth';
import API from '../../template/constants.js';
import axios from 'axios'; 
import styles from './styles.js';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import Toast, {DURATION} from 'react-native-easy-toast'
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import  Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'

export default class AddDetails extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      email: ""
    };
  }
  componentWillMount(){
    console.log(this.props.navigation);
  }



  render(){

    return(
      <View style={styles.mainBody}>
        <View style={styles.chevron_left_icon}>
          <TouchableOpacity onPress={()=>{
            const { navigate } = this.props.navigation;
            navigate('Signup')}}>
            <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
          </TouchableOpacity>
        </View>
        <View style={styles.header}>
            <Text style={styles.topSignupTxt}>
              ALL COURSES
            </Text>
        </View>
        <View style={styles.header}>
            <TouchableOpacity onPress={()=>{
              const { navigate } = this.props.navigation;
              navigate('Personal');
            }}>        
          <Text style={styles.topSignupTxt}>
            User Info
          </Text>
            </TouchableOpacity>
        </View>   
        <View style={styles.header}>
          <Text style={styles.topSignupTxt}>
            Profile Details
          </Text>
        </View> 
        <View style={styles.header}>
          <Text style={styles.topSignupTxt}>
            Pick Class
          </Text>
        </View>                       
      </View>
    );
  }
}
