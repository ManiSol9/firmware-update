import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Switch,
  Image,
  PixelRatio,
  KeyboardAvoidingView,
  ScrollView,
  TouchableHighlight,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  ActivityIndicator
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';

import { onSignIn } from '../../../config/auth';
import API from '../../template/constants.js';
import axios from 'axios'; 
import styles from './styles.js';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import Toast, {DURATION} from 'react-native-easy-toast'

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import  Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'

export default class Password extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      email: "",
      password: "",
      confirmPassword: "",
      first_name: "",
      last_name:"",
      username: "",
      showErrorEmail: false,
      showErrorPassword: false,
      showErrorConfirmPassword: false,
      showErrorFirstName: false,
      showErrorLastName:false,
      showErrorUsername: false,
      errorEmailMessage: "Check email",
      errorPasswordMessage: "Check password",
      errorConfirmPasswordMessage: "Check confirm password",
      errorUsernameMessage: "Check username",
      errorFirstNameMessage: "Check first name",
      errorLastNameMessage:"Check Last Name",
      loader:false

    };
  }
  componentWillMount(){
    console.log(this.props.navigation);
  }




/*authenticating starts*/
  _authenticateSignup = () => {
  
  if(this.state.email==="") {
      console.log('empty email', this.state)
      this.setState(
        {
          showErrorEmail:true,
          showErrorPassword:false,
          showErrorConfirmPassword:false,
          showErrorFirstName:false,
          showErrorUserName:false,
          showErrorLastName:false
        }
      )
  
  } else {

      console.log("Manikanta")

      const { navigate  } = this.props.navigation;

      navigate("AddDetails")

    }

  }
/*authenticating ends*/
  resetField=()=>{
    console.log('resetting fields')
    this.setState({
      email: "",
      showErrorEmail: false,
    },()=>console.log(this.state))
  }


  render(){
    const {
      email,
      showErrorEmail,
      errorEmailMessage,
      loader
    } = this.state;
    const { navigate } = this.props.navigation;
    return(
      <View style={styles.mainBody}>

              <View style={styles.chevron_left_icon}>
                <TouchableOpacity onPress={()=>{
          const { navigate } = this.props.navigation;
          navigate('Personal')}}>
                    <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                </TouchableOpacity>
              </View>

              <View style={styles.header}>
                    <Text style={styles.topSignupTxt}>
                      User Info (2/2)
                    </Text>
              </View>
        <ScrollView style={{ marginTop : 20, marginBottom:0, paddingBottom:60, height:Dimensions.get('window').height, width:Dimensions.get('window').width }} >
          <KeyboardAvoidingView behavior="padding">
            <View style={styles.signup_temp_form}>
              <View style={styles.body1a}>             

              <View style={styles.chevron_left_icon}>
                <TouchableOpacity onPress={()=>{
          const { navigate } = this.props.navigation;
          navigate('School')}}>
                    <FontAwesome name="chevron-right" size={25} color="#FF7E00"   />
                </TouchableOpacity>
              </View>

              <View style={styles.header}>
                    <Text style={styles.topSignupTxt}>
                      Select Your School
                    </Text>
              </View>              

              </View>
            </View>
          </KeyboardAvoidingView>
        </ScrollView>


        <View style={{bottom:0,position:'absolute',alignItems:'center',justifyContent:'center'}}>
            <TouchableOpacity onPress={() => this._authenticateSignup() }>
                <View style={{zIndex:999,alignItems:'center',justifyContent:'center',height:50,width:width}}>
                    
            
              {loader?
                <ActivityIndicator
                  animating = {loader}
                  color = '#bc2b78'
                  size = "large"
                  style = {styles.activityIndicator}
                />
                :
                    <Text style={{backgroundColor:'transparent',alignSelf:'center',fontFamily:'CircularStd-Black',color:'#fff',fontSize:19}}>Save And Continue</Text>
              }
            

                </View>
                <Image style={{width:width,height:50,position:'absolute',bottom:0}} source={{ uri: 'btn_gradi_bg' }}/>
            </TouchableOpacity>
        </View> 


                <Toast
                    ref="toast"
                    style={{backgroundColor:'#000',bottom:0}}
                    position='top'
                    positionValue={200}
                    fadeInDuration={750}
                    fadeOutDuration={1000}
                    opacity={0.8}
                    textStyle={{color:'white'}}
                />           

      </View>
    );
  }
}
