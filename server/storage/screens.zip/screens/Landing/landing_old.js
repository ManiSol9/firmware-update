
import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, Alert, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, ToastAndroid, Keyboard, Dimensions } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js';
import axios from 'axios';
import styles from './styles.js'
var {width, height} = Dimensions.get('window');
import StatusBarBackground from '../../screens/Tabs/statusbar.js'
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';
import { addToSQLiteTable } from '../../template/SQLiteOperationsOffline.js';
import { addAsyncStorage } from '../../../config/auth.js'


/*
import { NativeModules } from 'react-native';
const RNHealthKit = NativeModules.RNHealthKit;

import { NativeAppEventEmitter } from 'react-native';

import moment from 'moment';

import TimerMixin from 'react-timer-mixin';
import reactMixin from 'react-mixin';


/*

var AppleHealthKit = require('react-native-apple-healthkit-rn0.40');

const HKPERMS = AppleHealthKit.Constants.Permissions;
const HKOPTIONS = {
    permissions: {
        read: [
            HKPERMS.StepCount,
            HKPERMS.DistanceWalkingRunning,
            HKPERMS.FlightsClimbed,
            HKPERMS.Height,
            HKPERMS.DateOfBirth,
            HKPERMS.BiologicalSex,
            HKPERMS.SleepAnalysis,
        ],
        write: [
            HKPERMS.StepCount
        ],
    }
};

*/

FCM.on(FCMEvent.Notification, async (notif) => {
    console.log(notif);
    FCM.presentLocalNotification({
        id: Date.now().toString(), // (optional for instant notification)
        title: notif.fcm.title, // as FCM payload
        body: notif.fcm.body, // as FCM payload (required)
        sound: "default", // as FCM payload
        priority: "high", // as FCM payload
        click_action: "ACTION", // as FCM payload
        // badge: 10,                                          // as FCM payload IOS only, set 0 to clear badges
        // Android only
        auto_cancel: true, // Android only (default true)
        icon: "ic_launcher", // as FCM payload, you can relace this with custom icon you put in mipmap                      // Android only
        color: "red", // Android only
        vibrate: 300, // Android only default: 300, no vibration if you pass 0
        lights: true, // Android only, LED blinking (default false)
        show_in_foreground: true // notification when app is in foreground (local & remote)
    });
    if (notif.opened_from_tray) {
        console.log("Opened from Tray")
    }
});

FCM.on(FCMEvent.RefreshToken, (token) => {
    console.log(token)
});


export default class Landing extends Component {

    constructor(props) {
        super(props);
        this.state = {
            token: '',
            initNotif: ''
        };
    }


    async componentWillMount() {
        console.log("--Landed--")

        let ALLOW_NOTIFY = await AsyncStorage.getItem("ALLOW_NOTIFY");

        if (!ALLOW_NOTIFY) {

            Alert.alert("We use notifications to send key reminders so you always stay on track.", "We'll use them sparingly. Select yes to continue.",
                [
                    {
                        text: 'Yes',
                        onPress: () => this.notification()
                    },
                    {
                        text: 'No',

                    },
                ],
                {
                    cancelable: false
                }
            )

        }



    /*

    let d = new Date();


    let options = {
        permissions: {
            read: ["Height", "Weight", "StepCount", "DateOfBirth", "BodyMassIndex"],
            write: ["Weight", "StepCount", "BodyMassIndex"],
            date: d.toISOString()
        }
    };


    AppleHealthKit.initHealthKit(options: Object, (err: string, res: Object) => {
        if (err) {
            console.log("error initializing healthkit: ", err);
            return;
        }

        setInterval(() => {

            AppleHealthKit.getStepCount(options: Object, (err: Object, steps: Object) => {
                console.log(steps.value)
            });

        }, 2000)

    });

    */
    }

    notification = () => {



        FCM.requestPermissions().then(() => console.log('granted')).catch(() => console.log('notification permission rejected'));

        FCM.getFCMToken().then(token => {
            console.log(token)
            // store fcm token in your server
            this.setState({
                token: token
            })
            console.log(this.state.token);

            addAsyncStorage({
                "DEVICE_ID": '',
                "DEVICE_NAME": '',
                "USER_ID": '',
                "USER_NAME": '',
                "ALLOW_NOTIFY": this.state.token
            })
                .then(res => {
                    console.log(res)
                    if (res.status) {
                        console.log("Stored Successfully")
                    } else {
                        console.log("Problom in Storing")
                    }
                }, err => {
                    console.log("conection Error")
                })

        });

    }

    render() {
        const {navigate} = this.props.navigation;
        const {container} = style;




        return (
            <View style={{
                backgroundColor: '#2d2e37',
                marginTop: 0,
                padding: 0,
                height: Dimensions.get('window').height,
                width: Dimensions.get('window').width
            }}>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
        <View style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: undefined,
                height: undefined
            }}>
          <Image style={{
                resizeMode: 'stretch',
                height: Dimensions.get('window').height,
                width: Dimensions.get('window').width,
            }}
            source={{
                uri: 'login_main_bg'
            }}
            />
        </View>
        <View style = {{
                marginTop: '14%',
                justifyContent: 'center',
                alignItems: 'center'
            }}>
          <Image style={{
                resizeMode: 'contain',
                width: 140,
                height: 30
            }} source={{
                uri: 'top_logo'
            }} />
        </View>
        <View style = {{
                marginTop: '86%',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
          <View style={{
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <View>
              <Text style = {styles.textStyle}>Get inspired with our challenges quotes and friends workouts</Text>
            </View>
          </View>
        </View>
             <View style = {styles.home_signup_btn_main_view}>
                <TouchableOpacity onPress={() => navigate("Singup_New")}>
                <View style={styles.home_signup_btn_img_view}>
                  <Image source={{
                uri: 'signup_button_bg'
            }} style = {styles.home_signup_btn_img} />
                </View>

                  <View style = {styles.home_signup_btn_text_view}>
                    <Text style={styles.home_signup_btn_text}>Sign up</Text>
                  </View>
                </TouchableOpacity>
             </View>        
        <View style ={{
                alignItems: 'center',
                justifyContent: 'center',
                position: 'absolute',
                bottom: 0,
                left: 0,
                right: 0
            }}>
          <View style ={{
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <Text style={styles.textStyle}>
              <Text> I have an account </Text>
              <Text style = {{
                fontWeight: 'bold',
                color: '#fb620c'
            }} onPress={() => navigate("Login", {
                token: this.state.token
            })}>
                Log in
              </Text>
            </Text>
          </View>
        </View>
      </View>
        );
    }
}



const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    }
});