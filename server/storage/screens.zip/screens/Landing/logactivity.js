import React, { Component } from 'react';
import { AppRegistry, FlatList, StyleSheet, TextInput, Picker, ScrollView, TouchableOpacity, Text, Image, KeyboardAvoidingView, View, TouchableHighlight, ToastAndroid, Alert, ActivityIndicator, TouchableWithoutFeedback, Keyboard } from 'react-native';
import { Card, Button, FormLabel, FormInput, FormValidationMessage } from "react-native-elements";
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import Icon2 from 'react-native-vector-icons/MaterialCommunityIcons';
import { NavigationActions } from 'react-navigation';

import { onSignIn, getAllAsyncStroage } from '../../../config/auth';
import { getProfileDetails } from '../../template/SQLiteOperationsOffline.js';
import { updateProfile } from '../../template/api.js';
import API from '../../template/constants.js';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

import PhotoUpload from 'react-native-photo-upload'
import axios from 'axios';

const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');
import styles from '../Landing/styles.js';

import { request } from 'graphql-request'
import { Dropdown } from 'react-native-material-dropdown';


export default class ProfileDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            profile: [],
            height_in_feet: null,
            height_in_meters: null,
            height_in_inches: null,
            weight: null,
            age: null,
            gender: 'Male',
            userid: null,
            genderIndex: null,
            enable: null,
            Loader: false,
            contentLoader: true,
            editable: null,
            visible: true,
            profile_img_url: null,
            upload_uri: null,
            upload_uri_check: false,
            visible: true,
            imperial: 0,
            weight_in_kgs: null,
            profile_img_url: null,
            password: null
        }
    }
    async componentWillMount() {


    }


    photouploadserver = (file) => {
        console.log('response', file)

        let formData = new FormData();

        if (file.fileName) {
            name = file.fileName
        } else {
            image_source = file.uri
            image = image_source.split("/");
            image_length = image.length
            name = image[image_length - 1];
        }

        console.log(name)

        formData.append('myfile', {
            type: 'image/png',
            name: name,
            uri: file.uri.toString()
        })

        axios.post(API.Image_url, formData).then(response => {
            updated_img = response.data
            console.log(updated_img)

            this.setState({
                visible: true
            })
            this.setState({
                upload_uri: updated_img.url
            })
            this.setState({
                enable: true
            })


        }).catch(err => {
            console.log('err')
            console.log(err)

        })

    }


    render() {
        var that = this;
        var radio_props = [
            {
                label: 'Male',
                value: 0
            },
            {
                label: 'Female',
                value: 1
            }
        ];
        var {height, weight, age, enable, loader, contentLoader, profile_img_url, weight_in_kgs, height_in_inches, height_in_feet, height_in_meters, upload_uri} = this.state;

        if (upload_uri == null) {
            image_path = 'https://www.sparklabs.com/forum/styles/comboot/theme/images/default_avatar.jpg'
        } else {
            image_path = upload_uri
        }

        console.log(this.state)

        let data = [{
          value: 'Banana',
        }, {
          value: 'Mango',
        }, {
          value: 'Pear',
        }];        

        if(this.state.imperial == 0)
        {
            if(height_in_feet == null) {
                height_in_feet = 0
            }
            if(height_in_inches == null) {
                height_in_inches = 0
            }

            edit_height = height_in_feet +"'"+height_in_inches
            edit_weight = weight
        } else {
            edit_height = height_in_meters
            edit_weight = weight_in_kgs
        }

        console.log(image_path)


        return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>


                  <View style={style.body}>
                    <View style={{height: 150, backgroundColor: '#000',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: width,padding: 10, flex: 1, flexDirection: 'row' }}>
                                
                                <View style={{width: '10%'}}>
                                    <TouchableOpacity onPress={() => {
                                        const {navigate} = this.props.navigation;
                                        navigate('Tabs')
                                    }}>
                                        <Icon name="chevron-left" size={25} color="#FF7E00"   />
                                    </TouchableOpacity>
                                </View>
                                <View style={{width: '80%', alignItems: 'center'}}>
                                    <Text style={{ color: '#2d2e37', fontWeight: 'bold', fontSize: 16, textAlign: 'center'}}>Activty</Text>
                                </View>    
                                <View style={{width: '10%', alignItems: 'flex-end'}}>
                                </View>                                
                            </View>

                        </View>

                        <View>
                          <View style={{ padding: 20, bottom: 10}}>

                                  <Text style={{ color: '#fff', fontWeight: 'bold', fontSize: 32, textAlign: 'left'}}>Log your activity</Text>
                                  <Text style={{ color: '#ff7200', fontSize: 11, paddingTop: 20, textAlign: 'left'}}>ADO YOUR SPORT. TIME & RATE TO TRACK YOUR RESULTS</Text>

                          </View>
                        </View>

                    </View>
  

                    <View style={{flex: 1, flexDirection: 'column', marginTop: 20, height: 600}}>

                        <ScrollView style={{flex: 1}}>


                            <View style={{marginTop: 10}}>

                                <View style={{paddingLeft: 10}}>

                                    <Text style={{fontSize: 15}}> Sport </Text>

                                 </View>

                                <View style={{paddingTop: 10, paddingLeft: 5}}>

                                    <Text style={{fontSize: 40, fontWeight: 'bold', color: "#fff"}}> Crossfit </Text>

                                 </View>


                            </View>

                            <View style={style.crossbar}></View>

                          <View style={{alignItems: 'flex-start', padding: 20}}>

                                <PhotoUpload
                                            onPhotoSelect={avatar => {
                                                if (avatar) {
                                                    console.log('Image base64 string: ', avatar)

                                                }

                                            }}

                                            onStart = {start => {
                                                console.log('start', start)
                                                //this.setState({contentLoader:true})
                                                this.setState({
                                                    visible: false
                                                })
                                            }}
                                            onResponse = {response => {
                                                //this.setState({contentLoader:false})
                                                console.log('response', response)
                                                
                                                if(response.didCancel == true) {
                                                    this.setState({
                                                        visible: true
                                                    })                                                    
                                                } else {
                                                    this.photouploadserver(response)
                                                }

                                            }}
                                            onError = {error => {
                                                console.log('error', error)
                                            }}
                                            onRender = {render => {
                                                console.log('render', render)
                                            }}
                                            >
                                               {this.state.visible ?

                                                <View style={{height: 50,
                                                width: 150,
                                                borderRadius: 20,
                                                paddingVertical: 10,
                                                backgroundColor: '#ff7200', alignItems: 'center' }}>
                                                    <Text style={{ fontSize: 18, color: "#fff", padding: 5, fontWeight: 'bold'}}> <Icon name="camera" size={20} color="#FFF"   />  Add Photo</Text>
                                                </View>


                                                : 
                                                <View style={{height: 50,
                                                width: 150,
                                                borderRadius: 20,
                                                paddingVertical: 10,
                                                backgroundColor: '#ff7200', alignItems: 'center' }}>
                                                    <ActivityIndicator
                                                    animating = {true}
                                                    color = '#cccccc'
                                                    size = "large"
                                                    style = {{
                                                        paddingTop: 0
                                                    }}
                                                    />

                                                </View> }
                                                    
                                                   
                                </PhotoUpload> 
                          </View>


                            <View style={style.crossbar}></View>


                            <View style={{flex: 1, flexDirection: 'row', padding: 15}}>

                                <View style={{width: '40%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>TITLE</Text>
                                </View>
                                <View style={{width: '60%' }}> 
                                    <View style={{width: 200}}>
                                        <View>

                                        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                                            <TextInput
                                                placeholder="Title"
                                                underlineColorAndroid='transparent'
                                                autoCorrect={false}
                                                placeholderTextColor='#626264'
                                                style={style.textInput_signup}

                                                onChangeText={ (text) => this.setState({
                                                    title: text,
                                                    enable: true
                                                })}
                                            />
                                        </TouchableWithoutFeedback>

                                        </View>
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', padding: 15}}>

                                <View style={{width: '40%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>CALORIES</Text>
                                </View>
                                <View style={{width: '60%' }}> 
                                    <View style={{width: 200}}>
                                        <View>

                                        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
                                                <TextInput
                                            placeholder="Calories"
                                            underlineColorAndroid='transparent'
                                            autoCorrect={false}
                                            keyboardType='numeric'
                                            value={String(this.state.calories)}
                                            placeholderTextColor='#626264'
                                            style={style.textInput_signup}
                                            onChangeText={ (text) => this.setState({
                                                calories: text,
                                                enable: true
                                            })}
                                            onBlur={this.blurevent}
                                            />
                                        </TouchableWithoutFeedback>

                                        </View>
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '40%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>COMPLETED DATE</Text>
                                </View>
                                <View style={{width: '60%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>

                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>COMPLETED TIME</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={data}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>WORKOUT TIME</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={data}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row', borderBottomWidth: 1, padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>CALORIES</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={data}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                      />
                                    </View>                                
                                </View>

                            </View>

                            <View style={{height: 40, backgroundColor: '#000', borderBottomWidth: 1, padding: 10}}>

                                <View style={{alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold', color: '#2d2e37'}}>SETTINGS</Text>
                                </View>

                            </View>

                            <View style={{flex: 1, flexDirection: 'row',  padding: 15}}>

                                <View style={{width: '45%', alignItems: 'flex-start'}}> 
                                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>NOTIFICATIONS</Text>
                                </View>
                                <View style={{width: '50%', marginTop: -35 }}> 
                                    <View style={{width: 200}}>
                                      <Dropdown
                                        label=''
                                        data={data}
                                        style={{width: '100%'}}
                                        itemTextStyle={{fontWeight: 'bold'}}
                                      />
                                    </View>                                
                                </View>

                            </View>


                            <View style={{height: 60}}>


                            </View>

                        </ScrollView>

                    </View>                    

                    </View>

        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress={() => this.SaveData()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
            <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Complete workout</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 



            </View>
        );
    }
}

const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#2d2e37',
        flex:1,
        marginTop: 0
    },
    tab1: {
      height: 60, 
      width: '50%', 
      backgroundColor: '#000', 
      borderBottomWidth: 2,  
      borderBottomColor: '#ff7200', 
      borderRightWidth: 1,  
      borderRightColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    tab2: {
      height: 60, 
      width: '50%', 
      borderWidth: 0, 
      borderLeftWidth: 0, 
      borderColor: 'black', 
      alignItems: 'center', 
      justifyContent: 'center'
    },
    innerBlock: {fontSize: 10, color: '#fff', paddingTop: 5, fontWeight: 'bold', paddingLeft: 20, paddingTop: 10},
    middleLine: {borderBottomWidth: 2, borderColor: '#ff7200', width: 50, marginLeft: 20},
    headerLine: { color: '#fff', fontWeight: 'bold', fontSize: 55, textAlign: 'left', paddingLeft: 20},
    iconstyle: {textAlign: 'right', padding: 5},
    crossbar: {borderWidth: 1, borderColor: '#000', marginTop: 20, marginBottom: 20},
    textInput_signup: {
        backgroundColor: '#202124',
        borderRadius: 10,
        position: 'relative',
        color: '#fff',
        width: 200,
        padding: 10 ,
        marginTop: -10       
    }



});


module.exports = ProfileDetails;

