
import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, Alert, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, ToastAndroid, Keyboard, Dimensions } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js';
import axios from 'axios';
import styles from './styles.js'
var {width, height} = Dimensions.get('window');
import StatusBarBackground from '../../screens/Tabs/statusbar.js'
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';

import { AsyncStorage } from "react-native";
import { RadioGroup, RadioButton } from 'react-native-flexi-radio-button';
import { addToSQLiteTable } from '../../template/SQLiteOperationsOffline.js';
import { addAsyncStorage } from '../../../config/auth.js'
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Icon from 'react-native-vector-icons/Ionicons';
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';


import { request } from 'graphql-request'


export default class Landing extends Component {

    constructor(props) {
        super(props);
        this.state = {
            token: '',
            initNotif: ''
        };
    }


    async componentWillMount() {
        console.log("--Landed--")
    }

    render() {
        const {navigate} = this.props.navigation;
        const {container} = style;




        return (
            <View style={{backgroundColor: '#2d2e37', marginTop: 0, padding: 0, height: Dimensions.get('window').height, width: Dimensions.get('window').width}}>
                <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

                  <View style={style.body}>
                    <View style={{height: 200, backgroundColor: '#000',
                                    borderColor: '#ddd',
                                    borderBottomWidth: 0,
                                    shadowColor: '#000',
                                    shadowOffset: { width: 0, height: 2 },
                                    shadowOpacity: 0.9,
                                    shadowRadius: 2,
                                    elevation: 1}}>


                        <View style={{flex: 1, flexDirection: 'row', height: 10}}>

                            <View style={{width: 50, alignItems: 'center', padding: 10}}>
                                  <TouchableOpacity onPress={() => {
                                            const {navigate} = this.props.navigation;
                                            navigate('UpcomingWorkouts')
                                        }}>
                                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                                  </TouchableOpacity>
                            </View>
                            <View style={{width: width-50, marginLeft: 100,padding: 10}}>
                                <Text style={{ color: '#fff', fontWeight: 'bold'}}>Calendar</Text>
                            </View>

                        </View>

                        <View style={{padding: 20}}>

                       <Text style={{fontSize: 30, color: '#fff'}}>Workout calendar</Text>

                        </View>

                        <View style={{padding: 20}}>

                       <Text style={{fontSize: 35, color: '#fff'}}>6.5</Text>

                        </View>


                    </View>
  

                    <View style={{marginTop: 10, flex: 1}}>

                      <CalendarList
                          // Callback which gets executed when visible months change in scroll view. Default = undefined
                          onVisibleMonthsChange={(months) => {console.log('now these months are visible', months);}}
                          // Max amount of months allowed to scroll to the past. Default = 50
                          pastScrollRange={1}
                          // Max amount of months allowed to scroll to the future. Default = 50
                          futureScrollRange={1}
                          // Enable or disable scrolling of calendar list
                          scrollEnabled={true}
                          // Enable or disable vertical scroll indicator. Default = false
                          showScrollIndicator={true}

   markedDates={
    {'2018-05-20': {textColor: '#ff7200'},
     '2018-05-22': {startingDay: true, color: '#ff7200', endingDay: true},
     '2018-05-23': {startingDay: true, color: '#7CFC00', endingDay: true},
     '2018-05-04': {startingDay: true, color: '#ff7200', endingDay: true}
    }}
  // Date marking style [simple/period/multi-dot]. Default = 'simple'
  markingType={'period'}

                        />
                    </View>

                    </View>

            </View>
        );
    }
}



const style = StyleSheet.create({
    container: {
        flex: 1,

    },
    box: {

    },
    body: {
        backgroundColor: '#464444',
        flex:1,
        marginTop: 0
    }
});