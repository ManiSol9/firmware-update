import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableWithoutFeedback, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from './styles.js';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

var Spinner = require('react-native-spinkit');
import dismissKeyboard from 'react-native/Libraries/Utilities/dismissKeyboard';

import { request } from 'graphql-request'


FCM.on(FCMEvent.Notification, async (notif) => {
    console.log(notif);
    FCM.presentLocalNotification({
        id: Date.now().toString(), // (optional for instant notification)
        title: notif.fcm.title, // as FCM payload
        body: notif.fcm.body, // as FCM payload (required)
        sound: "default", // as FCM payload
        priority: "high", // as FCM payload
        click_action: "ACTION", // as FCM payload
        // badge: 10,                                          // as FCM payload IOS only, set 0 to clear badges
        // Android only
        auto_cancel: true, // Android only (default true)
        icon: "ic_launcher", // as FCM payload, you can relace this with custom icon you put in mipmap                      // Android only
        color: "red", // Android only
        vibrate: 300, // Android only default: 300, no vibration if you pass 0
        lights: true, // Android only, LED blinking (default false)
        show_in_foreground: true // notification when app is in foreground (local & remote)
    });
    if (notif.opened_from_tray) {
        console.log("Opened from Tray")
    }
});

FCM.on(FCMEvent.RefreshToken, (token) => {
    console.log(token)
});
var {width, height} = Dimensions.get('window');
export default class Login extends Component {

    constructor(props) {
        super(props);
        this.state = {
            username: "",
            password: "",
            showErrorUsername: false,
            showErrorPassword: false,
            errorUsernameMessage: "",
            errorPasswordMessage: "",
            loader: false,
            isVisible: false,
        };
    }

    componentWillMount() {
        getAllAsyncStroage()
            .then(items => console.log(items)
        )
            .catch(err => console.log(err)
        );
        FCM.requestPermissions().then(() => console.log('granted')).catch(() => console.log('notification permission rejected'));

        FCM.getFCMToken().then(token => {
            console.log(token)
            // store fcm token in your server
            this.setState({
                token: token
            })
            console.log(this.state.token);
        });
    }
    addBLERoute=async () => {
        const {navigate} = this.props.navigation;
        if (await AsyncStorage.getItem("DEVICE_NAME") && await AsyncStorage.getItem("DEVICE_ID")) {
            navigate('Tabs')
        } else {
            Alert.alert('Do you want to save BLE device?', 'You can add later also.',
                [
                    {
                        text: 'Add later',
                        onPress: () => navigate('Tabs')
                    },
                    {
                        text: 'Add',
                        onPress: () => navigate('SearchDevices', {
                            fromRoute: 'Login',
                            toRoute: 'SearchDevices',
                            enableBack: false
                        })
                    },
                ],
                {
                    cancelable: false
                }
            )
        }
    }
    /*authenticating starts*/
    _authenticateLoign = async () => {
        console.log(this.state)
        const {navigate} = this.props.navigation;

        const {token} = '';

        Keyboard.dismiss();
        if (this.state.username !== "" || this.state.password !== "") {
            this.setState({
                loader: true,
                isVisible: true
            })

            if (this.state.username != null) {

                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

                if (!filter.test(this.state.username)) {
                    alert("Enter valid email address")
                    this.setState({
                        loader: false,
                        isVisible: false
                    })
                } else {

                    this.setState({
                        loader: true,
                        isVisible: true
                    })

                    /*

                    signin(this.state.username, this.state.password)
                        .then(response => {
                            console.log(response);
                            if (response.status) {
                                this.setState({
                                    loader: false,
                                    isVisible: false
                                })
                                //this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
                                console.log("Notification Regitration started");
                                axios.post("http://resoltz.azurewebsites.net/api/v1/notification/deviceregistration", {
                                    "user_id": response.data.id,
                                    "token": token
                                })
                                    .then((res) => {
                                        console.log(res);
                                    })
                                    .catch((err) => {
                                        console.log('error');
                                    });


                                if (response.data.current_weight && response.data.age && ((response.data.height_in_feet && response.data.height_in_inches) || (response.data.height_in_centimeter)) && response.data.gender) {
                                    console.log("Profile completed")
                                    this.addBLERoute();
                                } else {
                                    console.log("profile not completed")
                                    navigate("ProfileDetails", {
                                        title: 'Complete your profile',
                                        fromRoute: 'Login',
                                        editable: true
                                    });
                                }



                            //console.log("Profile completed")
                            //this.addBLERoute();
                            } else {
                                this.setState({
                                    loader: false,
                                    isVisible: false
                                })
                                this.refs.toast.show(response.show, DURATION.LENGTH_LONG);
                            }
                        }, error => {
                            console.log(error)
                            this.setState({
                                loader: false,
                                isVisible: false
                            })
                            this.refs.toast.show(error.show, DURATION.LENGTH_LONG);
                        })

    */


                    const query = `query 
                                      signin($email: String!, $password: String!)
                                       {
                                          signin(email: $email, password: $password)
                                          {
                                            id, profile_image_url, first_name, last_name, username
                                          }
                                       }
                                    `


                    const variables = {
                        email: this.state.username,
                        password: this.state.password
                    }

                    request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/signin_mobile', query, variables)
                        .then(async data => {

                          console.log(data.signin[0])

                            if (data.signin[0].id == 0) {

                                alert("Password and Email are not matched.")
                                this.setState({
                                    loader: false,
                                    isVisible: false
                                })



                            } else {

                                alert("Sucess")
                                this.setState({
                                    loader: true,
                                    isVisible: true
                                })

                                console.log(data.signin[0])

                                AsyncStorage.setItem("USER_ID", String(data.signin[0].id));
                                AsyncStorage.setItem("PROFILE_IMAGE", String(data.signin[0].profile_image_url));

                                if(data.signin[0].username == null) {

                                    AsyncStorage.setItem("USER_NAME", String(data.signin[0].first_name +''+ data.signin[0].last_name));


                                } else {

                                    AsyncStorage.setItem("USER_NAME", String(data.signin[0].username));

                                }



                                const {navigate} = this.props.navigation;

                                navigate("Tabs")

                            }
                        }
                    )
                        .catch(async err => {
                            console.log(err)
                            alert("Something Went Wrong, Please try again later")

                            this.setState({
                                loader: false,
                                isVisible: false
                            })
                        }
                    )

                }

            } else {
                alert("Enter Valid email address")

                this.setState({
                    loader: false,
                    isVisible: false
                })
            }
        } else {
            alert("Please Fill all the fields")


                this.setState({
                    loader: false,
                    isVisible: false
                })
        }
    }
    /*authenticating starts*/

    render() {
        const {navigate} = this.props.navigation;
        const {loader, username, password, showErrorUsername, showErrorPassword, errorUsernameMessage, errorPasswordMessage, isVisible} = this.state;
        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
        <View style={styles.header}>
          <Text style={styles.topSignupTxt}>
            Log in
          </Text>
        </View>
        <View style={{
                position: 'absolute',
                right: 20,
                paddingTop: 15,
                marginTop: 10
            }}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('Singup_New');
            }}>
              <Text style={{
                color: '#F5F5FF',
                fontSize: 20,
                fontWeight: 'bold',
                opacity: 0.5
            }}>
                  Sign up
                </Text>
            </TouchableOpacity>
          </View>

          {isVisible ?
                <View style={styles.activityIndicator}>
          <Spinner  isVisible={true} size={100} type="Bounce" color="#ff7200"/>
          </View>
                :

                <TouchableWithoutFeedback onPress={dismissKeyboard}>

                <View style={{
                    marginTop: 30
                }}>

          <View style={styles.body1}>
            <Text style={styles.forTxt}>For students, log in using your school email</Text>
            {showErrorUsername ? <Text style={{
                    color: '#fb620c'
                }}>{errorUsernameMessage}</Text> : null}
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <TextInput
                placeholder="Email"
                underlineColorAndroid='transparent'
                autoCorrect={false}
                keyboardType='default'
                placeholderTextColor='#626264'
                style={styles.textInput_login}
                onChangeText={ (text) => this.setState({
                    username: text
                })}
                onFocus={ () => this.setState({
                    showErrorUsername: false,
                    showErrorPassword: false
                })}
                />
                </TouchableWithoutFeedback>
            {showErrorPassword ? <Text style={{
                    color: '#fb620c'
                }}>{errorPasswordMessage}</Text> : null}
                <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <TextInput
                placeholder="Password"
                secureTextEntry={true}
                underlineColorAndroid='transparent'
                autoCorrect={false}
                placeholderTextColor='#626264'
                style={styles.textInput_login}
                onChangeText={ (text) => this.setState({
                    password: text
                })}
                onFocus={ () => this.setState({
                    showErrorUsername: false,
                    showErrorPassword: false
                })}
                />
                </TouchableWithoutFeedback>
            <Text style={styles.nonStudent}>Non students log in account using options below</Text>
            <TouchableOpacity  style={styles.submitFB}>
              <Icon name="facebook-f" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
              <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
              <Text style={styles.buttonText}>
                Log in with Facebook
              </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity  style={styles.submitTW}>
              <Icon name="twitter" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
              <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
              <Text style={styles.buttonText}>
                Log in with Twitter
              </Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity  style={styles.submitGM}>
              <Icon name="google-plus" size={30} color="#fff" style={{
                    position: 'absolute',
                    left: 23,
                    top: 17,
                    fontSize: 20
                }} />
              <View style = {{
                    left: 18,
                    width: 180,
                    alignSelf: 'center'
                }}>
              <Text style={styles.buttonText}>
                Log in with Gmail
              </Text>
              </View>
            </TouchableOpacity>
          </View>

          </View>

          </TouchableWithoutFeedback>

            }

            {isVisible ?

                <View></View>

                :


                <View style={{
                    bottom: 0,
                    position: 'absolute',
                    alignItems: 'center',
                    justifyContent: 'center'
                }}>
            <TouchableOpacity onPress={() => this._authenticateLoign()}>
                <View style={{
                    zIndex: 999,
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: 50,
                    width: width
                }}>
                    

                    <Text style={{
                    backgroundColor: 'transparent',
                    alignSelf: 'center',
                    fontFamily: 'CircularStd-Black',
                    color: '#fff',
                    fontSize: 19
                }}>Save</Text>
          
                </View>
                <Image style={{
                    width: width,
                    height: 50,
                    position: 'absolute',
                    bottom: 0
                }} source={{
                    uri: 'btn_gradi_bg'
                }}/>
            </TouchableOpacity>
        </View>

            }


               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
