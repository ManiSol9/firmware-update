/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, ActivityIndicator, TouchableHighlight, TouchableOpacity, TextInput } from 'react-native';


import Orientation from 'react-native-orientation';
import moment from "moment";


import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { LineChart, YAxis } from 'react-native-svg-charts'
import { LinearGradient, Stop } from 'react-native-svg'

import * as shape from 'd3-shape'
const Dimensions = require('Dimensions');
const {height, width} = Dimensions.get('window');

import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo'
import EvilIcons from 'react-native-vector-icons/EvilIcons'
import Feather from 'react-native-vector-icons/Feather'
import Ionicons from 'react-native-vector-icons/Ionicons'
import { AsyncStorage } from "react-native";
import { getWorkoutDetails } from '../template/Workout/workout.js';
import { getExercises } from '../template/api.js';

import styles from './styles.js'

import { request } from 'graphql-request'

import StatusBarBackground from './Tabs/statusbar.js'


export default class WorkoutDetails extends Component {

    constructor(props) {
        super(props);
        this.state = {
            workoutdata: null,
            user_id: '',
            contentLoader: true,
            exercises: []
        }
    }


    async componentWillMount() {
        console.log(this.props.navigation.state.params)
        var {params} = this.props.navigation.state.params;
        let USER_ID = await AsyncStorage.getItem("USER_ID");
        this.setState({
            user_id: USER_ID
        })
        this.getWorkoutDetails(this.props.navigation.state.params.id)
        console.log(this.props.navigation.state.params)
    }


    getWorkoutDetails(id) {

        const query = `query fetch_workout_details($workout_id: Int!){
                              fetch_workout_details(workout_id: $workout_id){
                                title
                                thumbnail_url
                                backThumbnail_url
                                tags
                                difficulty
                                
                                workout_to_user{
                                  completion_date
                                  user_id
                                  user_details{
                                    first_name
                                  }
                                }
                                workout_to_exercise{
                                  exercise_id
                                  exercise_index
                                  exercise{
                                    streaming_url
                                    id
                                    title
                                    jobstatus
                                  }
                                }
                              }
                              
                            }
                        `;

        const variables = {
            workout_id: id
        }


        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_by_id', query, variables)
            .then(async data => {
                
                console.log(data)
                this.setState({
                    Loader: false,
                    contentLoader: false
                })

                response = data.fetch_workout_details[0]

                this.setState({
                    workoutdata: response
                });
                this.setState({
                    ImageUrl: response.backThumbnail_url
                });
                this.setState({
                    Title: response.title
                });
                this.setState({
                    Duration: response.duration
                });
                this.setState({
                    intensity: response.difficulty
                });            

                this.setState({exercise_list: response.workout_to_exercise[0].exercise_id}) 

                this.setState({exercises_total_list: response.workout_to_exercise[0].exercise}) 

                this.setState({exercise_index_list: response.workout_to_exercise[0].exercise_index})   

                console.log(response)

            }
        )
            .catch(async err => {
                console.log(err)
                alert("Something Went Wrong, Please try again later")
                this.setState({
                    loader: false,
                    ontentLoader: false
                })
            }
        )


    }


    onPressChevronLeft() {
        const {navigate} = this.props.navigation;
        navigate('UpcomingWorkouts');
    }

    async nextpage() {

        /*

        const {navigate} = this.props.navigation;
        navigate('Videoactivity', {id: this.props.navigation.state.params.id});

        */      

        exercise_list = this.state.exercise_list

        exercise_index_list = this.state.exercise_index_list

        j=0;

        prev_exe_id = ""

        for(i=0;i<exercise_list.length;i++){

            exe_id = exercise_list[i]

            exe_index = exercise_index_list[i]

            var today  = moment().format('YYYY-MM-DD')

            user_id = this.state.user_id

            course_id = this.props.navigation.state.params.course_id;

            workout_id = this.props.navigation.state.params.id;


                const query = `mutation addexercisestatus($exercise_id:Int!, $user_id:Int!, $workout_id: Int!, $course_id:Int!, $exercise_status:Int!, $completion_date: String!, $exercise_index: Int!, $start_date_workout: String!){

                            addexercisestatus(exercise_id:$exercise_id, user_id:$user_id, workout_id:$workout_id, course_id:$course_id, exercise_status:$exercise_status, completion_date: $completion_date, exercise_index: $exercise_index, start_date_workout: $start_date_workout){
                                status
                                id
                              }

                    }`;

                console.log(query)

                const variables = {
                    exercise_id: Number(exe_id),
                    user_id: Number(user_id),
                    workout_id: Number(workout_id),
                    course_id: Number(course_id),
                    exercise_status: 0,
                    completion_date: "00",
                    exercise_index: Number(exe_index),
                    start_date_workout: today
                }

                request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_by_id', query, variables)
                    .then(async data => {
                        console.log(data)

                        j++
                    }
                )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                    }
                ) 

            console.log(this.state.exercises_total_list)

        }  



                const workout_query = `mutation addworkoutstatus($user_id:Int!, $workout_id: Int!, $course_id:Int!, $workout_status:Int!, $completion_date: String!, $start_date: String!){

                            addworkoutstatus(user_id:$user_id, workout_id:$workout_id, course_id:$course_id, workout_status:$workout_status, completion_date: $completion_date, start_date: $start_date){
                                status
                                id
                              }

                    }`;

                const workout_variables = {
                    user_id: Number(user_id),
                    workout_id: Number(workout_id),
                    course_id: Number(course_id),
                    workout_status: 0,
                    completion_date: "00",
                    start_date: String(today)
                }

                //console.log(variables,'dsasdadds')

                request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_workout_by_id', workout_query, workout_variables)
                    .then(async data => {
                        console.log(data)
                    }
                )
                    .catch(async err => {
                        console.log(err)
                        alert("Something Went Wrong, Please try again later")
                        this.setState({
                            contentLoader: false
                        })
                    }
                )       


        if(i == exercise_list.length) {


     
         const {navigate} = this.props.navigation;

            navigate('Videoactivity', {id: this.props.navigation.state.params.id, course_id:this.props.navigation.state.params.course_id, exercises_list: this.state.exercises_total_list, exercises_list_ids: exercise_list, workout_title: this.state.Title});

        }

    }

    render() {
        const {navigation} = this.props
        const resizeMode = 'center';
        const text = 'I am some centered text';

        const {contentLoader} = this.state;


        return (

            <View style={styles.mainBody} >

        <StatusBarBackground style={{backgroundColor: '#ff7200'}}/>

          {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
            :
            <ScrollView
            style={{
                flex: 1
            }}
            contentContainerStyle={{
                paddingBottom: 50
            }}
            indicatorStyle={'white'}
            scrollEventThrottle={200}
            directionalLockEnabled={true}
            >
              <View style={styles.listofWrkouts21}>

                <View style={styles.header_wrkout_details}>
                       <Image style={{
                width: Dimensions.get('window').width,
                height: 260
            }} source={{
                uri: this.state.ImageUrl
            }} />
                <View style={styles.chevron_left_icon}>
                  <TouchableOpacity onPress={() => this.onPressChevronLeft()}>
                      <FontAwesome name="chevron-left" size={25} color="#FF7E00"   />
                  </TouchableOpacity>
                </View>
                </View>
                <View>
                    <Text style={styles.wrkdetails_name1}>
                      {this.state.Title}
                    </Text>
                    <View style={styles.wrkdetails_name1abc_mas}>
                      <Text style={styles.wrkdetails_name1a}> {this.state.Duration} MIN!</Text>
                      {this.state.intensity < 5 ? <Text style={styles.wrkdetails_name1b}> LOW LEVEL</Text>
                : <Text style={styles.wrkdetails_name1b}> HARD LEVEL</Text>}
                    </View>
                </View>

                <View style={{borderWidth: 1, borderColor: '#000'}}></View>


              </View>





            </ScrollView>

        }


        <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
            <TouchableOpacity onPress = {() => this.nextpage()}>
                <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                    

                    <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Start Workout</Text>
          
                </View>
                <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
            </TouchableOpacity>
        </View> 




            </View>

        );
    }
}
