import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Switch, Image, PixelRatio, KeyboardAvoidingView, ScrollView, TouchableHighlight, TouchableOpacity, TextInput, AsyncStorage, Dimensions, Keyboard, ToastAndroid, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/FontAwesome';
import { NavigationActions } from 'react-navigation';
import { onSignIn, onSignOut, getAllAsyncStroage } from '../../../config/auth';
import { signin, getCourses } from '../../template/api.js'
import axios from 'axios';
import FCM, { FCMEvent, RemoteNotificationResult, WillPresentNotificationResult, NotificationType } from 'react-native-fcm';
import styles from '../signup/styles.js';
import moment from 'moment';

import Toast, { DURATION } from 'react-native-easy-toast'
import StatusBarBackground from './statusbar.js'

const {height, width} = Dimensions.get('window');

const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');

import SearchInput, { createFilter } from 'react-native-search-filter';
const KEYS_TO_FILTERS = ['school_name'];

import { request } from 'graphql-request'


export default class Subscribe extends Component {

    constructor(props) {
        super(props);
        this.state = {
            selected: null,
            schoolname: null,
            searchTerm: '',
            course: null,
            contentLoader: true,
        };
    }
    searchUpdated(term) {
        this.setState({
            searchTerm: term
        })
    }
    componentWillMount() {

        courseid = this.props.navigation.state.params.courseid

        this.getSchool(courseid)

    }



    getSchool = (id) => {

        const query = `query fetch_course_by_id($course_id:Int!){
                          fetch_course_by_id(course_id: $course_id){
                            id
                            title
                            units
                            location
                            description
                            room
                            class_meets
                            start_date
                            days_and_times
                            refund_date
                            grading_option
                            advisories
                            limitations_on_enrollment
                            corequisites
                            prerequisites
                            length
                            
                            course_to_plan{
                              index
                              week
                              plan_id
                              day
                              plan_slot{
                                workout_id
                                workout{
                                  duration
                                  title
                                  tags
                                  difficulty
                                  description
                                  equipment
                                }
                              }
                            }
                          }
                        }
                        `;

        const variables = {
            course_id: Number(id),
        }


        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_course', query, variables)
            .then(async data => {
                this.setState({
                    course: data.fetch_course_by_id[0]
                })
                console.log(this.state.course)
                this.setState({
                    contentLoader: false
                })

            }
        )
            .catch(async err => {
                console.log(err)
                alert('There is no schools or server problom')
                this.setState({
                    contentLoader: false
                })
            }
        )

    }

    nextstep = async () => {

        let USER_ID = await AsyncStorage.getItem("USER_ID");

        var start_date  = moment().format('YYYY-MM-DD')

        var subscription_date = moment().format(); 

        var courseid = this.props.navigation.state.params.courseid

        const query = `mutation course_subscription($course_id: Int!, $start_date: String!, $student_id: Int!, $subscription_date: String!){
                          course_subscription(course_id:$course_id, start_date:$start_date, student_id:$student_id, subscription_date:$subscription_date){
                           status 
                          }
                        }  
                        `;

        const variables = {
            course_id: Number(courseid),
            student_id: Number(USER_ID),
            start_date: start_date,
            subscription_date: subscription_date

        }

        console.log(variables)

        request('http://resoltzphase3.centralindia.cloudapp.azure.com/api/v1/fetch_course', query, variables)
            .then(async data => {
                console.log(data)

                if (data.course_subscription[0].status == 'success') {
                    alert('Updated')
                    const {navigate} = this.props.navigation
                    navigate("ProfileFill", {
                        userinfo: 0,
                        profiledetails: 0,
                        pickclass: 0
                    })
                }

            }
        )
            .catch(async err => {
                console.log(err)
                alert('There is no schools or server problom')
                this.setState({
                    contentLoader: false
                })
            }
        )

    }

    render() {
        const {navigate} = this.props.navigation;
        const {course, contentLoader} = this.state;


        return (
            <View style={ styles.mainBody }>
        <StatusBarBackground style={{
                backgroundColor: '#ff7200'
            }}/>
          <View style={styles.chevron_left_icon}>
            <TouchableOpacity onPress={() => {
                const {navigate} = this.props.navigation;
                navigate('Courses')
            }}>
              <Icon name="chevron-left" size={25} color="#FF7E00"   />
            </TouchableOpacity>
          </View>
          <View style={styles.header1}>
            <Text style={styles.topSignupTxt}>
              Pick Course (2/2)
            </Text>
          </View>

        {contentLoader ?
                <ActivityIndicator
                animating = {this.state.contentLoader}
                color = '#bc2b78'
                size = "large"
                style = {styles.activityIndicator}
                />
                :
                <View>


           <View>
           <ScrollView>

                            <View style={styles.searchresults1}>
                              <Text style={styles.selected1}>
                              Prerequisites: {course.prerequisites}.{"\n"}Corequisites: {course.corequisites}. {"\n"}
                              Limitations on Enrollment: {course.limitations_on_enrollment}. {"\n"}Advisories: {course.advisories}. {"\n"}
                              Grading Option: {course.grading_option}. {"\n"}
                              </Text>                             
                            </View>

                            <View style={styles.searchresults1}>
                              <Text style={styles.selected1}>
                              Course Discription: {"\n"}{course.description}
                              {"\n"}</Text>                             
                            </View>

                            <View style={styles.searchresults1}>
                              <Text style={styles.selected1}>
                              Dates & Time: {course.days_and_times}.{"\n"}Units: {course.units}. {"\n"}
                              Location: {course.location}. {"\n"}Room: {course.room}. {"\n"}
                              Instructor: None. {"\n"}
                              </Text>                             
                            </View>

                            <View style={styles.searchresults1}>
                              <Text style={styles.selected1}>
                              Class Meets: {course.class_meets}.{"\n"}Refund Date: {course.return_date}. {"\n"}
                              Start Date: {course.start_date}. {"\n"}Last Drop Date: {course.start_date}. {"\n"}
                              </Text>                             
                            </View>                            


             </ScrollView>           

           </View>

           </View>

            }

          <View style={{
                bottom: 0,
                position: 'absolute',
                alignItems: 'center',
                justifyContent: 'center'
            }}>
              <TouchableOpacity onPress={() => this.nextstep()}>
                  <View style={{
                zIndex: 999,
                alignItems: 'center',
                justifyContent: 'center',
                height: 50,
                width: width
            }}>
                      

                      <Text style={{
                backgroundColor: 'transparent',
                alignSelf: 'center',
                fontFamily: 'CircularStd-Black',
                color: '#fff',
                fontSize: 19
            }}>Save and continue</Text>
            
                  </View>
                  <Image style={{
                width: width,
                height: 50,
                position: 'absolute',
                bottom: 0
            }} source={{
                uri: 'btn_gradi_bg'
            }}/>
              </TouchableOpacity>
          </View>

               <Toast
            ref="toast"
            style={{
                backgroundColor: '#000',
                bottom: 0
            }}
            position='top'
            positionValue={200}
            fadeInDuration={750}
            fadeOutDuration={1000}
            opacity={0.8}
            textStyle={{
                color: 'white'
            }}
            />
      </View>
        );
    }
}
